# Changelog — KTC-Quan-tri Plugin

## 1.3.7 — 2026-09-28

Sửa từ **chạy thật plugin 1.3.6** như tài khoản thành viên (thư mục ngoài dự án, câu lệnh mẫu mới). Lần chạy đó đã ra đủ
4 sản phẩm (báo cáo Word 8.720 chữ dựng từ BC-375, phụ lục 261 công thức KPI, kế hoạch tháng 10, ghi chú đối soát; 0 lỗi
thể thức Mức 1–2) nhưng lộ 4 lỗi. Ca thử: `test_bc_thang.py`, `test_plugin_131.py`.

- `bc_thang.py word`: bản đã ban hành trong kho ghi số hiệu dị dạng "Số375BC-CĐKT" → nay vẫn để trống số cho Văn thư.
- `bc_thang.py phu-luc`: tiêu đề nhóm, Trục của bản gốc còn "tháng 8" → đổi sang kỳ báo cáo.
- **Guard:** chặn Write/Edit vào tệp của plugin đã cài (và bộ đệm `.claude/plugins/`) — lần chạy đã ghi "bộ nhớ quá
  trình" vào chính tệp plugin. Kỹ năng `bao-cao` 3.19: ngoài dự án thì ghi vào ghi chú đối soát.
- Hook đo thể thức bỏ qua `10-Dau-Vao/` (tệp đơn vị vừa chép vào bị đo nhầm như sản phẩm).

## 1.3.6 — 2026-09-28

**Báo cáo tháng cấp Trường dựng từ bản đã ban hành** (`DL-20260928-004`). Chạy thử 28/9/2026 trên Cowork và Claude Code
(tài khoản phongthhcqt) cho báo cáo tháng 9 kém bản 21/9: dựng từ mẫu trắng qua `fill_bc736.py`, còn thẻ `[CẦN BỔ SUNG
[PHAN_I] …]`, mang lỗi của mẫu, thay tường thuật bằng tỷ lệ %, bỏ cả đơn vị vì vài dòng sai công thức, thiếu kế hoạch
tháng 10. Bản 21/9 đạt vì dùng công cụ chỉ có trong dự án. Ca thử: `test_bc_thang.py` (mới, 28 ca).

- **`scripts/bc_thang.py`** (cũng trong `skills/bao-cao/references/Skill-Library/`): `nguon` (bản đã ban hành gần nhất,
  Chương trình công tác năm, kế hoạch quý, kết luận giao ban; phân loại tệp đơn vị IIa/IIb/Ib) · `trich` (tường thuật IIa
  theo Trục, dòng IIb/Ib) · `word` · `phu-luc` · `ke-hoach` (mở bản đã ban hành, thay nội dung, giữ thể thức, dựng lại
  công thức KPI, tự kiểm `[CẦN BỔ SUNG`, kỳ cũ, văn phong, mục con). Dựng lại nội dung 21/9 bằng công cụ: trùng 100% chữ.
- **Skill `bao-cao` 3.18:** quy trình chính 4 sản phẩm (báo cáo Word, phụ lục KPI, kế hoạch tháng sau, ghi chú đối soát);
  đầu mối chưa nộp thì tổng hợp từ nguồn khác có ghi nguồn (QĐ-08); lỗi công thức dòng không loại cả đơn vị; nguồn ghi ở
  ghi chú đối soát, không chèn vào thân văn bản; `fill_bc736.py` chỉ còn dự phòng.
- Đóng thêm vào `scripts/`: `vanphong.py` (văn phong cấp Trường), `trich_tuong_thuat.py`, `ktc_trackchanges.py`
  (Track Changes, Nguyên tắc 8 — trước chỉ có trong kỹ năng soạn thảo).
- Mẫu trắng báo cáo tháng (dự phòng) sửa "nhiệm kỳ 2021-2026" → "2026-2031", "Báo cáo báo cáo", "tháng 7".
- Tác tử `ktc-kiem-ho-so-don-vi`: `TRẢ LẠI ĐƠN VỊ` là yêu cầu sửa, không loại đơn vị khỏi báo cáo cấp Trường.

## 1.3.5 — 2026-09-28

**Kết nối thư mục làm việc của đơn vị** cho tài khoản thành viên (phòng, khoa) trên Claude Cowork, Claude Code ngoài dự
án. Ca thử: `test_thu_muc.py` (mới, 20 ca gồm ca ngược).

- `scripts/ktc_thu_muc.py` (cũng có trong kỹ năng `quan-tri`): `khoi-tao <thư mục> --ma <mã đơn vị>` tạo `10-Dau-Vao/`,
  `30-Ket-Qua/`, `00-HUONG-DAN.md` và tệp đánh dấu `KTC-THU-MUC-LAM-VIEC.json`; không ghi đè; từ chối kho chuẩn, dự án,
  mã ngoài 11 mã chuẩn, thư mục đã kết nối cho đơn vị khác. `kiem` báo chế độ: dự án · thư mục đơn vị · chưa kết nối.
- Nguyên tắc 3 (bản sao trong `ke-hoach` 3.11, `theo-doi-cv` 1.9, `bao-cao` 3.17, `soan-thao-vb` 1.12, `quan-tri` 1.16):
  đầu vào thêm nguồn "thư mục làm việc của đơn vị"; kết quả lưu `30-Ket-Qua/` trong thư mục đó; người dùng vẫn tự gửi
  về Phòng TH-HC&QT. Kết nối thư mục không thay kho KTC-Database.
- Khối quy tắc lõi mục 5: `30-Ket-Qua/` của dự án hoặc thư mục đơn vị; chưa có thì giao tệp trong phiên.
- `kpi-lap-ke-hoach` 1.4, `kpi-tu-danh-gia` 1.3: lưu tệp ra thư mục đơn vị khi đã kết nối.
- Hook đo thể thức tự chạy cả trong thư mục đơn vị (trước chỉ trong dự án).
- Kiểm tra đầu phiên: báo chế độ thư mục; không thấy kho thì hướng dẫn thêm lối tắt "KTC-Database" vào Drive của tôi
  hoặc đặt `KTC_DATABASE_DIR`.

## 1.3.4 — 2026-09-28

Chuẩn phân loại 6 Trục theo quyết định `DL-20260928-002`; không đổi kết quả tính. Ca thử: `test_plugin_131.py` (mục A).

- **Chuẩn 6 Trục** (bản sao trong `ke-hoach` 3.10, `theo-doi-cv` 1.8, `bao-cao` 3.16, `soan-thao-vb` 1.11, `quan-tri` 1.15):
  cột (9)(10) Phụ lục kế hoạch, báo cáo (TB 736) theo 4 mức độ, **căn cứ Quyết định số 1923/QĐ-CĐKT Phụ lục I, II** (trước
  chỉ dựa dữ liệu vận hành); bảng quan hệ với Danh mục sản phẩm, công việc theo Quyết định số 2119/QĐ-CĐKT (hệ số sản phẩm
  dùng cho cột Sản phẩm và KPI cá nhân phương án A; không thay cột (10), không nhân hai hệ số); bỏ ghi chú thang 5 nhóm là
  dự thảo và KI-014 chưa xử lý.
- **Guard — sửa chặn nhầm thật** (28/9/2026): đứng trong kho chạy `python - <<'EOF'` có `if i > 45:` bị hiểu là chuyển hướng
  ghi. Thân heredoc đưa cho trình thông dịch không còn phân tích như câu lệnh shell (đưa cho `bash`/`sh` thì vẫn phân tích);
  tầng 2 vẫn xét toàn chuỗi. Chạy lại 2.283 lệnh thật: bỏ 3 lần chặn nhầm, 0 lần chặn mới.

## 1.3.3 — 2026-09-28

Cập nhật theo **Quyết định số 2119/QĐ-CĐKT ngày 28/9/2026** ban hành Danh mục sản phẩm, công việc **chính thức**, thay thế
danh mục dự thảo kèm TB 1052/TB-CĐKT (`DL-20260928-001`). Ca thử: `test_kpi_calc.py`, `test_validate_plan.py`,
`test_plugin_131.py` (mục A).

- **`kpi-lap-ke-hoach` 1.3**: phương án `A` tra hệ số theo Danh mục QĐ 2119 (416 sản phẩm; tra theo mã `Trục.Nội hàm.Mã VB.STT`,
  STT phụ lục hoặc tên chính xác); trạng thái "Có văn bản", **không còn** mã `THANG_DIEM_CHUA_PHAN_DINH`. `AxB` vẫn cảnh
  báo (phép nhân chưa có văn bản). Sản phẩm ngoài Danh mục → KH08 dẫn QĐ 2119. Dữ liệu `he-so-san-pham-QD2119.csv` trích
  từ phụ lục trong kho 02, kèm mã băm nguồn. Dự thảo TB 1052 chuyển lưu trữ.
- **`kpi-tu-danh-gia` 1.2**: đồng bộ `kpi_calc.py`, Câu hỏi mở (#2 đóng), Thuật ngữ.
- **`quan-tri` 1.14**: ghi chú Danh mục chính thức và cách trích dẫn mới; quy tắc KPI gốc mục C; ví dụ mẫu số 4.
- Chuẩn chung: mã `THANG_DIEM_CHUA_PHAN_DINH` nay chỉ dùng cho cách quy đổi chưa có văn bản (A × B).
- **Guard — sửa chặn nhầm thật** (28/9/2026): `str.replace()`/`DataFrame.rename()` trong lệnh chỉ đọc kho bị coi là ghi.
  `.replace(`/`.rename(` nay chỉ tính là ghi khi lệnh có `Path(...)` (hoặc `os.replace`/`os.rename`); ca ngược giữ chặn.
- KPI đã chấm trước 28/9/2026 (Quý III) không tính lại.

## 1.3.2 — 2026-09-27

Tiếp thu thẩm định độc lập lần 4 (`DL-20260927-002`). Ca thử: `test_plugin_131.py` (mục A, E).

- **Guard tầng 2 chặn thay vì hỏi** (ChatGPT L4 F4-01, tái hiện: biến trỏ kho + `shutil.copy` trả `ask`): lệnh không xác
  định được đích mà có dấu hiệu ghi vào kho → chặn (mã 2); không còn lựa chọn "đồng ý". Chạy lại 1.653 lệnh thật: 0 chặn nhầm.
- **Sửa chặn nhầm thật trong vận hành** (27/9/2026): `sed -i`/`perl -i` chỉ xét tệp đích, không xét biểu thức thay thế có chữ
  "KTC-Database"; ca thử gồm đúng lệnh bị chặn nhầm.
- Chặn tạo liên kết tượng trưng/thư mục trỏ vào kho (`ln`, `mklink`, `New-Item -ItemType SymbolicLink|Junction`).
- Sửa nhận dạng đường dẫn tuyệt đối Windows `C:\…` (bản 1.3.1 coi là tương đối khi đang đứng trong kho → chặn nhầm).
- Khối quy tắc lõi: ghi rõ đường dẫn bản đầy đủ cho agent `skills/quan-tri/references/00-Quy-Tac-Bat-Bien-Day-Du.md` (F4-07).
- `kiem_vien_dan.py` đọc tệp văn bản UTF-8, UTF-16, cp1258, cp1252 (chuẩn hóa NFC), báo bảng mã đã dùng (Gemini L4).
- `kiem_ho_so.py` (máy phát triển): kiểm mã băm hồ sơ và số đánh dấu tệp `_TrackChanges` trước khi gửi thẩm định (F4-03).
- Bộ ca nghiệm thu khai báo `runs: 2` trong từng ca — metadata `runsPerCase` khớp số lượt chạy (F4-04).

## 1.3.1 — 2026-09-27

Tiếp thu thẩm định độc lập lần 3 (`KI-019`). Ca thử: `test_plugin_131.py`.

- **Guard hai tầng** (ChatGPT L3 P0-2): chặn lệnh lồng (`powershell -Command`, `pwsh -c`, `cmd /c`, `bash -c`), mã
  Python nhúng `open(..., 'w')`/`Path().write_text|unlink`, `cd` vào kho rồi ghi, UNC, `-EncodedCommand`; **hỏi người
  dùng** khi đích không xác định (mã nhúng hoặc biến trỏ vào kho + dấu hiệu ghi). Vùng bảo vệ khớp theo thành phần
  đường dẫn — sửa 3 lần chặn nhầm có từ 1.3.0 (tên tệp chứa "KTC-Database"). Sửa tách lệnh đường dẫn Windows (`\`).
- **Nhật ký không lưu nội dung thô qua PostToolUse** (ChatGPT L3 P0-1): lệnh Bash/PowerShell → chương trình + loại
  hành động; Agent → loại agent; Grep/Glob → không lưu mẫu; tệp → đường dẫn tương đối. Lệnh (đã che dữ liệu) chỉ
  khi chủ máy chọn `KTC_NHAT_KY_NOI_DUNG=1`. Nhật ký cũ được làm sạch khi mở phiên (trừ máy đã chọn ghi).
- **Tiết kiệm token** (ChatGPT L3 mục 4, P1-1; Gemini, Grok, Copilot): khối chuẩn chung chèn vào skill/agent rút từ
  ~4.550 xuống ~2.460 ký tự (−46%) (giữ đủ 7 quy tắc, 6 trạng thái, 6 mã cảnh báo, tự kiểm); diễn giải, ví dụ, bảng mã
  chuyển `references/00-Quy-Tac-Bat-Bien-Day-Du.md`; lịch sử phiên bản đầu `SKILL.md` chuyển
  `references/LICH-SU-PHIEN-BAN.md`; phần nạp đầu phiên ≤ 4.500 ký tự, không in lệnh, không in đường dẫn ngoài dự án.
- **Quy tắc bất đồng skill–agent** (Copilot L3 R5): nêu đủ các bên kèm căn cứ, `CAN_XAC_MINH`, người có thẩm quyền
  quyết; không bỏ phiếu; Mức 1 theo bất kỳ bên nào thì chưa trình ký.
- skill `bao-cao` **3.15**: viết lại mô tả kích hoạt (có dấu, nêu tình huống viết đoạn đánh giá, tổng hợp bảng kết quả
  dán trong khung chat) — nghiệm thu đo được skill không tự kích hoạt với các yêu cầu này, trả lời thiếu khối trạng thái.
- Mã `DOI_CHIEU_GAN_DUNG`: bắt buộc đối chiếu thủ công 100% trước khi lãnh đạo đơn vị ký duyệt (Gemini L3 4.1).
- Bộ ca nghiệm thu Code thêm 9 ca cho ba luồng rủi ro cao — KPI, báo cáo, soạn thảo — có bộ chấm tất định
  (regex) bên cạnh giám khảo LLM (ChatGPT L3 P1-3).

## 1.3.0 — 2026-09-26

Tiếp thu thẩm định độc lập lần 1, lần 2 (`KI-019`). Mọi thay đổi có ca thử trong `test_plugin_130.py`,
`test_plugin_nhat_ky_backup.py`, `test_tu_hoc.py`.

- **Gỡ sao lưu GitHub khỏi plugin** (C-01, R2-01): bỏ khỏi `SessionStart`; `ktc_backup_github.py` không còn nằm trong
  plugin (chỉ chạy theo lịch trên máy phát triển), thêm quét nội dung số định danh cá nhân trước khi commit.
- **Guard chặn ghi độc lập** `scripts/ktc_guard.py` (C-04, R2-03): `PreToolUse` cho Write, Edit, MultiEdit,
  NotebookEdit, Bash, PowerShell; fail-closed; doctor tự thử và báo trạng thái.
- **Nhật ký riêng tư mặc định** (C-02, R2-02): lời người dùng chỉ ghi độ dài + nhãn tín hiệu; nội dung chỉ khi chọn:
  `#học` (lời đó) hoặc chủ máy đặt `KTC_NHAT_KY_NOI_DUNG=1` (chỉ lời **có tín hiệu học**); nội dung luôn **che** số định
  danh, số điện thoại, email; xóa tệp cũ hơn 30 ngày. Bộ gắn tín hiệu bỏ lời < 5 từ, bỏ "OK" trần, bỏ số hiệu văn bản
  ("Quyết định số …") — TT-20260924-08.
- `kpi_calc.py`: phương án hệ số A, A×B (dự thảo TB 1052) trả mã `THANG_DIEM_CHUA_PHAN_DINH` (KI-014).
- **Chuẩn chung** `20-Chuan-Chung/20-Quy-Tac-Bat-Bien-Va-Khuon-Dau-Ra.md` chèn vào 8 skill + 7 agent (C-03, M-02,
  R2-08): quy tắc bất biến cấp skill, ranh giới dữ liệu, kiểm soát dữ liệu ra ngoài, 6 trạng thái, mã cảnh báo, tự
  kiểm, ví dụ.
- skill `quan-tri` **1.13**: thứ tự ưu tiên chứng cứ; "cứ làm" khi thiếu nguồn chỉ ra bản nháp `CAN_XAC_MINH`; ví dụ
  riêng; giới hạn nền tảng theo năng lực; lịch sử phiên bản chuyển `CHANGELOG.md`.
- Sửa YAML mô tả agent `ktc-kiem-san-pham` (lỗi có từ 19/9: agent mất toàn bộ frontmatter lúc chạy); bước dựng tự
  chặn mô tả không ngoặc có `: `.
- Doctor báo phụ thuộc ngoài gói: Python, KTC-Database, thư viện docx/openpyxl (M-01, M-06).

## 1.2.1 — 2026-09-25

- Lệnh sửa trình bày sheet KPI (`DL-20260925-002`, Known-Issues #13, #14), **không đổi số nào** (ca thử ghim tổng điểm 6 nhóm):
  - Hết che chữ: chiều cao dòng tính cả nội dung mà công thức `='Ke Hoach'!B…` trỏ tới, độ rộng cột đọc theo nhóm
    (openpyxl gộp C–F, S–Y), lấy cực đại mọi cột, cả hai sheet; đo lại sau khi ghi số thực tế; > 409 pt → KH19.
  - Cột C–F sheet KPI có người chỉ đạo, người phối hợp (không tự điền — KH17), đơn vị tham mưu, sản phẩm (công thức;
    KH18). Tệp ra đang mở trong Excel → thông báo rõ.
- skill `kpi-lap-ke-hoach` **1.2**, `kpi-tu-danh-gia` **1.1**.

## 1.2.0 — 2026-09-25

- **Skill mới `kpi-tu-danh-gia`** (v1.0, `DL-20260925-001`): tự đánh giá, đề xuất xếp loại cá nhân theo quý (QĐ 1923).
  Từ kế hoạch KPI đã duyệt sinh **bảng hỏi Excel** (điểm tiêu chí chung, số thực tế 3 chiều, điều kiện, trường hợp đặc
  thù), rồi tính A 30 + B 70 **chặn trần 100% từng chỉ tiêu** [Đ11.6], đối chiếu ngưỡng 90/70/50 và điều kiện Đ19; xuất
  Bản tự đánh giá (`TDG-KPI-...xlsx`). Không quyết định mức xếp loại; không tính trần tỷ lệ HTXS (giai đoạn 3).
- `scripts/kpi_danh_gia.py` (mới); `kpi_mau.cau_truc_danh_gia()` dò động sheet Đánh giá cả 6 mẫu.
- skill `kpi-lap-ke-hoach` **1.1**: xóa số thực tế ví dụ của mẫu ở sheet KPI (L=4, N=100, P=100 — bản 1.0 để sót), tự
  xuống dòng, ẩn dòng trống; KH16; nhận đúng nhóm Trưởng/Phó đơn vị từ tiêu đề mẫu (bản 1.0 không nhận → KH10 bỏ sót).
- skill `quan-tri` **1.12**: đồng bộ quy tắc KPI gốc (Đ10.5 theo nhóm, Đ21.4/Đ21.6).
- Manifest qua `claude plugin validate --strict` (lần đầu chạy được).


## 1.1.2 — 2026-09-24

- Bảo mật nhật ký (`CP-20260924-001`, phương án A + C): lời nhắn bắt đầu bằng **`#riêng`** (hoặc `#rieng`) thì hook
  `ktc_nhat_ky.py` chỉ ghi mốc thời gian, không ghi nội dung, không đánh dấu tín hiệu học. Nhật ký tự động của dự án
  (`90-Nhat-Ky-Van-Hanh/04-Nhat-Ky-Tu-Dong/`) ra khỏi git — backup tối không còn đẩy lời người dùng lên GitHub.

## 1.1.1 — 2026-09-24

- `scripts/doi_soat_so_lieu.py` đọc mục **ánh xạ bổ sung máy đọc** của bảng mã đơn vị: Ban Truyền thông → `P-THHC`
  (quyết định 14/9/2026, cấp hai), biến thể tên tệp có bằng chứng (`P.THHCQT`, `P QLKHCN`, `SP`, `Ban TT`). Kỳ 2026-09 hết
  đơn vị chưa nhận diện (công cụ ghi dạng `?<tên>`); DS06 chỉ còn K-KTNL chưa nộp Phụ lục Excel. Vẫn chỉ khớp chính xác.
- skill quan-tri **1.11**: bản sao `12-Bang-Ma-Don-Vi.md` đồng bộ bản gốc.

## 1.1.0 — 2026-09-24

- **Skill mới `kpi-lap-ke-hoach`** (v1.0, `DL-20260924-001`): lập kế hoạch và danh mục KPI cá nhân theo quý theo
  QĐ 1923/QĐ-CĐKT, 6 mẫu Kế hoạch + KPI (03-Templates/03-12). Hệ số quy đổi **không có mặc định** — bắt chọn phương
  án (mức độ: có văn bản · A theo TB 1052: dự thảo · A×B: chưa có văn bản · nhập tay). Giai đoạn 1: chỉ lập kế hoạch.
- Công cụ dùng chung `scripts/kpi_calc.py`, `kpi_mau.py`, `validate_plan.py` (KH01–KH15, mỗi lỗi dẫn Điều).
- skill quan-tri **1.10**: `references/30-KPI-Va-Xep-Loai.md` thành bản sao của quy tắc gốc
  `20-Chuan-Chung/19-Quy-Tac-KPI.md`; lập KPI cá nhân chuyển sang skill mới.

## 1.0.1 — 2026-09-24

- **`scripts/doi_soat_so_lieu.py`**: nhận mã đơn vị, loại KH/KQ và kỳ từ phần đầu tệp khi tên tệp/thư mục không theo quy
  ước (bố cục `10-Dau-Vao` ngày 21/9: `1. BAO CAO PL IIB/KHCB.xlsx`). Bản 1.0.0 gộp 10 đơn vị thành một và xếp
  `KHCB.xlsx` là kế hoạch mà vẫn thoát mã 0. Khớp mã chỉ chính xác theo bảng biến thể `13-Bang-Ma-Don-Vi.md`; không khớp
  thì tách riêng `?<tên>` và DS06 báo. Ảnh hưởng agent `ktc-kiem-ho-so-don-vi`, `ktc-kiem-san-pham`.
- skill soan-thao-vb **1.10**: đồng bộ quy tắc khai thác Internet với bản gốc 897 (tra `phapluat.gov.vn` trước tiên).

## 0.9.1 — 2026-09-19

- Cập nhật TB 1052/TB-CĐKT (`DL-20260919-007`): danh mục 371 sản phẩm đã gửi đơn vị rà soát (hạn 20/9), chưa ban hành;
  quy đổi STT 38 lĩnh vực → Trục/nội hàm. skill quan-tri 1.9.

## 0.9.0 — 2026-09-19

- Agent mới **`ktc-xac-minh-minh-chung`** (tổng 7) + công cụ `scripts/kiem_minh_chung.py` (MC01–MC07) — `DL-20260919-006`.
- Công cụ dùng chung **`scripts/doi_soat_so_lieu.py`** (DS01–DS06) — `ktc-kiem-ho-so-don-vi` và `ktc-kiem-san-pham` bắt buộc
  gọi, không tự cộng. Không tách agent đối soát riêng (tránh 3 agent cho 3 kết luận về cùng một con số).

## 0.8.1 — 2026-09-19

- Sửa lỗi Cowork từ chối tải lên: mô tả `plugin.json` 554 → 336 ký tự (giới hạn 500). Bản dựng tự chặn mô tả plugin > 500
  và mô tả skill/agent > 1024 ký tự.

## 0.8.0 — 2026-09-19

- **Vòng tự học** (`DL-20260919-005`): hook `UserPromptSubmit` ghi lời người dùng + tín hiệu học; agent mới **`ktc-tu-hoc`**
  rút tri thức vào `90-Nhat-Ky-Van-Hanh/05-Tri-Thuc-Tu-Hoc/TRI-THUC.md`; hook SessionStart nạp tri thức + nhắc tín hiệu chưa
  học; hook thể thức ghi cảnh báo làm bằng chứng. `ktc-tu-cai-tien` đọc mục `→ CP`. Tổng 6 agent.

## 0.7.0 — 2026-09-19

- **4 agent mới** (tổng 5, `DL-20260919-004`): `ktc-kiem-ho-so-don-vi`, `ktc-tra-cuu-can-cu`, `ktc-kiem-san-pham`,
  `ktc-hieu-luc-vien-dan`. Chỉ đọc, chỉ ghi báo cáo vào `30-Ket-Qua/<ngày>/…`; không lặp reviewer của 897.
- **Quét hiệu lực pháp lý + viện dẫn**: `scripts/tra_hieu_luc.py` (kèm `kiem_vien_dan.py`, `duong_dan.py`) — trích văn bản
  viện dẫn, đối chiếu kho 01–02 và chuỗi văn bản đã thay thế; không tự kết luận hết hiệu lực khi thiếu nguồn.

## 0.6.0 — 2026-09-19

- **Skill mới `the-thuc`** + Nguyên tắc 6 (`DL-20260919-003`): mọi sản phẩm .docx/.xlsx đạt chuẩn thể thức theo
  `03-Templates(1)`/`04-Good-Documents` (A4, lề 2-2-3-2 cm, Times New Roman 14, phần đầu UBND TỈNH QUẢNG NGÃI –
  TRƯỜNG CAO ĐẲNG KON TUM); chồng lên skill `docx`/`xlsx`. Công cụ `kiem_the_thuc.py` (đo + `--tao` từ mẫu).
- **Hook mới** `ktc_the_thuc_hook.py` (PostToolUse): tự đo .docx/.xlsx vừa sinh trong dự án KTC, còn Mức 1–2 → báo để sửa.
- 6 skill: quan-tri 1.8 · ke-hoach 3.9 · theo-doi-cv 1.7 · bao-cao 3.14 · soan-thao-vb 1.9 · the-thuc 1.0.

## 0.5.4 — 2026-09-19

- soan-thao-vb 1.8: bỏ bản sao `Mau-Prompt-Chinh-Thuc-Ra-Soat-897.docx` (không giữ bản sao quy tắc 897). Dọn hệ: gói/plugin cũ và kết quả chạy thử tháng 7–8 vào `99-Luu-Tru`.

## 0.5.3 — 2026-09-19

- Quy tắc viện dẫn văn bản (`DL-20260919-002`): `17-Quy-Tac-Vien-Dan.md` (NĐ 30 · Pháp lệnh hợp nhất Điều 4 · quy ước
  Trường qua 897) + Nguyên tắc 5. Văn bản hành chính: Luật/Pháp lệnh **không ghi số hiệu**, kể cả khi có VBHN. Công cụ
  tự kiểm `kiem_vien_dan.py` (VD01–VD12). 5 skill: quan-tri 1.7 · ke-hoach 3.8 · theo-doi-cv 1.6 · bao-cao 3.13 ·
  soan-thao-vb 1.7.

## 0.5.2 — 2026-09-19

- Nguyên tắc 3 (`DL-20260919-001`): đơn vị gửi dữ liệu thô vào khung chat, skill xuất sản phẩm trong phiên/project,
  người dùng tải về gửi P-THHC. Tên tệp trả về chuẩn `<mã đơn vị>_<loại>_<kỳ>_v<N>` + phiếu tự kiểm (còn lỗi →
  "chưa nên gửi"). 5 skill: quan-tri 1.6 · ke-hoach 3.7 · theo-doi-cv 1.5 · bao-cao 3.12 · soan-thao-vb 1.6.

## 0.5.1 — 2026-09-18

- Đính chính `DL-20260918-005`: chỉ bản chép KTC-Database trên máy bị xóa (đã cũ: thiếu 163/1.171 tệp). Skill/script
  đọc **bản gốc trên Google Drive** (`duong_dan.py` dò ổ Drive). 5 skill: quan-tri 1.5 · ke-hoach 3.6 · theo-doi-cv 1.4 ·
  bao-cao 3.11 · soan-thao-vb 1.5. C12 so kích thước trước, không tải cả kho từ Drive.

## 0.5.0 — 2026-09-18

- **Nguyên tắc 4** (`DL-20260918-005`) nhân xuống 5 skill: quan-tri 1.4 · ke-hoach 3.5 · theo-doi-cv 1.3 · bao-cao 3.10 ·
  soan-thao-vb 1.4. Mỗi loại đầu vào một nơi lưu; tìm KTC-Database qua `KTC_DATABASE_DIR` → thư mục ngang cấp →
  Google Drive → hỏi (không ghi cứng ổ đĩa — dự án sẽ chỉ còn trên Google Drive); quy tắc làm việc trên Drive.
- `ke-hoach`: `10-Dau-Vao/02-Cap-Truong/<nhóm kỳ>/<kỳ>/` (01-Nam/02-Quy/03-Thang/04-Chuyen-De); văn bản cấp trên
  đọc tại `KTC-Database/01-Legal-Database/` (bỏ nhánh `04-Van-Ban-Cap-Tren`).

## 0.4.1 — 2026-09-18

- `quan-tri` 1.3: sửa chỉ mục KTC-Database — `12-Output` của kho bị đổi nhầm thành `30-Ket-Qua` trong đợt
  kết cấu thư mục (`DL-20260918-004`). Rà toàn bộ diff đợt đó: chỉ 1 chỗ nhầm.

## 0.4.0 — 2026-09-18

- Kết cấu lại thư mục dự án theo nhóm INPUT (1x) / PROCESS (2x) / OUTPUT (3x) / quản trị hệ (9x)
  (`DL-20260918-004`). Bản dựng plugin nay ở `31-Plugin/`; nguồn hook/agent ở `29-Cong-Cu/plugin_src/`.
- 5 skill đóng gói lại: quan-tri 1.2 · ke-hoach 3.4 · theo-doi-cv 1.2 · bao-cao 3.9 · soan-thao-vb 1.3 — thêm
  **Nguyên tắc 3**: tài khoản Team (phòng/khoa/bộ môn) không có thư mục dự án → lấy đầu vào từ tệp đính kèm
  trong phiên, trả kết quả để tải về.
- Hook nhật ký nhận diện dự án qua `90-Nhat-Ky-Van-Hanh/`; ở máy thành viên không có thư mục này → không ghi.

## 0.3.0 — 2026-09-18

- `bao-cao` nâng lên **v3.8** (gói `ktc-bao-cao-v3.8.skill`): đọc cột `Task_ID` (KI-001, Lãnh đạo thống nhất,
  `DL-20260918-003`); sửa lỗi nhiệm vụ "Tổng hợp/Tổng kết…" bị bỏ mất. `quan-tri`: cập nhật quy tắc Task_ID.

## 0.2.2 — 2026-09-18

- Sửa lỗi nhật ký: khi hook báo thư mục làm việc nằm ngoài dự án, script vẫn lùi về thư mục đang chạy và
  ghi nhầm vào nhật ký KTC-Quan-tri (phát hiện qua dòng "Write a" do kiểm thử sinh ra). Nay chỉ lùi về khi
  hook không báo thư mục nào. Không ghi dòng rỗng khi dữ liệu hook hỏng.
- Hồi quy thêm ca ngược: chạy kiểm thử từ chính thư mục dự án và kiểm nhật ký thật không đổi (ca này thất bại
  với bản cũ, đạt với bản mới). Đã dọn 10 dòng rác khỏi nhật ký 18/9.

## 0.2.1 — 2026-09-18

- Thư mục dữ liệu nền đổi tên `KTC-Du-lieu-Cong-Viec` → `Du-lieu-Cong-Viec` (yêu cầu người dùng; commit `b8297f7`; nay là
  `11-Du-lieu-Cong-Viec` từ 0.4.0 — dòng này từng bị lần thay tên hàng loạt ở 0.4.0 ghi đè cả hai vế, sửa lại 25/9/2026). Cập nhật
  mọi tham chiếu còn hiệu lực (CLAUDE.md, README, 20-Chuan-Chung, references, agent); đóng gói lại
  `ktc-quan-tri.skill` từ nguồn rời. Hồ sơ lịch sử trong `30-Ket-Qua/` giữ nguyên tên cũ.
- `Claude outputs/` (tệp ứng dụng Claude xuất ra) đưa vào `.gitignore` — không lên backup GitHub.

## 0.2.0 — 2026-09-18

Thêm 3 cơ chế theo yêu cầu người dùng. Nguồn viết tay ở `29-Cong-Cu/plugin_src/` (script build chép vào, không sửa
trong `31-Plugin/`). Hồi quy: `92-Kinh-Nghiem/02-Regression/Cases/test_plugin_nhat_ky_backup.py` — 10 ca, có ca ngược.

- **Agent `ktc-tu-cai-tien`** (`agents/`): đọc nhật ký tự động, Process Memory, Known Issues, Decision Log, kết
  quả `kiem_tra_he_thong.py` → viết đề xuất `CP-YYYYMMDD-NNN` trạng thái *Chờ duyệt* vào
  `92-Kinh-Nghiem/03-Change-Proposals/`. **Không tự sửa** skill/quy tắc/dữ liệu (nguyên tắc bất biến #6);
  bị chặn công cụ `Edit`.
- **Tự ghi nhật ký + nạp vào context** (`scripts/ktc_nhat_ky.py`): `PostToolUse` ghi 1 dòng JSONL cho mỗi
  Write/Edit/Bash/PowerShell/Skill/Agent vào `90-Nhat-Ky-Van-Hanh/04-Nhat-Ky-Tu-Dong/YYYY-MM-DD.jsonl` (chỉ
  tên công cụ + đối tượng, **không** ghi nội dung tệp); `SessionStart` in tóm tắt 2 ngày gần nhất vào
  context; `SessionEnd` đánh dấu kết thúc phiên. Chỉ hoạt động trong thư mục KTC-Quan-tri.
- **Tự backup GitHub** (`scripts/ktc_backup_github.py`): commit + push thường (không force), Task Scheduler
  21:00 hằng ngày (`KTC-Quan-tri-Backup-GitHub`, chạy bù khi máy bật lại) + `SessionStart` chạy bù nếu quá
  24h. Dừng nếu có tệp tên giống bí mật. **Chưa nối remote** — cần người dùng cung cấp URL repo private.

## 0.1.1 — 2026-09-18

- `ktc-soan-thao-vb` nâng lên **v1.2** ở nguồn (gói `.skill` gốc, không chỉ trong plugin): thêm hẳn
  `14-Nguyen-Tac-Soan-Thao-Bat-Bien.md`, `15-Skill-Track-Changes.md`, `ktc_trackchanges.py` vào
  `references/Skill-Library/` của chính hệ đó, sửa 3 trích dẫn trong `SKILL.md` trỏ đúng vị trí trong gói
  (`references/Skill-Library/...`, không còn cần `${CLAUDE_PLUGIN_ROOT}`).
- `29-Cong-Cu/dong_goi_plugin.py` bỏ hàm vá riêng cho plugin (`vas_lo_hong_soan_thao_vb`) — không còn cần vì đã
  sửa tận gốc; script build lại đơn giản như 4 hệ còn lại (giải nén thuần túy, không vá thêm).
- Sửa lỗi build script: `don_sach()` từng xoá cả `README.md`/`CHANGELOG.md` viết tay ở gốc `31-Plugin/` vì dọn
  nguyên thư mục gốc — nay chỉ dọn các thư mục sinh tự động (`skills/`, `.claude-plugin/`, `hooks/`,
  `scripts/`), giữ nguyên tài liệu viết tay.
- Kiểm lại: 0 lỗi, 0 tệp thiếu/thừa so với 5 gói `.skill` nguồn, không còn tham chiếu
  `${CLAUDE_PLUGIN_ROOT}` nào trong toàn bộ 5 SKILL.md.

## 0.1.0 — 2026-09-18

Bản đầu tiên. Gộp 5 hệ KTC (quan-tri, bao-cao, ke-hoach, soan-thao-vb, theo-doi-cv) thành một plugin dùng
chung cho Cowork và Claude Code, thay vì 5 gói `.skill` rời.

- Dựng từ 5 gói `.skill` đã xác minh byte-for-byte cùng ngày (`DL-20260918-001`): `ktc-quan-tri.skill`,
  `ktc-bao-cao-v3.7.skill`, `ktc-ke-hoach-v3.3.skill`, `ktc-soan-thao-vb-v1.1.skill`,
  `ktc-theo-doi-cv-v1.1.skill`.
- Phát hiện 3 lỗ hổng tham chiếu có thật trong `ktc-soan-thao-vb` (tồn tại từ trước, không liên quan lần
  đóng gói này) và vá tạm riêng cho plugin. **Đã thay bằng bản sửa tận gốc ở 0.1.1**, xem mục trên.
- Hook `SessionStart` mới: `scripts/ktc_quan_tri_doctor.py` — in phiên bản tự khai của cả 5 skill.
- Chưa chạy `claude plugin validate --strict` (không có CLI trong môi trường dựng) — chỉ tự kiểm thủ công.
