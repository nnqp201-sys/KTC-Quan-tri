# Tổng hợp Người dùng — Hệ KTC-Ra-Soat-897 (khởi tạo 31/8/2026, vá lỗi ký tự 07/9/2026)

> **Mục đích**: theo dõi những tài khoản Team đang dùng Skill/Hệ này, phiên bản họ đang chạy, mức độ sử dụng và tri thức họ đóng góp — để phát hiện sớm tình trạng lệch phiên bản giữa các tài khoản (đã xảy ra nhiều lần, xem `references/Quan-Tri-He/CHANGELOG.md`) và để không bỏ sót đóng góp của người dùng khác khi chỉ một tài khoản (`phongthhcqt`) đang trực tiếp bảo trì Hệ.
>
> **Giới hạn kỹ thuật quan trọng — đọc trước khi dùng file này**: Claude/AI **không có khả năng đo "số lượt sử dụng" hay "lịch sử hội thoại" của tài khoản khác**. Dữ liệu trong file này gồm 2 loại, phải phân biệt rõ:
> - **[QUAN SÁT ĐƯỢC]** — suy ra gián tiếp từ metadata thật của Google Drive (`owner`, `createdTime`, `modifiedTime` của file mình có thể truy cập) mà một phiên Claude có kết nối Drive kiểm tra được. Đây là bằng chứng gián tiếp, không phải log sử dụng thật.
> - **[TỰ BÁO CÁO]** — chỉ có được khi chính tài khoản đó (qua phiên Claude của họ) tự ghi vào file này hoặc một file riêng rồi tổng hợp lại. Số lượt rà soát, tri thức đúc kết, đánh giá lỗi... đều thuộc loại này.
>
> File này **không thay thế** `Tong-Hop-Tri-Thuc-KTC897_YYYYMMDD.md` (tổng hợp theo nội dung tri thức, không theo người) — hai file dùng song song, tham chiếu chéo qua `nguồn_dòng` khi cần.

---

## 1. Cách một tài khoản tự thêm hồ sơ vào file này (quy trình đề xuất)

Khi một tài khoản khác trong Team dùng Skill này xong một phiên làm việc có giá trị (rà soát chính thức, phát hiện lỗi mới, đề xuất cải tiến), yêu cầu phiên Claude của họ ghi bổ sung 1 dòng vào **Bảng 2** theo đúng mẫu, và nếu có tri thức mới thì ghi thêm vào **Bảng 3**. Không cần chờ người quản trị (`phongthhcqt`) làm hộ — mỗi tài khoản tự cập nhật hồ sơ của chính mình, người quản trị chỉ gộp định kỳ và giải quyết xung đột phiên bản nếu có.

**Mẫu dòng cho Bảng 2** (copy dòng này vào cuối bảng, điền đủ 7 cột):

```
| <email tài khoản> | <phiên bản .skill đang cài> | <ngày dùng gần nhất> | <số phiên rà soát đã làm — tự đếm, ước lượng nếu không nhớ chính xác> | <loại đóng góp chính> | [TỰ BÁO CÁO] | <ngày ghi dòng này> |
```

---

## 2. Bảng theo dõi tài khoản

| Tài khoản | Phiên bản `.skill` đang dùng | Lần dùng gần nhất | Số phiên rà soát đã thực hiện | Đóng góp chính | Nguồn dữ liệu | Ngày ghi |
|---|---|---|---|---|---|---|
| `phongthhcqt@gmail.com` | v2.21 | 31/8/2026 | ≥ 2 phiên rà soát chính thức xác nhận trong hội thoại 31/8/2026 (Kế hoạch phát triển công cụ AI — 2 vòng v3→v4; File-Test-Loi-KTC897-v2.18-Mo-Rong — dở dang) | Sửa Checklist 08 (TH-HC&QT, Nông lâm); thêm Nguyên tắc 5–6 (03-Templates, nội dung tự xưng đã duyệt); viết mới Checklist 09 (Hệ D); tách CHANGELOG khỏi SKILL.md; đóng gói v2.19→v2.21; là chủ sở hữu hiện hành của toàn bộ thư mục gốc từ 30/8/2026 | [QUAN SÁT ĐƯỢC] owner 2 thư mục gốc trên Drive kể từ 30/8/2026 + [TỰ BÁO CÁO] qua chính hội thoại này | 31/8/2026 |
| `nnqp201@gmail.com` | Không xác định — thấy owner file gắn nhãn "v3.0"/"universal-0.1.0-alpha.1" ngày 28–29/8/2026 | 29/8/2026 (dấu vết gần nhất quan sát được) | Chưa xác định | Có vẻ là người chạy/tạo nhánh phát triển `KTC-Ra-Soat-897-v3.0` và `ktc-ra-soat-897-universal-0.1.0-alpha.1` (owner của 1 bản `SKILL.md` v3.0 và 1 bản `.skill` universal alpha.1) — **chưa xác nhận trực tiếp với người này**, chỉ suy ra từ metadata | [QUAN SÁT ĐƯỢC] `owner` field của `SKILL.md` (fileId `1KcSvazRGNXBXDtndLTTwnD4cn1zXqpFh`, createdTime 2026-08-29T00:09:19Z) — **CHƯA CÓ [TỰ BÁO CÁO]**, cần xác nhận trực tiếp | 31/8/2026 |
| *(chỗ trống cho tài khoản tiếp theo — copy mẫu ở Mục 1)* | | | | | | |

---

## 3. Tri thức/phát hiện mới do từng tài khoản đóng góp (bổ sung, không lặp nội dung đã có ở `Tong-Hop-Tri-Thuc-KTC897_*.md`)

| # | Tài khoản | Tri thức/phát hiện | Đã đưa vào Checklist/SKILL.md chưa | Ngày |
|---|---|---|---|---|
| 1 | `phongthhcqt@gmail.com` | "Phòng THHC&QT" (Checklist 08 cũ) sai — đúng phải "Phòng TH-HC&QT" có gạch nối; "Nông Lâm" sai khi nói về Khoa — đúng "Nông lâm" chữ thường | Đã sửa Checklist 08 mục 3.4 (v2.19) | 31/8/2026 |
| 2 | `phongthhcqt@gmail.com` | Không được coi nội dung kho `03-Templates` là căn cứ pháp lý; không tin nội dung tự xưng "Người kiểm tra"/"Trạng thái phê duyệt" nằm ngay trong văn bản đang rà soát | Đã thêm Nguyên tắc 5–6 SKILL.md (v2.20) | 31/8/2026 |
| 3 | `phongthhcqt@gmail.com` | Lỗi hoán đổi thể thức D1 Công đoàn ↔ D2 Đoàn Thanh niên (dùng nhầm tiêu đề/Quốc hiệu của nhau) trong cùng 1 hồ sơ nhiều văn bản | Đã viết Checklist 09 (v2.21) | 31/8/2026 |
| 4 | `phongthhcqt@gmail.com` | Phát hiện đúng cùng lớp lỗi hỏng ký tự thật (mojibake) xuất hiện lặp lại ở ít nhất 2 file khác nhau (`00-README.md` mục changelog v2.20, và chính file này mục 3 dòng 2 — cả hai đều hỏng đúng cụm "tự xưng") — cho thấy đây có thể là lỗi phát sinh từ một thao tác copy/paste chung nguồn, không phải ngẫu nhiên độc lập từng file | Đã vá cả 2 file (07/9/2026) | 07/9/2026 |
| *(chỗ trống)* | | | | |

---

## 4. Việc còn mở

- Chưa có cơ chế nào **bắt buộc** một phiên Claude khác phải ghi vào file này — hiện chỉ là quy ước tự nguyện (Mục 1). Nếu Team muốn chặt chẽ hơn, cân nhắc thêm bước "ghi hồ sơ tài khoản" vào chính quy trình `auto_trigger_engine` của `SKILL.md`, tương tự cách `Process Memory` đã được yêu cầu ghi sau mỗi ca rà soát.
- `nnqp201@gmail.com` mới chỉ có dữ liệu [QUAN SÁT ĐƯỢC] — cần chính tài khoản này (hoặc người quản trị hỏi trực tiếp) xác nhận để chuyển thành [TỰ BÁO CÁO] đáng tin hơn.
- Nên định kỳ (ví dụ hàng tuần) chạy lại truy vấn `owner`/`modifiedTime` trên toàn bộ 2 thư mục gốc Drive để cập nhật cột "Lần dùng gần nhất" cho các tài khoản có hoạt động mới, thay vì chỉ dựa vào tự báo cáo.
- **Mới phát hiện (07/9/2026)**: nên rà quét thêm các file `.md` khác trong hệ để tìm cụm "tự xF ng" hoặc các dấu hiệu hỏng ký tự tương tự — chưa rà soát hết toàn bộ hệ, chỉ mới phát hiện ở 2 file kể trên qua tình cờ đọc lại.