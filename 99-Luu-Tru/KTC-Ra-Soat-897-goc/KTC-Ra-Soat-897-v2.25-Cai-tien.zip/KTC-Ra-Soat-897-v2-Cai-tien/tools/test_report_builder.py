"""Hồi quy các chốt an toàn của ReportBuilder."""

from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from build_ktc897_report import ReportBuilder


with TemporaryDirectory(prefix="ktc897-report-tests-") as tmpdir:
    tmp = Path(tmpdir)
    builder = ReportBuilder("v2.23", "13/9/2026")

    before = len(builder.doc.tables)
    try:
        builder.table(["A", "B"], [], widths=[13, 13])
        raise AssertionError("Bảng 26cm phải bị từ chối")
    except ValueError:
        pass
    assert len(builder.doc.tables) == before, "ValueError đã để lại bảng rỗng"

    docx_path = tmp / "bao_cao.docx"
    pdf_path = tmp / "bao_cao.pdf"
    marker = b"PDF-CUA-NGUOI-DUNG"
    pdf_path.write_bytes(marker)
    builder.footer_pages()
    builder.save(docx_path)

    assert pdf_path.read_bytes() == marker, "PDF cùng tên đã bị ghi đè hoặc xóa"
    with ZipFile(docx_path) as archive:
        assert archive.testzip() is None
        assert "word/document.xml" in archive.namelist()

print("PASS - width guard không làm bẩn document; PDF cùng tên được bảo toàn; DOCX hợp lệ")
