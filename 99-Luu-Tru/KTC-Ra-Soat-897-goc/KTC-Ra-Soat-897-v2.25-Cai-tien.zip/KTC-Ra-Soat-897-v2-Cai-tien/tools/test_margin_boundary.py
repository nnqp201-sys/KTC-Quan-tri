"""Test case bắt buộc theo LỆNH 6 bước 3: xác nhận 2 giá trị biên KHÔNG bị flag sai,
đồng thời vẫn bắt đúng lỗi thật khi lề sai thực sự (kiểm chứng ngược)."""
from docx import Document
from docx.enum.section import WD_SECTION
from docx.shared import Mm, Pt
from _read_input_properties import read_input_properties
from pathlib import Path
from tempfile import TemporaryDirectory

with TemporaryDirectory(prefix="ktc897-tests-") as tmpdir:
    tmp = Path(tmpdir)

    # Test 1: lề phải chính xác = 20.0mm (biên TRÊN của khoảng 15-20mm)
    doc1 = Document()
    sec1 = doc1.sections[0]
    sec1.top_margin = Mm(22)
    sec1.bottom_margin = Mm(22)
    sec1.left_margin = Mm(32)
    sec1.right_margin = Mm(20)
    path1 = tmp / "test_right_20mm.docx"
    doc1.save(path1)

    # Test 2: lề trái chính xác = 30.0mm (biên DƯỚI của khoảng 30-35mm)
    doc2 = Document()
    sec2 = doc2.sections[0]
    sec2.top_margin = Mm(22)
    sec2.bottom_margin = Mm(22)
    sec2.left_margin = Mm(30)
    sec2.right_margin = Mm(18)
    path2 = tmp / "test_left_30mm.docx"
    doc2.save(path2)

    print("=== TEST 1: Lề phải = 20.0mm (biên trên 15-20mm) ===")
    findings1 = read_input_properties(path1)
    right_flags = [f for f in findings1 if f["thanh_phan"] == "Lề right"]
    assert len(right_flags) == 0, f"FAIL: lề phải 20.0mm bị flag sai! {right_flags}"
    print("PASS - lề phải 20.0mm KHÔNG bị flag (đúng)")

    print("\n=== TEST 2: Lề trái = 30.0mm (biên dưới 30-35mm) ===")
    findings2 = read_input_properties(path2)
    left_flags = [f for f in findings2 if f["thanh_phan"] == "Lề left"]
    assert len(left_flags) == 0, f"FAIL: lề trái 30.0mm bị flag sai! {left_flags}"
    print("PASS - lề trái 30.0mm KHÔNG bị flag (đúng)")

    print("\n=== TEST 3: bắt lỗi thật ở nhiều section và trong bảng ===")
    doc3 = Document()
    sec3 = doc3.sections[0]
    sec3.top_margin = Mm(22); sec3.bottom_margin = Mm(22)
    sec3.left_margin = Mm(20); sec3.right_margin = Mm(20)
    sec4 = doc3.add_section(WD_SECTION.NEW_PAGE)
    sec4.top_margin = Mm(22); sec4.bottom_margin = Mm(22)
    sec4.left_margin = Mm(32); sec4.right_margin = Mm(25)
    p = doc3.add_table(rows=1, cols=1).cell(0, 0).paragraphs[0]
    run = p.add_run("Về việc kiểm thử định dạng")
    run.font.size = Pt(12)
    run.font.bold = False
    path3 = tmp / "test_multi_section_table.docx"
    doc3.save(path3)
    findings3 = read_input_properties(path3)
    assert any(f["thanh_phan"] == "Lề left" for f in findings3)
    assert any(f["thanh_phan"] == "Lề right (phần 2)" for f in findings3)
    assert any(f["thanh_phan"].startswith("Trích yếu") for f in findings3)
    print("PASS - bắt được section sau và run trong ô bảng")

print("\n=== TẤT CẢ TEST PASS; không để lại fixture ở thư mục gốc ===")
