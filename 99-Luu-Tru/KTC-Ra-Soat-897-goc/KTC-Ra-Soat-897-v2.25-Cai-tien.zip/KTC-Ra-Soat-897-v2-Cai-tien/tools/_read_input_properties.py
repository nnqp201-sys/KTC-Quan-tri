"""
_read_input_properties.py — v1.2 (13/9/2026)
Hàm đọc thuộc tính định dạng THẬT của file .docx đầu vào (không phải file report tự tạo).
Dùng để vá lỗ hổng đã xác nhận: build_ktc897_report.py / run_review.py trước đây chỉ đọc
paragraph.text / table, không bao giờ đọc section.*_margin hay run.font.size của file đầu vào
=> mọi lỗi định lượng (lề, cỡ chữ, kiểu chữ) chắc chắn bị bỏ sót.

Cách dùng:
    from _read_input_properties import read_input_properties
    findings = read_input_properties("File-Test-Loi-KTC897.docx")
    for f in findings:
        print(f["muc"], f["thanh_phan"], f["mo_ta"])

GHI CHÚ SỬA LỖI v1.1 (26/8/2026, LỆNH 6):
Bug xác nhận: python-docx quy đổi Cm/Mm → giá trị mm có sai số dấu phẩy động
(ví dụ lề đúng 20.0mm có thể trả về 20.0025mm hoặc tương tự do làm tròn EMU nội bộ).
Với so sánh "val > rule['max']" thô, giá trị đúng biên (20.0mm cho lề phải,
30.0mm cho lề trái) có thể bị báo sai (false positive).

Đã sửa CẢ 4 LỀ (trên/dưới/trái/phải dùng CHUNG một hàm _margin_findings, không
phải 4 đoạn code riêng — xác nhận qua đọc code: chỉ có 1 vòng lặp for over
ND30_MARGIN_MM.items(), nên sửa 1 chỗ áp dụng cho cả 4).

Áp dụng CẢ HAI biện pháp theo đúng LỆNH 6, không chỉ epsilon đơn thuần:
  a. round(val, 1) trước khi so sánh — giá trị mm chỉ cần chính xác 1 chữ số
     thập phân theo NĐ 30.
  b. Giữ thêm EPS = 0.01 khi so sánh khoảng, để an toàn kép (double-guard).

Đã kiểm thử với 2 test case bắt buộc theo LỆNH 6 bước 3:
  - File có lề phải chính xác = 20.0mm (biên trên khoảng 15-20mm) → không bị flag.
  - File có lề trái chính xác = 30.0mm (biên dưới khoảng 30-35mm) → không bị flag.
Cả hai xác nhận PASS — xem test_margin_boundary.py cùng thư mục.

Vá v1.2: đọc lề của mọi section và duyệt run trong thân văn bản, bảng, header, footer.
"""

from docx import Document
from docx.shared import Mm, Pt

EPS = 0.01  # dung sai an toàn kép theo LỆNH 6 bước 2b


# ===== Ngưỡng đối chiếu — NĐ 30/2020/NĐ-CP Phụ lục I (văn bản hành chính, A4 dọc) =====
ND30_MARGIN_MM = {
    "top":    {"min": 20, "max": 25},
    "bottom": {"min": 20, "max": 25},
    "left":   {"min": 30, "max": 35},
    "right":  {"min": 15, "max": 20},
}

# ===== Ngưỡng đối chiếu — TB 597/TB-CĐKT mục 4 (một số thành phần thường gặp) =====
TB597_RUN_RULES = [
    {"match_prefix": "về việc", "expect_size_pt": 14, "expect_bold": True,  "label": "Trích yếu (có tên loại văn bản)"},
    {"match_prefix": "quốc hiệu", "expect_size_pt": 13, "expect_bold": True, "label": "Quốc hiệu"},
]


def _margin_findings(doc, path):
    """Áp dụng CHUNG cho cả 4 lề (top/bottom/left/right) — cùng 1 vòng lặp,
    nên bản vá round(val,1) + EPS tự động có hiệu lực cho cả 4, không cần
    sửa 4 chỗ riêng biệt (đã xác nhận qua đọc code: chỉ 1 điểm so sánh)."""
    findings = []
    if not doc.sections:
        return findings
    for sec_idx, sec in enumerate(doc.sections, start=1):
        actual = {
            "top": sec.top_margin.mm if sec.top_margin is not None else None,
            "bottom": sec.bottom_margin.mm if sec.bottom_margin is not None else None,
            "left": sec.left_margin.mm if sec.left_margin is not None else None,
            "right": sec.right_margin.mm if sec.right_margin is not None else None,
        }
        for side, rule in ND30_MARGIN_MM.items():
            val = actual[side]
            if val is None:
                continue
            val_rounded = round(val, 1)
            if val_rounded < rule["min"] - EPS or val_rounded > rule["max"] + EPS:
                suffix = "" if sec_idx == 1 else f" (phần {sec_idx})"
                findings.append({
                    "muc": 1,
                    "thanh_phan": f"Lề {side}{suffix}",
                    "mo_ta": f"Lề {side} phần {sec_idx} = {val_rounded:.1f}mm, ngoài khoảng cho phép {rule['min']}-{rule['max']}mm (Phụ lục I NĐ 30/2020/NĐ-CP)",
                    "gia_tri_thuc_te": val_rounded,
                    "gia_tri_dung": f"{rule['min']}-{rule['max']}mm",
                    "nguon_file": path,
                })
    return findings


def _iter_paragraphs(doc):
    """Duyệt đoạn ở thân, bảng, header và footer; tránh lặp phần liên kết."""
    seen_parts = set()

    def walk(container, location):
        for index, paragraph in enumerate(container.paragraphs):
            yield paragraph, f"{location}, đoạn {index + 1}"
        for table_index, table in enumerate(container.tables):
            for row_index, row in enumerate(table.rows):
                for cell_index, cell in enumerate(row.cells):
                    yield from walk(
                        cell,
                        f"{location}, bảng {table_index + 1}, dòng {row_index + 1}, ô {cell_index + 1}",
                    )

    yield from walk(doc, "thân văn bản")
    for sec_index, section in enumerate(doc.sections, start=1):
        for kind, part in (("header", section.header), ("footer", section.footer)):
            key = id(part._element)
            if key not in seen_parts:
                seen_parts.add(key)
                yield from walk(part, f"{kind} phần {sec_index}")


def _run_findings(doc, path):
    """Duyệt toàn bộ đoạn văn, đối chiếu font.size/bold của các run so với TB597_RUN_RULES
    khi đoạn văn khớp một mẫu nhận diện (match_prefix)."""
    findings = []
    for para, location in _iter_paragraphs(doc):
        text_lower = para.text.strip().lower()
        if not text_lower:
            continue
        for rule in TB597_RUN_RULES:
            if text_lower.startswith(rule["match_prefix"]):
                for run in para.runs:
                    if not run.text.strip():
                        continue
                    actual_size = run.font.size.pt if run.font.size is not None else None
                    actual_bold = bool(run.font.bold)
                    problems = []
                    if actual_size is not None and actual_size != rule["expect_size_pt"]:
                        problems.append(f"cỡ chữ thực tế {actual_size}pt, phải {rule['expect_size_pt']}pt")
                    if rule["expect_bold"] and not actual_bold:
                        problems.append("thiếu định dạng đậm (bold)")
                    if problems:
                        findings.append({
                            "muc": 3,
                            "thanh_phan": rule["label"],
                            "mo_ta": f"{location} ('{para.text[:40]}...'): " + "; ".join(problems) + " (TB 597/TB-CĐKT mục 4)",
                            "nguon_file": path,
                        })
                break
    return findings


def read_input_properties(docx_path):
    """Trả về danh sách phát hiện (list[dict]) từ việc đọc thuộc tính XML thật của file .docx đầu vào."""
    doc = Document(docx_path)
    findings = []
    findings.extend(_margin_findings(doc, docx_path))
    findings.extend(_run_findings(doc, docx_path))
    return findings


if __name__ == "__main__":
    import sys, json
    path = sys.argv[1] if len(sys.argv) > 1 else "File-Test-Loi-KTC897.docx"
    result = read_input_properties(path)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print(f"\n=> Tổng {len(result)} phát hiện từ thuộc tính định dạng thật (không tính lỗi nội dung chữ).")
