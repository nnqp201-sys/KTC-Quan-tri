"""
build_ktc897_report.py — v3.6 (29/9/2026)
Script CHÍNH THỨC DUY NHẤT xuất Báo cáo rà soát KTC-897 (.docx).

Vá trong v3.6 — phát hiện bằng cách CHẠY THẬT script rồi đọc lại .docx bằng python-docx
(không phải đọc code): trường "Người kiểm tra" trong bảng THÔNG TIN TRÁCH NHIỆM đang mở đầu
bằng tên công cụ AI — "Hệ KTC-Ra-Soat-897-v2-Cai-tien (v2.25, ...)" — vi phạm thẳng quy tắc
bắt buộc "Người kiểm tra KHÔNG được điền tên công cụ AI, phải là người thật chịu trách nhiệm".
Nghịch lý là chính docstring của hàm thong_tin_trach_nhiem() đã nhắc đúng quy tắc đó, nhưng
thân hàm lại tự ghép tên Hệ vào. Xử lý:
  - "Người kiểm tra" nay CHỈ còn tên người + chức danh do người gọi truyền vào.
  - Tên Hệ + phiên bản + ngày chạy chuyển sang trường "Nguồn dữ liệu đã dùng" — vẫn truy vết
    đủ công cụ nào tạo ra báo cáo, mà không mạo danh người kiểm tra.
  - Footer mọi trang vẫn in phiên bản Skill như cũ, không đổi.

Vá trong v3.5:
  - Kiểm tra width trước khi thêm bảng, tránh để lại bảng rỗng khi phát sinh ValueError.
  - Render PDF đếm trang trong thư mục tạm riêng, không đụng tệp PDF cùng tên của người dùng.
  - CLI sinh khung báo cáo đầy đủ thay vì chỉ có trang đầu; Phần VIII điều khiển bằng --include-risk.

Vá trong v3.4 — phát hiện qua tự kiểm định trực tiếp (không phải suy đoán):
  - Thêm kiểm tra THẬT (raise ValueError) khi tổng độ rộng bảng vượt 25.7cm — trước đó chỉ có
    dòng chú thích nhắc nhở, không có gì thực sự chặn lại. Xác nhận thật: 3/5 bảng trong chính
    file mẫu gốc (Mau_Bao_cao_ra_soat_KTC897_8phan.docx) đã vượt nhẹ khổ giấy (25.8-26.0cm).
  - Giảm độ rộng cứng trong bang_2cot() từ đúng biên 25.7cm xuống 25.5cm — tránh vỡ do sai số
    làm tròn EMU/Cm nội bộ của Word (đã từng gặp đúng kiểu lỗi này với ngưỡng lề trang).
  - Thêm _fix_app_xml_metadata(): tự tính lại Pages/Words/Paragraphs/Characters thật (render PDF
    thật để đếm trang, không đoán) rồi ghi vào docProps/app.xml sau khi lưu — trước đó python-docx
    để mặc định Pages=1/Words=0, khiến một số trình xem hiển thị sai "chỉ có 1 trang".
  - Vá luôn lỗi schema thật: <w:zoom> trong settings.xml thiếu thuộc tính w:percent bắt buộc.
  Cả 4 lỗi trên được xác nhận bằng validate.py (skill docx) + chạy thử thật, không chỉ đọc code.

Vá so với v3.0 (25/8/2026) — v3.1 vẫn còn 1 lỗi (xem bên dưới), đã vá tiếp trong v3.2 — phát hiện qua đối chiếu trực tiếp với báo cáo
mẫu thật đã dùng để trình ký (v3__Claude__BC_Ra_Soat_Chinh_Thuc_897_HoSo_
DeAn_v3_1.docx). Bản v3.0 khi hợp nhất 2 nhánh script đã LẤY NHẦM bảng màu
từ nhánh build_tcdm_review_fixed.py thay vì giữ đúng bảng màu gốc trích từ
template .dotx chuẩn. Đã sửa lại đúng theo bằng chứng trong file mẫu:

  - Heading 1 (PHẦN I..VIII):      7030A0 (tím)   — v3.0 sai dùng 002060
  - Heading 2 (phụ đề, II.A/II.B): 2E74B5 (xanh)  — v3.0 sai dùng 0000CC
  - Tiêu đề "BÁO CÁO RÀ SOÁT...":  0000FF (xanh)  — v3.0 không đặt màu
  - Nền tiêu đề bảng:              1F497D (navy)  — v3.0 sai dùng D9EAF7
  - Chữ tiêu đề bảng:              trắng (FFFFFF) — v3.0 không đặt màu
  - Ô "Đạt":                       nền C6EFCE     — v3.0 THIẾU logic này
  - Dòng "Phản hồi:" trong ô KIẾN NGHỊ: đỏ FF0000 — v3.0 THIẾU tính năng này

Vá thêm trong v3.2 — phát hiện qua góp ý trực tiếp của người dùng:
  - Giá trị "Đơn vị soạn thảo:" và "Thẩm quyền:" ở trang đầu bị viết
    thường chữ cái đầu (vi phạm Checklist 08 mục 3.1: bắt buộc viết
    hoa ngay sau dấu hai chấm). Thêm hàm _cap_first() tự động viết hoa
    chữ cái đầu, áp dụng cho các trường luôn đứng sau dấu hai chấm:
    "Đơn vị soạn thảo: ", "Thẩm quyền: ", và dòng "Phản hồi: " trong
    ô KIẾN NGHỊ. Không tự sửa các chữ khác trong chuỗi, chỉ chữ đầu.

Vá thêm trong v3.3 — phát hiện qua tự rà soát lại chính script:
  - Phương thức dựng "Thông tin trách nhiệm" (3 trường bắt buộc theo
    Nguyên tắc 2, 00-Nguyen-Tac-Chung.md) đã BỊ RƠI MẤT khi viết lại
    v3.1/v3.2 so với bản gốc v2.10. Thêm lại bang_2cot() (bảng 2 cột
    dùng chung cho PHẦN I và Thông tin trách nhiệm) và
    thong_tin_trach_nhiem(), tuân thủ quy tắc đúc kết từ vận hành thực
    tế: "Người kiểm tra" không được ghi CHỈ tên công cụ AI — bắt buộc
    có tên người + chức danh cụ thể đi kèm. Script in cảnh báo ra
    stdout nếu bị gọi thiếu tên người chịu trách nhiệm.

RÀNG BUỘC BẢNG (giữ nguyên từ v3.0, đã kiểm thử thật 25/8/2026):
  Phải đặt t.autofit=False VÀ khai w:tblLayout type="fixed" VÀ ghi w:w
  vào từng w:gridCol. Thiếu bất kỳ bước nào thì Word bỏ qua width,
  bảng co lại ~87% chiều rộng và tài liệu phình từ 8 lên 12 trang.
  Tổng width mỗi bảng <= 25.7cm (A4 ngang 29.7cm trừ lề 20mm mỗi bên).
"""
import argparse
import re
from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Mm, Pt, RGBColor

DEFAULT_OUT_DIR = Path("12-Output")
SKILL_NAME = "KTC-Ra-Soat-897-v2-Cai-tien"

# ── Bảng màu — trích trực tiếp từ báo cáo mẫu đã dùng để trình ký ───────────
C_H1 = (0x70, 0x30, 0xA0)       # 7030A0 tím — Heading 1
C_H2 = (0x2E, 0x74, 0xB5)       # 2E74B5 xanh — Heading 2
C_TITLE = (0x00, 0x00, 0xFF)    # 0000FF xanh dương — tiêu đề báo cáo trang đầu
C_MUC1 = (0xC0, 0x00, 0x00)     # C00000 đỏ đậm — chữ "Mức 1"
C_PHANHOI = (0xFF, 0x00, 0x00)  # FF0000 đỏ tươi — dòng "Phản hồi:" trong ô KIẾN NGHỊ
C_WHITE = (0xFF, 0xFF, 0xFF)
F_HEADER = "1F497D"             # navy đậm — nền tiêu đề bảng
F_PASS = "C6EFCE"               # xanh lá nhạt — nền ô "Đạt"


def _read_skill_version(skill_md_paths=None):
    """Đọc phiên bản + ngày từ SKILL.md/00-README.md tại thời điểm chạy.
    Không hard-code — bảo đảm báo cáo luôn ghi đúng phiên bản hiện hành."""
    candidates = list(skill_md_paths or [])
    script_dir = Path(__file__).resolve().parent
    candidates += [
        script_dir.parent / "SKILL.md",
        script_dir.parent / "00-README.md",
        script_dir / "SKILL.md",
    ]
    pat_ver = [
        r"Phiên bản hiện hành[:\s]*([vV]\d[\d.]+)",
        r"Phiên bản.*?([vV]\d[\d.]+)",
        r"([vV]\d+\.\d+(?:\.\d+)?)\s*[|\u2014\u2013]",
    ]
    pat_ngay = [
        r"[Cc]ập nhật[:\s]*(\d{1,2}/\d{1,2}/\d{4})",
        r"Ngày[:\s]*(\d{1,2}/\d{1,2}/\d{4})",
        r"(\d{1,2}/\d{1,2}/\d{4})",
    ]
    for path in candidates:
        try:
            text = Path(path).read_text(encoding="utf-8")
            ver = ngay = None
            for p in pat_ver:
                m = re.search(p, text)
                if m:
                    ver = m.group(1)
                    break
            for p in pat_ngay:
                m = re.search(p, text)
                if m:
                    ngay = m.group(1)
                    break
            if ver:
                return ver, ngay or datetime.now().strftime("%d/%m/%Y")
        except Exception:
            continue
    return "v2.23", datetime.now().strftime("%d/%m/%Y")


def resolve_output(arg_out, ho_so="ra-soat-chinh-thuc"):
    if arg_out:
        p = Path(arg_out)
    else:
        p = DEFAULT_OUT_DIR / f"Bao_cao_ra_soat_{ho_so}_{datetime.now():%Y%m%d}.docx"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _font(run, size=14, bold=False, italic=False, color=None):
    run.font.name = "Times New Roman"
    pr = run._element.get_or_add_rPr()
    pr.rFonts.set(qn("w:ascii"), "Times New Roman")
    pr.rFonts.set(qn("w:hAnsi"), "Times New Roman")
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    if color:
        run.font.color.rgb = RGBColor(*color)


def _shade(cell, hexfill):
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), hexfill)
    tcPr = cell._tc.get_or_add_tcPr()
    # Lỗi schema thật xác nhận 30/8/2026: append() mù ở cuối đặt w:shd SAU w:tcMar/vAlign đã có
    # sẵn (do _set_cell_margins() có thể chạy trước) — vi phạm thứ tự bắt buộc: ... tcBorders,
    # shd, noWrap, tcMar, textDirection, tcFitText, vAlign, hideMark. Phải chèn TRƯỚC các thẻ đó.
    insert_before = None
    for tag in ("w:noWrap", "w:tcMar", "w:textDirection", "w:tcFitText", "w:vAlign", "w:hideMark"):
        found = tcPr.find(qn(tag))
        if found is not None:
            insert_before = found
            break
    if insert_before is not None:
        insert_before.addprevious(shd)
    else:
        tcPr.append(shd)


def _set_cell_margins(cell, top=60, start=90, bottom=60, end=90):
    tcPr = cell._tc.get_or_add_tcPr()
    mar = OxmlElement("w:tcMar")
    for tag, val in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        el = OxmlElement(f"w:{tag}")
        el.set(qn("w:w"), str(val))
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    # Lỗi schema thật xác nhận 30/8/2026: append() mù ở cuối tcPr đặt tcMar SAU vAlign/hideMark
    # (do cell.vertical_alignment thường được set trước khi gọi hàm này) — vi phạm thứ tự OOXML
    # bắt buộc: ... tcBorders, shd, noWrap, tcMar, textDirection, tcFitText, vAlign, hideMark.
    # Phải chèn tcMar TRƯỚC các thẻ đó nếu đã tồn tại, không được append() tự do ở cuối.
    insert_before = None
    for tag in ("w:textDirection", "w:tcFitText", "w:vAlign", "w:hideMark"):
        existing = tcPr.find(qn(tag))
        if existing is not None:
            insert_before = existing
            break
    if insert_before is not None:
        insert_before.addprevious(mar)
    else:
        tcPr.append(mar)


def _set_tbl_layout_fixed(tbl):
    """Đặt w:tblLayout type=fixed đúng vị trí schema OOXML — không được append() mù ở cuối
    tblPr, vì có thể đứng sau tblCellMar/tblLook đã tồn tại, vi phạm thứ tự bắt buộc và khiến
    Word từ chối mở file (LibreOffice không phát hiện). Xác nhận lỗi thật ngày 30/8/2026."""
    tblPr = tbl.tblPr
    existing = tblPr.find(qn("w:tblLayout"))
    if existing is not None:
        existing.set(qn("w:type"), "fixed")
        return
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    insert_before = None
    for tag in ("w:tblCellMar", "w:tblLook", "w:tblCaption", "w:tblDescription"):
        found = tblPr.find(qn(tag))
        if found is not None:
            insert_before = found
            break
    if insert_before is not None:
        insert_before.addprevious(layout)
    else:
        tblPr.append(layout)


def _row_props(row, repeat_header=False, allow_break=True):
    """tblHeader: lặp dòng tiêu đề đầu mỗi trang.
    cantSplit val=0: cho phép dòng ngắt qua trang (nếu quá dài)."""
    trPr = row._tr.get_or_add_trPr()
    cant = OxmlElement("w:cantSplit")
    cant.set(qn("w:val"), "0" if allow_break else "1")
    trPr.append(cant)
    if repeat_header:
        th = OxmlElement("w:tblHeader")
        th.set(qn("w:val"), "1")
        trPr.append(th)


class ReportBuilder:
    """Dựng báo cáo rà soát 8 phần đúng đặc tả KTC-897."""

    def __init__(self, ver, ngay_skill):
        self.ver = ver
        self.ngay_skill = ngay_skill
        self.doc = Document()
        self._setup_page()

    def _setup_page(self):
        sec = self.doc.sections[0]
        sec.orientation = WD_ORIENT.LANDSCAPE
        sec.page_width = Mm(297)
        sec.page_height = Mm(210)
        for attr in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
            setattr(sec, attr, Mm(20))
        n = self.doc.styles["Normal"]
        n.font.name = "Times New Roman"
        n._element.rPr.rFonts.set(qn("w:ascii"), "Times New Roman")
        n._element.rPr.rFonts.set(qn("w:hAnsi"), "Times New Roman")
        n.font.size = Pt(14)

    # ── Heading / đoạn văn ────────────────────────────────────────────────
    def h1(self, text):
        """PHẦN I .. PHẦN VIII, KIỂM TRA CHẤT LƯỢNG CUỐI CÙNG, THÔNG TIN TRÁCH NHIỆM."""
        p = self.doc.add_paragraph()
        p.paragraph_format.space_before = Pt(10)
        p.paragraph_format.space_after = Pt(4)
        _font(p.add_run(text), 14, True, color=C_H1)
        return p

    def h2(self, text):
        """Phụ đề trang đầu (HỆ KTC-RA-SOAT...) và II.A / II.B..."""
        p = self.doc.add_paragraph()
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after = Pt(3)
        _font(p.add_run(text), 14, True, color=C_H2)
        return p

    def h3(self, text):
        p = self.doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(2)
        _font(p.add_run(text), 14, True, italic=True)
        return p

    def title(self, text, size=15, color=None):
        """Dòng tiêu đề trang đầu, căn giữa. Dòng 'BÁO CÁO RÀ SOÁT...' PHẢI
        truyền color=C_TITLE — đây là điểm v3.0 để trống, xvất ra chữ đen sai."""
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(3)
        _font(p.add_run(text), size, True, color=color)
        return p

    def para(self, text, indent=True, italic=False, color=None, bold=False):
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p.paragraph_format.space_after = Pt(3)
        p.paragraph_format.line_spacing = 1.15
        if indent:
            p.paragraph_format.first_line_indent = Cm(1)
        _font(p.add_run(text), 14, bold, italic, color)
        return p

    # ── Ô và bảng ─────────────────────────────────────────────────────────
    def _cell_multi(self, c, parts, center=False):
        """parts: list[(text, {bold,color,italic})] — nhiều đoạn/run trong 1 ô,
        dùng để chèn dòng 'Phản hồi:' màu đỏ ngay dưới nội dung kiến nghị
        trong CÙNG một ô, đúng cấu trúc file mẫu chuẩn."""
        c.text = ""
        first = True
        for text, opts in parts:
            opts = opts or {}
            if first:
                p = c.paragraphs[0]
                first = False
            else:
                p = c.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.JUSTIFY
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.space_before = Pt(4) if opts.get("phan_hoi") else Pt(0)
            p.paragraph_format.line_spacing = 1.0
            color = C_PHANHOI if opts.get("phan_hoi") else opts.get("color")
            _font(p.add_run(text), opts.get("size", 13), opts.get("bold", False), color=color)
        c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
        _set_cell_margins(c)

    def _cell(self, c, val, bold=False, size=13, center=False, color=None, fill=None):
        c.text = ""
        p = c.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.JUSTIFY
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.0
        p.paragraph_format.first_line_indent = Pt(0)
        p.paragraph_format.left_indent = Pt(0)
        _font(p.add_run(str(val)), size, bold, color=color)
        c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
        _set_cell_margins(c)
        if fill:
            _shade(c, fill)

    def table(self, headers, rows, muc_col=None, widths=None, kien_nghi_col=None):
        """headers/rows theo đúng 6 cột chuẩn đã dùng trong báo cáo trình ký
        thật: TT | NỘI DUNG | NHẬN XÉT | KIẾN NGHỊ | CĂN CỨ | MỨC.

        muc_col: chỉ số cột MỨC — tô đỏ đậm (C00000) khi giá trị chứa "Mức 1";
                 tô nền xanh lá (C6EFCE) khi giá trị là "Đạt";
        kien_nghi_col: chỉ số cột KIẾN NGHỊ — nếu giá trị dạng tuple
                 (kien_nghi_text, phan_hoi_text), dòng "Phản hồi: ..." được
                 tách riêng, tô đỏ tươi (FF0000), đúng file mẫu chuẩn.
        widths: list cm. Tổng phải <= 25.7cm.
        """
        if widths:
            total_w = sum(widths)
            if total_w > 25.7:
                raise ValueError(
                    f"Bảng vượt khổ giấy: tổng độ rộng {total_w:.2f}cm > 25.7cm cho phép "
                    f"(A4 ngang, lề 20mm mỗi bên). Co lại widths trước khi gọi table()."
                )
            if len(widths) != len(headers):
                raise ValueError("Số phần tử widths phải bằng số cột headers.")

        # Chỉ thêm bảng sau khi toàn bộ điều kiện đầu vào đã hợp lệ. Như vậy một
        # ValueError không để lại bảng rỗng trong tài liệu đang dựng.
        t = self.doc.add_table(rows=1, cols=len(headers))
        t.style = "Table Grid"
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False  # BẮT BUỘC: không tắt thì Word bỏ qua width đã đặt
        for i, h in enumerate(headers):
            self._cell(t.rows[0].cells[i], h, bold=True, size=14,
                       center=True, color=C_WHITE, fill=F_HEADER)
        _row_props(t.rows[0], repeat_header=True, allow_break=True)

        for row in rows:
            cells = t.add_row().cells
            for i, val in enumerate(row):
                is_muc1 = (muc_col is not None and i == muc_col
                           and "Mức 1" in str(val))
                is_dat = (muc_col is not None and i == muc_col
                          and str(val).strip().lower() in ("đạt", "dat"))
                if kien_nghi_col is not None and i == kien_nghi_col and isinstance(val, tuple):
                    kien_nghi_text, phan_hoi_text = val
                    parts = [(kien_nghi_text, {"size": 13})]
                    if phan_hoi_text:
                        parts.append((f"Phản hồi: {_cap_first(phan_hoi_text)}",
                                       {"size": 13, "phan_hoi": True}))
                    self._cell_multi(cells[i], parts)
                else:
                    self._cell(cells[i], val, bold=(is_muc1 or is_dat), size=13,
                               center=(i == 0 or i == muc_col),
                               color=C_MUC1 if is_muc1 else None,
                               fill=F_PASS if is_dat else None)
            _row_props(t.rows[-1], repeat_header=False, allow_break=True)

        if widths:
            tblPr = t._tbl.tblPr
            _set_tbl_layout_fixed(t._tbl)
            grid = t._tbl.find(qn("w:tblGrid"))
            if grid is not None:
                for gc, w in zip(grid.findall(qn("w:gridCol")), widths):
                    gc.set(qn("w:w"), str(int(w * 567)))
            for r in t.rows:
                for i, w in enumerate(widths):
                    r.cells[i].width = Cm(w)
        self.doc.add_paragraph().paragraph_format.space_after = Pt(2)
        return t

    def bang_2cot(self, header, rows, bold_left=True):
        """Bảng 2 cột dùng cho PHẦN I (header=('MỤC','NỘI DUNG')) và
        THÔNG TIN TRÁCH NHIỆM (header=None — mẫu thật KHÔNG có dòng tiêu đề,
        đi thẳng vào 3 dòng nhãn-giá trị). Cột trái in đậm theo mẫu thật."""
        t = self.doc.add_table(rows=1 if header else 0, cols=2)
        t.style = "Table Grid"
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False
        if header:
            for i, h in enumerate(header):
                self._cell(t.rows[0].cells[i], h, bold=True, size=14,
                           center=True, color=C_WHITE, fill=F_HEADER)
            _row_props(t.rows[0], repeat_header=True, allow_break=True)
        for label, value in rows:
            r = t.add_row()
            self._cell(r.cells[0], label, bold=bold_left, size=13)
            self._cell(r.cells[1], value, size=13,
                       color=C_MUC1 if "BẢN NHÁP" in str(value) else None,
                       bold=("BẢN NHÁP" in str(value)))
            _row_props(r, repeat_header=False, allow_break=True)
        # Trước là [5.0, 20.7] = đúng biên 25.7cm — không có dư an toàn, dễ vỡ do sai số làm tròn
        # EMU/Cm nội bộ của Word (đã từng gặp đúng kiểu lỗi này với lề trang). Giảm nhẹ để có dư.
        widths = [4.9, 20.6]
        assert sum(widths) <= 25.7, "bang_2cot(): độ rộng cứng vượt khổ giấy — kiểm tra lại"
        tblPr = t._tbl.tblPr
        _set_tbl_layout_fixed(t._tbl)
        grid = t._tbl.find(qn("w:tblGrid"))
        if grid is not None:
            for gc, w in zip(grid.findall(qn("w:gridCol")), widths):
                gc.set(qn("w:w"), str(int(w * 567)))
        for r in t.rows:
            for i, w in enumerate(widths):
                r.cells[i].width = Cm(w)
        self.doc.add_paragraph().paragraph_format.space_after = Pt(2)
        return t

    def thong_tin_trach_nhiem(self, nguon_du_lieu, nguoi_chiu_trach_nhiem, ngay=None):
        """PHẦN cuối bắt buộc theo Nguyên tắc 2 (00-Nguyen-Tac-Chung.md).

        nguoi_chiu_trach_nhiem: BẮT BUỘC là tên người + chức danh cụ thể
        (ví dụ "Nguyễn Văn A, Phó Trưởng phòng TH-HC&QT"). Quy tắc đúc kết
        từ vận hành thực tế (SKILL.md): "Người kiểm tra" không được ghi
        CHỈ tên công cụ AI — script KHÔNG tự kiểm tra được nội dung chuỗi
        này có đúng là tên người hay không, người gọi hàm phải tự bảo đảm.
        Nếu để trống, script vẫn chạy nhưng in cảnh báo ra stdout đề
        người dùng không lỡ quên điền.
        """
        if not nguoi_chiu_trach_nhiem or not nguoi_chiu_trach_nhiem.strip():
            print("CẢNH BÁO: thong_tin_trach_nhiem() được gọi mà không có "
                  "tên người chịu trách nhiệm — vi phạm quy tắc 'Người kiểm "
                  "tra không được ghi chỉ tên công cụ AI'. Hãy truyền tên "
                  "người + chức danh cụ thể vào nguoi_chiu_trach_nhiem.")
            nguoi_chiu_trach_nhiem = "[CẦN ĐIỀN TÊN NGƯỜI CHỊU TRÁCH NHIỆM]"
        ngay = ngay or datetime.now().strftime("%d/%m/%Y")
        self.h1("THÔNG TIN TRÁCH NHIỆM")
        self.bang_2cot(None, [
            ("Nguồn dữ liệu đã dùng",
             f"{nguon_du_lieu} · Công cụ hỗ trợ: Hệ {SKILL_NAME} "
             f"(Skill ktc-ra-soat-897, {self.ver}), chạy ngày {ngay}."),
            ("Người kiểm tra",
             f"{_cap_first(nguoi_chiu_trach_nhiem)} chịu trách nhiệm xác nhận kết quả."),
            ("Trạng thái phê duyệt",
             "BẢN NHÁP – Kết quả AI chỉ có giá trị tham khảo. "
             "Cần phê duyệt chính thức trước khi dùng."),
        ], bold_left=True)

    def footer_pages(self):
        for sec in self.doc.sections:
            fp = sec.footer.paragraphs[0]
            fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
            _font(fp.add_run(
                f"Hệ {SKILL_NAME} (Skill ktc-ra-soat-897, phiên bản {self.ver})  |  Trang "),
                10, color=(100, 100, 100))
            fld = OxmlElement("w:fldSimple")
            fld.set(qn("w:instr"), "PAGE")
            fp._p.append(fld)

    def save(self, path):
        self.doc.save(path)
        _fix_app_xml_metadata(path, self.doc)
        return path


def _fix_app_xml_metadata(path, doc):
    """python-docx để mặc định docProps/app.xml ghi Pages=1, Words=0, Paragraphs=0 vì thư viện
    không tự dàn trang — nhiều trình xem (thanh trạng thái Word trước khi tính lại, Windows
    Explorer, khung xem trước) đọc thẳng số liệu này, hiển thị sai "1 trang" dù nội dung thật
    dài hơn nhiều. Xác nhận lỗi thật ngày 30/8/2026 khi tự kiểm định script.
    Vá bằng cách: đếm đoạn/từ thật + render PDF thật để đếm số trang, rồi ghi đè vào app.xml."""
    import re
    import shutil
    import subprocess
    import tempfile
    import zipfile

    n_paragraphs = len(doc.paragraphs) + sum(
        len(c.paragraphs) for t in doc.tables for r in t.rows for c in r.cells
    )
    full_text = "\n".join(p.text for p in doc.paragraphs)
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                full_text += "\n" + "\n".join(p.text for p in cell.paragraphs)
    n_words = len(full_text.split())
    n_chars = len(full_text.replace(" ", ""))

    n_pages = 1
    try:
        office = shutil.which("soffice") or shutil.which("libreoffice")
        pdfinfo = shutil.which("pdfinfo")
        if office and pdfinfo:
            # Render trong thư mục tạm riêng. Không bao giờ ghi đè hoặc xóa tệp
            # PDF cùng tên mà người dùng đã có cạnh báo cáo.
            with tempfile.TemporaryDirectory(prefix="ktc897-pages-") as tmpdir:
                converted = subprocess.run(
                    [office, "--headless", "--convert-to", "pdf",
                     "--outdir", tmpdir, str(Path(path).resolve())],
                    capture_output=True, timeout=60,
                )
                generated_pdf = Path(tmpdir) / Path(path).with_suffix(".pdf").name
                if converted.returncode == 0 and generated_pdf.exists():
                    info = subprocess.run(
                        [pdfinfo, str(generated_pdf)],
                        capture_output=True, text=True, timeout=30,
                    )
                    m = re.search(r"Pages:\s+(\d+)", info.stdout)
                    if m:
                        n_pages = int(m.group(1))
    except Exception:
        pass  # không chặn việc xuất file nếu môi trường không có soffice/pdfinfo — giữ Pages=1 mặc định

    tmp = str(path) + ".tmp"
    with zipfile.ZipFile(path, "r") as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == "docProps/app.xml":
                text = data.decode("utf-8")
                text = re.sub(r"<Pages>\d+</Pages>", f"<Pages>{n_pages}</Pages>", text)
                text = re.sub(r"<Words>\d+</Words>", f"<Words>{n_words}</Words>", text)
                text = re.sub(r"<Paragraphs>\d+</Paragraphs>", f"<Paragraphs>{n_paragraphs}</Paragraphs>", text)
                text = re.sub(r"<Characters>\d+</Characters>", f"<Characters>{n_chars}</Characters>", text)
                data = text.encode("utf-8")
            elif item.filename == "word/settings.xml":
                # Lỗi schema thật xác nhận 30/8/2026: <w:zoom w:val="..."/> thiếu w:percent bắt buộc.
                text = data.decode("utf-8")
                text = re.sub(
                    r'(<w:zoom\b(?:(?!w:percent)[^/])*)/>',
                    r'\1 w:percent="100"/>',
                    text,
                )
                data = text.encode("utf-8")
            zout.writestr(item, data)
    shutil.move(tmp, str(path))


def _cap_first(text):
    """Viết hoa chữ cái đầu — bắt buộc áp dụng cho mọi giá trị đứng ngay
    sau dấu hai chấm, theo Checklist 08 mục 3.1: 'phòng/khoa/bộ môn viết
    thường, trừ khi đứng đầu dòng, sau dấu chấm và SAU DẤU HAI CHẤM'.
    Không tự sửa các chữ khác trong chuỗi, chỉ chữ đầu tiên."""
    text = str(text)
    if not text:
        return text
    return text[0].upper() + text[1:]


# ── Hàm tiện ích dựng nhanh trang đầu — dùng đúng màu chuẩn ──────────────────
def trang_dau(b, ho_so, don_vi, tham_quyen, ngay):
    don_vi = _cap_first(don_vi)      # luôn đứng sau "Đơn vị soạn thảo: "
    tham_quyen = _cap_first(tham_quyen)  # luôn đứng sau "Thẩm quyền: "
    b.title("TRƯỜNG CAO ĐẲNG KON TUM", 13)
    p = b.doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(4)
    _font(p.add_run(f"HỆ {SKILL_NAME.upper()}"), 13, True, color=C_H2)
    _font(p.add_run("  |  Báo cáo rà soát chính thức"), 13, True, color=C_H2)
    b.title("BÁO CÁO RÀ SOÁT CHÍNH THỨC TRƯỚC KHI TRÌNH KÝ", 15, color=C_TITLE)
    b.title(ho_so, 14)
    p = b.doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _font(p.add_run("Ngày rà soát: "), 13)
    _font(p.add_run(ngay), 13, bold=True)
    _font(p.add_run("  |  Đơn vị soạn thảo: "), 13)
    _font(p.add_run(don_vi), 13, bold=True)
    _font(p.add_run("  |  Thẩm quyền: "), 13)
    _font(p.add_run(tham_quyen), 13, bold=True)


def khung_bao_cao(b, nguon_du_lieu, nguoi_kiem_tra, include_risk=False):
    """Dựng khung báo cáo đầy đủ để CLI không xuất một trang bìa đơn độc."""
    b.h1("PHẦN I. THÔNG TIN CHUNG")
    b.bang_2cot(("MỤC", "NỘI DUNG"), [
        ("Hệ quy chiếu", "[CẦN XÁC ĐỊNH]"),
        ("Loại văn bản", "[CẦN ĐIỀN]"),
        ("Cơ quan ban hành", "[CẦN ĐIỀN]"),
        ("Nguồn dữ liệu", nguon_du_lieu),
        ("Thống nhất tiền đề", "[CẦN ĐIỀN]"),
        ("Thời điểm xác minh", datetime.now().strftime("%d/%m/%Y")),
    ])

    b.h1("PHẦN II. KẾT QUẢ RÀ SOÁT CHI TIẾT")
    b.table(
        ["TT", "NỘI DUNG", "NHẬN XÉT", "KIẾN NGHỊ", "CĂN CỨ", "MỨC"],
        [],
        muc_col=5,
        kien_nghi_col=3,
        widths=[1.0, 4.4, 9.7, 5.3, 2.9, 1.9],
    )
    b.para("[CHƯA CÓ DỮ LIỆU RÀ SOÁT]", indent=False, italic=True)

    b.h1("PHẦN III. NỘI DUNG ĐẠT / KHÔNG PHÁT HIỆN VẤN ĐỀ")
    b.para("[CẦN ĐIỀN SAU KHI ĐỐI CHIẾU]", indent=False, italic=True)
    b.h1("PHẦN IV. BẢNG TỔNG HỢP")
    b.para("[CẦN TỔNG HỢP THEO NHÓM VÀ MỨC ĐỘ]", indent=False, italic=True)
    b.h1("PHẦN V. THẨM ĐỊNH CHUYÊN MÔN")
    b.para("Không có nội dung cần thẩm định chuyên môn.", indent=False, italic=True)
    b.h1("PHẦN VI. ĐÁNH GIÁ TỔNG THỂ")
    b.para("[CẦN ĐÁNH GIÁ MỨC ĐỘ TUÂN THỦ VÀ SẴN SÀNG TRÌNH KÝ]", indent=False, italic=True)
    b.h1("PHẦN VII. KẾT LUẬN VÀ THỨ TỰ XỬ LÝ")
    b.para("[CẦN ĐIỀN]", indent=False, italic=True)
    if include_risk:
        b.h1("PHẦN VIII. PHÂN TÍCH KHẢ THI VÀ RỦI RO")
        b.para(
            "Các nhận định dưới đây mang tính tư vấn, dựa trên kinh nghiệm thực tiễn, "
            "không phải là lỗi vi phạm quy định.",
            indent=False,
            italic=True,
        )
        b.para("[CẦN ĐIỀN]", indent=False, italic=True)

    b.h1("KIỂM TRA CHẤT LƯỢNG CUỐI CÙNG")
    b.para("[CẦN TỰ KIỂM TRƯỚC KHI PHÊ DUYỆT]", indent=False, italic=True)
    b.thong_tin_trach_nhiem(nguon_du_lieu, nguoi_kiem_tra)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Xuất Báo cáo Rà soát KTC-897 (.docx)")
    ap.add_argument("--out", default=None)
    ap.add_argument("--ho-so", default="ra-soat-chinh-thuc")
    ap.add_argument("--nguon", default="[CẦN LIỆT KÊ NGUỒN ĐÃ DÙNG]")
    ap.add_argument("--nguoi-kiem-tra", default="[CẦN ĐIỀN TÊN VÀ CHỨC DANH]")
    ap.add_argument("--include-risk", action="store_true")
    a = ap.parse_args()
    ver, ngay_skill = _read_skill_version()
    b = ReportBuilder(ver, ngay_skill)
    trang_dau(b, f"[{a.ho_so}]", "[TÊN ĐƠN VỊ]", "[CHỨC DANH NGƯỜI KÝ]",
              datetime.now().strftime("%d/%m/%Y"))
    khung_bao_cao(b, a.nguon, a.nguoi_kiem_tra, a.include_risk)
    out = resolve_output(a.out, a.ho_so)
    b.footer_pages()
    b.save(out)
    print(f"Đã xuất: {out}")
