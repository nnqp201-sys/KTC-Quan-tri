# KTC-Ra-Soat-897-v2-Cai-tien

Hệ chuyên biệt rà soát, so sánh và chuẩn hóa văn bản của Trường Cao đẳng Kon Tum trước khi trình ký.

**Phiên bản hiện hành:** v2.25 — 28/9/2026  
**Gói cài đặt:** `ktc-ra-soat-897-v2.25.skill`  
**Phạm vi:** không soạn văn bản mới.

## Thành phần hoạt động

```text
SKILL.md                         Điểm vào và chốt an toàn
assets/                          Mẫu prompt và template DOCX/DOTX
references/Checklist/            Bộ kiểm tra 01-09
references/Prompt-Library/       Prompt theo tác vụ và loại văn bản
references/Skill-Library/        Hướng dẫn chuyên sâu theo tình huống
references/Nguyen-Tac/           Quy tắc khai thác Internet
references/Quan-Tri-He/          Changelog và ghi chú kỹ thuật
tools/                           Đọc thuộc tính đầu vào, dựng báo cáo, kiểm thử
09-Quan-Tri-He/                  Chuyển giao, nhật ký và bộ nhớ vận hành
13-Regression-Test/              Bộ hồi quy và kết quả lịch sử
99-Kinh-Nghiem/                  Bài học, đề xuất, quyết định và lỗi đã biết
```

Các tài liệu hành chính, bản bàn giao và kết quả hồi quy ở ngoài gói `.skill` được giữ làm hồ sơ;
chúng không phải thành phần runtime.

## Cách dùng

1. Cài `ktc-ra-soat-897-v2.25.skill` trong Claude.
2. Kết nối Google Drive có quyền đọc thư mục `KTC-Database`.
3. Giao dự thảo và yêu cầu rà soát, so sánh hoặc chuẩn hóa.
4. Với rà soát chính thức, hệ phải đọc nguồn liên quan trong bốn lớp 01-04 và xuất báo cáo `.docx`.

Đọc `SKILL.md` để biết quy trình có hiệu lực. Đặc tả báo cáo nằm tại
`references/Skill-Library/28-Skill-Bao-Cao-Ra-Soat-Chuan.md`; lịch sử thay đổi nằm tại
`references/Quan-Tri-He/CHANGELOG.md`.

## Thay đổi gần nhất — v2.25 (28/9/2026)

Vá một lỗi dương tính giả lặp lại nhiều lần: Hệ từng bắt nhầm việc thiếu dòng
*"(Ban hành kèm theo Quyết định số ... ngày ... của ...)"* ở **văn bản điện tử ký số** là lỗi thể thức.
Quy tắc đúng vốn đã có trong `Checklist/01-The-Thuc.md` nhưng không khớp được vì khác cách diễn đạt.
Đã tách thành **mục 3a** riêng (liệt kê đủ 4 cách viết, 9 loại văn bản kèm theo) và thêm mục
**"Danh sách dương tính giả"** vào `SKILL.md` — tầng luôn được nạp.

Trước đó, **v2.24 (14/9/2026)** cập nhật căn cứ ban hành: `QĐ 1976/QĐ-CĐKT ngày 14/9/2026` thay
`QĐ 988/QĐ-CĐKT ngày 12/5/2026` (Quy chế tổ chức và hoạt động), kèm bảng chuyển tiếp 3 đời đối chiếu
theo ngày ban hành của dự thảo.

Chi tiết đầy đủ: `references/Quan-Tri-He/CHANGELOG.md`.

## Quy tắc quản trị

- `SKILL.md` trong gói phát hành hiện hành là nguồn chỉ dẫn có thẩm quyền cao nhất.
- Không suy diễn phiên bản từ tên tệp; luôn kiểm tra nội dung và hash của gói.
- Không coi template, checklist hoặc báo cáo AI là căn cứ pháp lý.
- Mọi kết luận hiệu lực pháp luật phải được xác minh tại thời điểm rà soát.
- Sau mỗi lần sửa, chạy kiểm thử, kiểm tra OOXML và giải nén lại gói trước khi công bố.
- Mọi kết luận dạng **"không khắc phục được"** phải kèm **ngày** và **điều kiện môi trường** lúc kết
  luận, và phải được thử lại khi điều kiện đổi (xem `99-Kinh-Nghiem/06-Decision-Log/DL-20260929-001.md`).
- Dương tính giả bị nhắc **từ lần thứ hai** là sự thật vận hành ổn định — ghi ngay vào
  `MEMORY-INDEX.md` mục "Dương tính giả", không đợi đợt nâng cấp gói. Xem `MEMORY-INDEX.md` mục
  "Vòng tự cải tiến".
