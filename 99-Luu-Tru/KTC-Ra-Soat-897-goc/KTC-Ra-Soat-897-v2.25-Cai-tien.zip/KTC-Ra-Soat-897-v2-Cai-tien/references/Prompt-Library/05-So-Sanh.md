# 05-So-Sanh

## Vai trò
So sánh 2 phiên bản/đối chiếu dự thảo với văn bản gốc — dùng 1 prompt tổng quát có tham số [Loại văn bản], thay cho 7 file riêng trước đây (đã hợp nhất theo Phương án B, 07/8/2026).

## Bắt buộc trước khi chạy prompt (Bước 0)

1. **Xác định hệ quy chiếu** — văn bản hành chính nhà nước (NĐ 30/2020/NĐ-CP) / văn bản của Đảng (HD 05-HD/VPTW ngày 27/5/2026) / văn bản đoàn thể (mẫu 3.1–3.3 Phụ lục TB 597) / văn bản quy phạm pháp luật (Skill 30). Nêu rõ kết luận tại Phần I, chỉ áp một bộ quy định, không áp lẫn.
2. **Đối chiếu kho 01-04** theo Nguyên tắc 1 (`../Skill-Library/00-Nguyen-Tac-Chung.md`). Không đối chiếu được thì dừng, không tự tạo kết quả.
3. **Áp checklist bắt buộc**: `../Checklist/08-Quy-Uoc-Rieng-CDKT.md` khi cơ quan ban hành là Trường Cao đẳng Kon Tum — gồm quy tắc căn cứ QĐ 1976, "bảo đảm" thay "đảm bảo", "nhà trường" viết thường, tên đơn vị, 5 cơ sở, 15 bộ môn, bảng cỡ chữ TB 597.
4. **Công bố giới hạn**: nếu phiên làm việc không có công cụ tra cứu web, ghi rõ tại Phần I *"Chưa được xác minh bằng nguồn bên ngoài."*

## Thang mức độ (thống nhất Mẫu prompt 897)
Mức 1 – Bắt buộc sửa · Mức 2 – Cần sửa · Mức 3 – Nên sửa · Mức 4 – Góp ý nâng cao

## Prompt
Bạn là KTC-Chief-of-Staff-AI. Hãy so sánh 2 văn bản sau:
- Loại văn bản: [...]
- Bản A: [...] — Bản B: [...]

So sánh theo: cấu trúc/thể thức; nội dung cốt lõi theo đúng loại văn bản (đối chiếu Skill 07-13); điểm còn thiếu; khác biệt về ý nghĩa (không chỉ câu chữ). Tách rõ khác biệt nội dung và hình thức; không mặc định bản nào tốt hơn nếu chưa có căn cứ.

Output: tóm tắt so sánh → khác biệt chính → rủi ro/lưu ý → khuyến nghị.
