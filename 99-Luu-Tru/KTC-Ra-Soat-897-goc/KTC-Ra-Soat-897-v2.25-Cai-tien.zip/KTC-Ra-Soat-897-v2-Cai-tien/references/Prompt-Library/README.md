# Prompt-Library — Chỉ mục (bổ sung v2.23, 09/9/2026)

Thư mục này chứa prompt dựng sẵn cho 3 trong 4 tác vụ của hệ. Trước v2.23 các file con
không được trỏ đích danh từ bất kỳ đâu nên hệ hay bỏ qua — chỉ mục này khắc phục điều đó.

## Chọn file theo tác vụ

| Tác vụ | Đường dẫn | Ghi chú |
|---|---|---|
| (a) Rà soát chính thức trước khi trình ký | **KHÔNG dùng thư mục này** | Dùng `assets/Mau-Prompt-Chinh-Thuc-Ra-Soat-897.docx` làm khung chính |
| (b) Rà soát nhanh / sơ bộ | `02-Ra-Soat/<loại văn bản>.md` | Xem bảng dưới |
| (c) So sánh 2 phiên bản | `05-So-Sanh.md` | 1 file dùng chung mọi loại văn bản |
| (d) Chuẩn hóa văn phong | `03-Chuan-Hoa/<loại văn bản>.md` | Xem bảng dưới |

## Bảng tra theo loại văn bản

| Loại văn bản | Rà soát nhanh (b) | Chuẩn hóa (d) |
|---|---|---|
| Quyết định | `02-Ra-Soat/01-Quyet-Dinh.md` | `03-Chuan-Hoa/01-Quyet-Dinh.md` |
| Kế hoạch | `02-Ra-Soat/02-Ke-Hoach.md` | `03-Chuan-Hoa/02-Ke-Hoach.md` |
| Thông báo | `02-Ra-Soat/03-Thong-Bao.md` | `03-Chuan-Hoa/03-Thong-Bao.md` |
| Báo cáo | `02-Ra-Soat/04-Bao-Cao.md` | `03-Chuan-Hoa/04-Bao-Cao.md` |
| Tờ trình | `02-Ra-Soat/05-To-Trinh.md` | `03-Chuan-Hoa/05-To-Trinh.md` |
| Công văn | `02-Ra-Soat/06-Cong-Van.md` | `03-Chuan-Hoa/06-Cong-Van.md` |
| Biên bản | `02-Ra-Soat/07-Bien-Ban.md` | `03-Chuan-Hoa/07-Bien-Ban.md` |

**Loại văn bản không có trong bảng** (đề án, quy chế, hợp đồng, giấy mời...): dùng khuôn 6 phần
tại `00-Chuan-Khuon-Prompt_20260810.md` để viết prompt tùy biến. Không lấy file gần giống dùng thay.

## Ràng buộc chung — áp cho mọi prompt trong thư mục này

1. Prompt ở đây **không thay thế Checklist**. Vẫn phải đối chiếu `../Checklist/08-Quy-Uoc-Rieng-CDKT.md`
   (bắt buộc ở cả 4 tác vụ khi cơ quan ban hành là Trường Cao đẳng Kon Tum), và
   `../Checklist/09-Checklist-He-D-Doan-The.md` khi văn bản thuộc Hệ D.
2. Trước khi dùng bất kỳ prompt nào, phải hoàn thành **Bước 0** trong `SKILL.md`
   (xác định 1 trong 4 hệ quy chiếu + chạy `tools/_read_input_properties.py`).
   Các prompt trong thư mục này mặc định viết cho **hệ hành chính nhà nước**; với văn bản Đảng,
   quy phạm pháp luật hoặc đoàn thể phải đọc kèm Skill 29/30 hoặc Checklist 09 và **không áp thể thức NĐ 30**.
3. Prompt tạo mới từ 10/8/2026 trở đi dùng khuôn 6 phần tại `00-Chuan-Khuon-Prompt_20260810.md`.
4. Kết quả tác vụ (b) và (d) vẫn phải xuất `.docx` đủ 3 trường trách nhiệm theo Nguyên tắc 2.
