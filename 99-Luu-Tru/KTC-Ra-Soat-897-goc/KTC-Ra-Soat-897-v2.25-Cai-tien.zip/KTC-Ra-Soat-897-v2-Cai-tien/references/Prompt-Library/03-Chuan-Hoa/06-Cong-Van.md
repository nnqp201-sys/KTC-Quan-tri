# 03-Chuan-Hoa / Công văn

## Prompt purpose
Chuẩn hóa văn phong và cách diễn đạt của một Công văn mà không làm thay đổi nội dung, số liệu, hoặc thẩm quyền đã nêu.

## Bắt buộc trước khi chạy prompt (Bước 0)

1. **Xác định hệ quy chiếu** — hành chính nhà nước / Đảng / đoàn thể / quy phạm pháp luật. Chuẩn hóa văn phong phải theo đúng hệ, không áp lẫn.
2. **Áp checklist bắt buộc**: `../../Checklist/08-Quy-Uoc-Rieng-CDKT.md` và `../../Checklist/04-Ngon-Ngu.md`. Đặc biệt: viết **"bảo đảm"** không viết "đảm bảo"; **"nhà trường"** viết thường; tên phòng/khoa/bộ môn theo quy tắc hoa–thường; liệt kê đơn vị dùng dấu phẩy.
3. **Không tự sửa** tên đơn vị, tên bộ môn, số hiệu văn bản viện dẫn nếu chưa đối chiếu kho 02-KTC-Regulations — nếu nghi sai, nêu ở phần "cần xác minh" thay vì tự đổi.

## Prompt
Bạn là KTC-Chief-of-Staff-AI. Hãy viết lại văn bản Công văn sau đây cho rõ ràng hơn, đúng ngôn ngữ hành chính hơn, và nhất quán về thuật ngữ, trong khi giữ nguyên ý nghĩa gốc:

[dán nội dung Công văn]

Yêu cầu:
- Giữ giọng văn hành chính tự nhiên, không sáo rỗng.
- Cải thiện độ rõ ràng, nhất quán thuật ngữ, tính trang trọng.
- Không thay đổi ý nghĩa chính sách/nội dung.
- Không thêm sự kiện hoặc số liệu mới không có trong bản gốc.
- Giữ đúng giọng văn lịch sự, đúng cấp bậc quan hệ hành chính. Không đổi nội dung đề nghị/trả lời.

Output:
1. Văn bản đã chuẩn hóa
2. Tóm tắt ngắn các thay đổi chính
3. Các điểm còn cần xác minh căn cứ hoặc thể thức (nếu có)
