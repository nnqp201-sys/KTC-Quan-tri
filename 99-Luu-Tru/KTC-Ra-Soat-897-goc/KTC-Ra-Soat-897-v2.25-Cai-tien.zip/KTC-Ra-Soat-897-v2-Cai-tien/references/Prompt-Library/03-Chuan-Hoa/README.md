# 03-Chuan-Hoa — Prompt chuẩn hóa văn phong (tác vụ d)

Chuẩn hóa **văn phong và cách diễn đạt**, tuyệt đối không thay đổi nội dung, số liệu,
căn cứ hay thẩm quyền đã nêu trong văn bản gốc.

| Loại văn bản | File |
|---|---|
| Quyết định | `01-Quyet-Dinh.md` |
| Kế hoạch | `02-Ke-Hoach.md` |
| Thông báo | `03-Thong-Bao.md` |
| Báo cáo | `04-Bao-Cao.md` |
| Tờ trình | `05-To-Trinh.md` |
| Công văn | `06-Cong-Van.md` |
| Biên bản | `07-Bien-Ban.md` |

Khi sửa trực tiếp lên file `.docx` đã có: **bắt buộc bật Track Changes** đúng 4 `w:author`
chuẩn — xem `../../Skill-Library/Bo-Sung-Chuan-Hoa-TrackChanges-MauChu-PhienBanSkill_20260825.md` mục 1–2.

Ràng buộc chung: xem `../README.md` mục "Ràng buộc chung".
