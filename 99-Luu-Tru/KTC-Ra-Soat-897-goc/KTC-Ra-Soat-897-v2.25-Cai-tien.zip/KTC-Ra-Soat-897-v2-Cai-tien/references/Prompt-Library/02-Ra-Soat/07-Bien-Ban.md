# 02-Ra-Soat / Biên bản

## Prompt purpose
Rà soát một Biên bản về tính trung thực của nội dung ghi nhận và tính đầy đủ chữ ký các bên.

## Bắt buộc trước khi chạy prompt (Bước 0)

1. **Xác định hệ quy chiếu** — văn bản hành chính nhà nước (NĐ 30/2020/NĐ-CP) / văn bản của Đảng (HD 05-HD/VPTW ngày 27/5/2026) / văn bản đoàn thể (mẫu 3.1–3.3 Phụ lục TB 597) / văn bản quy phạm pháp luật (Skill 30). Nêu rõ kết luận tại Phần I, chỉ áp một bộ quy định, không áp lẫn.
2. **Đối chiếu kho 01-04** theo Nguyên tắc 1 (`../../Skill-Library/00-Nguyen-Tac-Chung.md`). Không đối chiếu được thì dừng, không tự tạo kết quả.
3. **Áp checklist bắt buộc**: `../../Checklist/08-Quy-Uoc-Rieng-CDKT.md` khi cơ quan ban hành là Trường Cao đẳng Kon Tum — gồm quy tắc căn cứ QĐ 1976, "bảo đảm" thay "đảm bảo", "nhà trường" viết thường, tên đơn vị, 5 cơ sở, 15 bộ môn, bảng cỡ chữ TB 597.
4. **Công bố giới hạn**: nếu phiên làm việc không có công cụ tra cứu web, ghi rõ tại Phần I *"Chưa được xác minh bằng nguồn bên ngoài."*

## Thang mức độ (thống nhất Mẫu prompt 897)
Mức 1 – Bắt buộc sửa · Mức 2 – Cần sửa · Mức 3 – Nên sửa · Mức 4 – Góp ý nâng cao

## Prompt
Bạn là KTC-Chief-of-Staff-AI. Hãy rà soát văn bản Biên bản sau đây:

[dán nội dung Biên bản]

Kiểm tra theo các nhóm:
1. Nội dung diễn biến có được ghi trung thực, theo trình tự không, có dấu hiệu diễn giải chủ quan không.
2. Kết luận/thống nhất có khớp với nội dung diễn biến đã ghi không.
3. Thành phần tham dự và chữ ký các bên có đầy đủ theo yêu cầu (đặc biệt với biên bản nghiệm thu/hội đồng) không.
4. Thời gian, địa điểm có được ghi rõ không.
5. Thể thức theo Nghị định 30.

Output: bảng vấn đề (Nhóm | Mô tả | Căn cứ | Kiến nghị sửa | Mức độ), theo đúng chuẩn Skill 28.
