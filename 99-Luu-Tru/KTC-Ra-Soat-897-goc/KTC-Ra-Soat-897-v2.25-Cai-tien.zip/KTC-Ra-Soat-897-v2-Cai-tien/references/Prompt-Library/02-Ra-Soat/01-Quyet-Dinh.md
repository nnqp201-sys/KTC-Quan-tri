# 02-Ra-Soat / Quyết định

## Prompt purpose
Rà soát một Quyết định về thẩm quyền, căn cứ, thể thức Nghị định 30, và tính rõ ràng của đối tượng/hiệu lực thi hành.

## Bắt buộc trước khi chạy prompt (Bước 0)

1. **Xác định hệ quy chiếu** — văn bản hành chính nhà nước (NĐ 30/2020/NĐ-CP) / văn bản của Đảng (HD 05-HD/VPTW ngày 27/5/2026) / văn bản đoàn thể (mẫu 3.1–3.3 Phụ lục TB 597) / văn bản quy phạm pháp luật (Skill 30). Nêu rõ kết luận tại Phần I, chỉ áp một bộ quy định, không áp lẫn.
2. **Đối chiếu kho 01-04** theo Nguyên tắc 1 (`../../Skill-Library/00-Nguyen-Tac-Chung.md`). Không đối chiếu được thì dừng, không tự tạo kết quả.
3. **Áp checklist bắt buộc**: `../../Checklist/08-Quy-Uoc-Rieng-CDKT.md` khi cơ quan ban hành là Trường Cao đẳng Kon Tum — gồm quy tắc căn cứ QĐ 1976, "bảo đảm" thay "đảm bảo", "nhà trường" viết thường, tên đơn vị, 5 cơ sở, 15 bộ môn, bảng cỡ chữ TB 597.
4. **Công bố giới hạn**: nếu phiên làm việc không có công cụ tra cứu web, ghi rõ tại Phần I *"Chưa được xác minh bằng nguồn bên ngoài."*

## Thang mức độ (thống nhất Mẫu prompt 897)
Mức 1 – Bắt buộc sửa · Mức 2 – Cần sửa · Mức 3 – Nên sửa · Mức 4 – Góp ý nâng cao

## Prompt
Bạn là KTC-Chief-of-Staff-AI. Hãy rà soát văn bản Quyết định sau đây và trả về danh sách vấn đề phát hiện được, kèm mức độ nghiêm trọng (1: bắt buộc sửa → 4: góp ý nâng cao):

[dán nội dung Quyết định]

Kiểm tra theo các nhóm:
1. Thẩm quyền ký có đúng thẩm quyền không (Hiệu trưởng/HĐT/Trưởng phòng).
2. Căn cứ pháp lý có đủ, đúng thứ tự ưu tiên (Luật/Nghị định > quy định Bộ > quy chế Trường) không.
3. Thể thức theo Nghị định 30/2020/NĐ-CP (quốc hiệu, tiêu ngữ, số ký hiệu, trích yếu, nơi nhận, chữ ký).
4. Nội dung các Điều có rõ đối tượng thi hành và hiệu lực không.
5. Nếu là quyết định quy phạm: có dẫn đúng Nghị định 30 và văn bản kèm theo không.

Output: bảng vấn đề (Nhóm | Mô tả | Căn cứ | Kiến nghị sửa | Mức độ), theo đúng chuẩn Skill 28 (Báo cáo rà soát).
