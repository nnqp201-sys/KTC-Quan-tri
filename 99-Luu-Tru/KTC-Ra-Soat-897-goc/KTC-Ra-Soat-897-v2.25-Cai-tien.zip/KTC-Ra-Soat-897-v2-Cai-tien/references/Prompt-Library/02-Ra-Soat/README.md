# 02-Ra-Soat — Prompt rà soát nhanh (tác vụ b)

Chỉ dùng cho **rà soát nhanh/sơ bộ**. Rà soát chính thức trước khi trình ký (tác vụ a)
phải dùng `assets/Mau-Prompt-Chinh-Thuc-Ra-Soat-897.docx`, không dùng thư mục này.

| Loại văn bản | File |
|---|---|
| Quyết định | `01-Quyet-Dinh.md` |
| Kế hoạch | `02-Ke-Hoach.md` |
| Thông báo | `03-Thong-Bao.md` |
| Báo cáo | `04-Bao-Cao.md` |
| Tờ trình | `05-To-Trinh.md` |
| Công văn | `06-Cong-Van.md` |
| Biên bản | `07-Bien-Ban.md` |

Ràng buộc chung: xem `../README.md` mục "Ràng buộc chung".
