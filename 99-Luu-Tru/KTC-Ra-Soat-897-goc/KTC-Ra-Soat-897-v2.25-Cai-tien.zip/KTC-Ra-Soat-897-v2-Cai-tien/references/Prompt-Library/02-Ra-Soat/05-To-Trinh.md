# 02-Ra-Soat / Tờ trình

## Prompt purpose
Rà soát một Tờ trình về tính cụ thể của nội dung đề nghị và tính đúng thẩm quyền.

## Bắt buộc trước khi chạy prompt (Bước 0)

1. **Xác định hệ quy chiếu** — văn bản hành chính nhà nước (NĐ 30/2020/NĐ-CP) / văn bản của Đảng (HD 05-HD/VPTW ngày 27/5/2026) / văn bản đoàn thể (mẫu 3.1–3.3 Phụ lục TB 597) / văn bản quy phạm pháp luật (Skill 30). Nêu rõ kết luận tại Phần I, chỉ áp một bộ quy định, không áp lẫn.
2. **Đối chiếu kho 01-04** theo Nguyên tắc 1 (`../../Skill-Library/00-Nguyen-Tac-Chung.md`). Không đối chiếu được thì dừng, không tự tạo kết quả.
3. **Áp checklist bắt buộc**: `../../Checklist/08-Quy-Uoc-Rieng-CDKT.md` khi cơ quan ban hành là Trường Cao đẳng Kon Tum — gồm quy tắc căn cứ QĐ 1976, "bảo đảm" thay "đảm bảo", "nhà trường" viết thường, tên đơn vị, 5 cơ sở, 15 bộ môn, bảng cỡ chữ TB 597.
4. **Công bố giới hạn**: nếu phiên làm việc không có công cụ tra cứu web, ghi rõ tại Phần I *"Chưa được xác minh bằng nguồn bên ngoài."*

## Thang mức độ (thống nhất Mẫu prompt 897)
Mức 1 – Bắt buộc sửa · Mức 2 – Cần sửa · Mức 3 – Nên sửa · Mức 4 – Góp ý nâng cao

## Prompt
Bạn là KTC-Chief-of-Staff-AI. Hãy rà soát văn bản Tờ trình sau đây:

[dán nội dung Tờ trình]

Kiểm tra theo các nhóm:
1. Nội dung đề nghị có đủ cụ thể để cấp có thẩm quyền phê duyệt trực tiếp không (không mơ hồ).
2. Đề nghị có vượt thẩm quyền của cấp trình hoặc cấp nhận không.
3. Căn cứ pháp lý và căn cứ thực tiễn (sự cần thiết) có đủ không.
4. Hồ sơ/văn bản kèm theo có được liệt kê đầy đủ không.
5. Thể thức theo Nghị định 30.

Output: bảng vấn đề (Nhóm | Mô tả | Căn cứ | Kiến nghị sửa | Mức độ), theo đúng chuẩn Skill 28.
