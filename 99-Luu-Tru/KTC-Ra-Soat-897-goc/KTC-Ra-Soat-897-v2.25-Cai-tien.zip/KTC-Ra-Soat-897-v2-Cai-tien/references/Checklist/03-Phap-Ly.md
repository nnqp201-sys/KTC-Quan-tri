# 03-Phap-Ly — Checklist căn cứ pháp lý và hiệu lực văn bản

**Mục đích**: kiểm tra căn cứ pháp lý còn hiệu lực, đúng thứ bậc, đủ cho nội dung dự thảo — nhóm ưu tiên số 1 và số 3 theo Mẫu prompt 897.

## 1. Nguyên tắc bắt buộc trước khi viện dẫn

☐ Với **mỗi** văn bản pháp luật xuất hiện trong dự thảo hoặc dùng làm căn cứ rà soát, tự hỏi: *"Kiến thức của tôi về văn bản này có thể đã lỗi thời không?"*
☐ Nếu có công cụ tra cứu → **PHẢI** dùng để xác minh: (a) còn hiệu lực hay đã bị thay thế/bãi bỏ; (b) nếu đã thay thế, văn bản mới có số hiệu, ngày ban hành, ngày hiệu lực là gì; (c) Điều/Khoản tương ứng trong văn bản mới
☐ **Không suy diễn** một văn bản "chắc vẫn còn hiệu lực" chỉ vì quen thuộc, phổ biến, hoặc từng được tài liệu khác viện dẫn — **mỗi văn bản xác minh độc lập**
☐ Nếu phát hiện đã hết hiệu lực nhưng không đủ thông tin về văn bản thay thế → nêu rõ là **khoảng trống cần người có chuyên môn xác minh**, không tự suy diễn nội dung văn bản thay thế
☐ Ghi rõ **ngày kiểm tra hiệu lực** trong phần đánh giá căn cứ ban hành và điều khoản bắt buộc
☐ Việc AI tự rà soát lại sản phẩm do chính mình soạn **KHÔNG** được coi là đã hoàn thành bước xác minh — phải tra cứu chủ động
☐ **Không tin lời xác nhận "đã điều chỉnh"** của kỳ rà soát trước — phải đọc trọn vẹn đoạn văn bản thực tế hoặc tính toán lại độc lập rồi mới kết luận "Đạt". Áp dụng cả cho việc ghi nhận quan hệ pháp lý giữa 2 văn bản — không kết luận "thay thế"/"sửa đổi" chỉ dựa vào mô tả bằng lời, phải đọc Điều khoản thi hành của văn bản mới

### Hai kênh độc lập — KHÔNG được gộp lý do (bổ sung 09/9/2026)

| Kênh | Nằm ở đâu | Cần công cụ web? | Thiếu công cụ web thì sao |
|---|---|---|---|
| **Tra kho 01-04** | Google Drive | **KHÔNG** | **Vẫn phải tra đầy đủ** — thiếu web không phải lý do |
| **Xác minh hiệu lực bên ngoài** | `phapluat.gov.vn`, `vbpl.vn`, Công báo | **CÓ** | Ghi **"Chưa xác minh"** vào bảng mục 6, đề nghị bộ phận pháp chế tra |

☐ **CẤM** viết câu dạng *"chưa tra kho 01-04 **do** không có công cụ tra cứu web"* — đây là **nhân quả giả**,
kho 01-04 không liên quan gì tới công cụ web. Lỗi này nguy hiểm hơn việc bỏ sót, vì nó biến một thiếu sót
sửa được thành "giới hạn kỹ thuật" khiến không ai đi sửa. Đã bắt được thật ngày 09/9/2026 — xem quy tắc
vận hành **#21** trong `SKILL.md`.

☐ **Xác nhận kết nối kho 01-04 KHÔNG tính là đã đối chiếu.** Báo cáo phải liệt kê **từng văn bản viện dẫn**
kèm kết quả tra: tìm thấy trong kho (ghi vị trí) / không có trong kho. Không được ghi gộp "đã xác nhận kết nối".

### Thứ tự ưu tiên nguồn xác minh
1. Kho `01-Legal-Database`, `02-KTC-Regulations` (Nguyên tắc 1 — đối chiếu trước)
2. **Nguồn chính thức của Nhà nước — ưu tiên theo đúng thứ tự này:**
   - **`https://phapluat.gov.vn/` — TRA TRƯỚC TIÊN.** Cổng do Phòng TH-HC&QT xác nhận là nguồn có giá trị cao nhất cho việc tra cứu văn bản và **tình trạng hiệu lực**. Khi cổng này và nguồn khác lệch nhau về tình trạng hiệu lực, **lấy theo cổng này** và ghi rõ điểm lệch vào bảng mục 6.
   - Cơ sở dữ liệu quốc gia về VBQPPL (`vbpl.vn`)
   - Công báo Chính phủ (`congbao.chinhphu.vn`) — dùng để đối chiếu ngày đăng Công báo và bản gốc
   - Cổng TTĐT Chính phủ / Bộ / tỉnh
3. Thư viện pháp luật và các trang tổng hợp tương tự — **chỉ dùng để tìm manh mối**, không được dùng làm nguồn kết luận về hiệu lực. Tìm thấy ở đây thì phải quay lại xác minh tại nguồn nhóm 2.
4. **Không** dựa vào trang tổng hợp không rõ nguồn gốc để kết luận về hiệu lực.

**Ba điều bắt buộc khi tra `phapluat.gov.vn`:**
- Đọc đúng trường **tình trạng hiệu lực** (Còn hiệu lực / Hết hiệu lực / Hết hiệu lực một phần / Chưa có hiệu lực) — **không suy ra hiệu lực từ việc văn bản có mặt trên cổng**.
- Ghi lại **URL cụ thể của văn bản** và **ngày tra cứu** vào bảng mục 6, không ghi chung chung "tra trên phapluat.gov.vn".
- Với văn bản **hết hiệu lực một phần**, phải xác định đúng Điều/Khoản nào đã hết — không kết luận cả văn bản còn hoặc hết hiệu lực.

☐ Nội dung lấy từ internet phải định dạng **chữ màu đỏ** trong kết quả trả về (`../Nguyen-Tac/00-Quy-Tac-Khai-Thac-Internet.md`)

## 2. Thứ bậc hiệu lực pháp lý

| Bậc | Loại văn bản |
|---|---|
| 1 | Hiến pháp |
| 2 | Luật, Nghị quyết của Quốc hội |
| 3 | Pháp lệnh, Nghị quyết của UBTVQH |
| 4 | Nghị định của Chính phủ; Quyết định của Thủ tướng |
| 5 | Thông tư của Bộ trưởng |
| 6 | Nghị quyết HĐND tỉnh; Quyết định UBND tỉnh |
| 7 | Văn bản hành chính của UBND tỉnh, Sở, ngành |
| 8 | Quy chế, quy định nội bộ của Trường |

☐ Không viện dẫn văn bản cấp dưới trái với văn bản cấp trên (sai → **Mức 1**)
☐ Khi nhiều văn bản cùng điều chỉnh một vấn đề: áp dụng theo thứ bậc và nguyên tắc **văn bản mới thay thế văn bản cũ**
☐ Khi quy chế nội bộ Trường **chặt hơn** quy định pháp luật chung và không vi phạm pháp luật → **ưu tiên áp dụng quy chế nội bộ**, nêu rõ trong báo cáo là đang áp theo quy chế nào

## 3. Bốn hệ quy chiếu — không áp lẫn

| Hệ | Văn bản chuẩn | Skill |
|---|---|---|
| Hành chính nhà nước | Nghị định 30/2020/NĐ-CP + Phụ lục I; TB 597/TB-CĐKT | 02, 14, checklist 01 |
| Văn bản của Đảng | **Hướng dẫn 05-HD/VPTW ngày 27/5/2026** (thể thức, kỹ thuật trình bày); Quy định 399-QĐ/TW ngày 09/01/2026 (thể loại, thẩm quyền) | 29 + `29-Phu-Luc-2` + `29-Phu-Luc-3` |
| Quy phạm pháp luật | Luật BHVBQPPL; NĐ 34/2016/NĐ-CP sửa đổi bởi NĐ 154/2020/NĐ-CP | 30 |
| **Đoàn thể** (Công đoàn, Đoàn TN, Hội SV) | Quy định của tổ chức cấp trên tương ứng; mẫu 3.1–3.3 Phụ lục TB 597 | `09-Checklist-He-D-Doan-The.md` (tách D1 Công đoàn / D2 Đoàn TN / D3 Hội SV) + `08-Quy-Uoc-Rieng-CDKT.md` mục 7.3 |

### Văn bản của Đảng — hai điểm về hiệu lực

☐ **HD 05-HD/VPTW đã thay thế HD 36-HD/VPTW ngày 04/3/2018**, đồng thời **bãi bỏ** CV 5053-CV/VPTW ngày 11/3/2019 và CV 3294-CV/VPTW/nb ngày 11/3/2019. Dự thảo còn dẫn các văn bản này → **căn cứ lỗi thời, Mức 1**
☐ **QĐ 399-QĐ/TW đã thay thế** QĐ 66-QĐ/TW ngày 06/02/2017 và QĐ 223-QĐ/TW ngày 06/3/2020
☐ **QĐ 208-QĐ/TW ngày 26/7/2026** thay đổi tên gọi loại hình tổ chức đảng cấp cơ sở — **bắt buộc đọc `../Skill-Library/29-Phu-Luc-3-Tai-Co-Cau-To-Chuc-Dang-2026.md`** trước khi nhận xét về tên cơ quan ban hành hoặc thẩm quyền theo cấp. Văn bản dùng tên gọi hệ **cũ không đương nhiên là lỗi** (điều khoản chuyển tiếp Chương VIII mục 3) → chỉ nêu ở **Mức 4**

## 4. Lĩnh vực có nhiều sửa đổi — phải tra thêm văn bản hướng dẫn mới nhất

Giáo dục, y tế, đất đai, đầu tư, thuế, ngân sách, viên chức, lưu trữ.

☐ Ngoài luật/nghị định gốc, tra thêm thông tư, quyết định của Bộ trưởng/cơ quan có thẩm quyền để bảo đảm bản cập nhật nhất
☐ **Khi viện dẫn văn bản có bản sửa đổi bổ sung, phải tra kèm cả hai và ghi rõ điều khoản nào đã bị sửa** — không chỉ dẫn văn bản gốc hoặc chỉ dẫn văn bản sửa đổi riêng lẻ

**Các cặp đã biết trong kho cần xác nhận trước khi viện dẫn**:
- NĐ 60/2021/NĐ-CP ↔ **NĐ 111/2025/NĐ-CP** (quy định **chung** về tự chủ tài chính ĐVSNCL) và
  **NĐ 334/2026/NĐ-CP** (quy định **chuyên ngành** cho cơ sở GDĐH, GDNN; hiệu lực 05/10/2026).

  > **Đã kiểm từ chính văn** `01-Legal-Database/01-04/ND-334-2026-ND-CP_v1.docx`: **Điều 16 của NĐ 334
  > KHÔNG có khoản bãi bỏ nào** — NĐ 60/2021 và NĐ 111/2025 **vẫn còn hiệu lực**. Hơn nữa, NĐ 334 Điều 7
  > khoản 3 điểm a **dẫn chiếu ngược** về *"quy định của Chính phủ về cơ chế tự chủ tài chính của đơn vị sự
  > nghiệp công lập"* — tức chính NĐ 60/111. Không được kết luận "thay thế".

  **Quy tắc viện dẫn — quyền quyết định thuộc ĐƠN VỊ SOẠN THẢO.** Tùy từng **nội dung tự chủ cụ thể**,
  đơn vị soạn thảo xem xét và viện dẫn nghị định phù hợp, đúng quy định với nội dung đó. **Hệ không tự
  quyết thay**: không có quy tắc "đổi hết sang NĐ 334", cũng không có quy tắc "luôn dẫn cả hai".

  Định hướng tham khảo *(không phải quy định cứng — xem đầy đủ tại `../Skill-Library/00d-Ghi-Nho-ND-334-2026-Pham-Vi-Co-So-GDNN.md` mục 3)*:
  nội dung về hoạt động đào tạo, KH-CN, tổ chức nhân sự, quyền tự quyết nguồn tài chính, thẩm quyền người
  đứng đầu về định mức, đặt hàng đào tạo → thường thuộc **NĐ 334**; nội dung về **trích lập và sử dụng các quỹ
  từ chênh lệch thu – chi** → thuộc **NĐ 60/111**, do chính NĐ 334 chỉ về.

  **Khi rà soát:**
  - **KHÔNG nêu "căn cứ đã hết hiệu lực" (Mức 1)** với NĐ 60/111 — hai nghị định đó còn hiệu lực.
  - **KHÔNG tự đổi** căn cứ của dự thảo từ nghị định này sang nghị định kia.
  - Thấy dấu hiệu nghị định được viện dẫn **chưa khớp với nội dung tự chủ đang quy định** → nêu **Mức 4**,
    mô tả rõ nội dung nào và vì sao thấy chưa khớp, **đề nghị đơn vị soạn thảo rà lại và tự quyết**.
  - Không chắc → **hỏi người dùng, không suy đoán**.

  **Chuyển tiếp (NĐ 334 Điều 15)**: chương trình, đề án, hợp đồng đặt hàng đã phê duyệt trước 05/10/2026
  tiếp tục đến hết thời hạn; giai đoạn 01/7/2026 → 05/10/2026 áp dụng quy định trước 01/7/2026. Văn bản cũ
  của Trường đang dẫn NĐ 60/111 → **không nêu lỗi**.
- Luật Thi đua khen thưởng số 06/2022/QH15 và Luật sửa đổi số 06/2026/QH16
- Luật BHVBQPPL gốc và Luật sửa đổi số 87 — **chưa xác định bản hợp nhất hiện hành**
- QĐ 49/QĐ-CĐKT (24/7/2025) → QĐ 988/QĐ-CĐKT (12/5/2026) → đã bị **QĐ 1976/QĐ-CĐKT (14/9/2026)** thay thế (hiệu lực từ ngày ký)
- QĐ 215/QĐ-CĐKT (15/02/2024) → đã bị **QĐ 389/QĐ-CĐKT (26/02/2026)** thay thế
- QĐ 50/QĐ-CĐKT (25/7/2025) → đã bị **QĐ 1299/QĐ-CĐKT (27/5/2026)** thay thế (Quy chế làm việc)
  > ⚠️ Không nhầm với **QĐ 1229/QĐ-CĐKT ngày 22/9/2023** — đó là Quy chế đào tạo, kiểm tra, thi và xét công nhận tốt nghiệp GDNN, một văn bản hoàn toàn khác. Hai số hiệu chỉ khác nhau một chữ số.
- QĐ 1060/QĐ-CĐKT (09/8/2024) → đã bị **QĐ 1400/QĐ-CĐKT (12/6/2026)** thay thế (chế độ làm việc nhà giáo)
- TB 340/TB-CĐCĐ (13/6/2023) và CV 109/CĐCĐ-HCQT (14/5/2020) → đã bị **TB 597/TB-CĐKT (19/5/2026)** thay thế (thể thức, kỹ thuật trình bày)

## 5. Không tự ý bổ sung căn cứ

☐ Không tự thêm căn cứ pháp lý mà dự thảo không đề cập, **trừ khi** cần thiết để bảo đảm tính hợp pháp
☐ Khi bổ sung: trình bày theo **dòng riêng, dễ nhận diện**, dạng:
> `Đề xuất bổ sung căn cứ pháp lý: [tên văn bản, số hiệu, ngày ban hành] — lý do: [...]`
☐ Nêu rõ đây là **"đề xuất bổ sung"**, không phải nội dung hiện có của dự thảo

## 6. Bảng ghi nhận kết quả xác minh

| Văn bản viện dẫn trong dự thảo | Có trong kho 01-04? | Trạng thái hiệu lực | Nguồn xác minh | Ngày xác minh |
|---|---|---|---|---|
| | | Còn / Hết / **Hết một phần** / Chưa có hiệu lực / **Chưa xác minh** | Kho 01-04 / **phapluat.gov.vn (kèm URL)** / vbpl.vn / Công báo / **Không có công cụ** | |

☐ Bảng này đưa vào **Phần I** của báo cáo rà soát (mục Danh mục tài liệu đối chiếu và Phạm vi xác minh)

## 7. Điều kiện đạt
Toàn bộ căn cứ đủ, đúng thứ bậc, còn hiệu lực và đã được ghi rõ trạng thái xác minh. Mọi nội dung chưa xác minh được đều đã công bố rõ trong Phần I thay vì im lặng bỏ qua.

## 8. Liên quan
`02-Noi-Dung.md` · `../Skill-Library/03-Skill-Kiem-Tra-Can-Cu.md` · `../Skill-Library/17-Skill-Kiem-Tra-Tham-Quyen.md` · `../Nguyen-Tac/00-Quy-Tac-Khai-Thac-Internet.md` · `../Skill-Library/04-Nguyen-Tac-Nap-Van-Ban-Tu-Internet.md`
