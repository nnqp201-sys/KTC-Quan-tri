# 08-Quy-Uoc-Rieng-CDKT — Quy ước riêng của Trường Cao đẳng Kon Tum

**Áp dụng**: khi cơ quan ban hành là Trường Cao đẳng Kon Tum · **Dùng cùng** checklist 01–07 · **Bắt buộc ở cả 4 tác vụ** (rà soát chính thức, rà soát nhanh, so sánh, chuẩn hóa)

Thuộc gói ktc-ra-soat-897 **v2.9**, cập nhật ngày 31/8/2026.

---

## 1. Căn cứ ban hành — Quyết định 1976/QĐ-CĐKT

**Quy tắc**: căn cứ đầu tiên phải là **Quyết định số 1976/QĐ-CĐKT ngày 14/9/2026 của Hiệu trưởng** ban hành Quy chế tổ chức và hoạt động của Trường.

**Chỉ áp dụng khi thỏa ĐỒNG THỜI cả hai điều kiện:**
- (a) Loại văn bản là **quyết định**, VÀ
- (b) thuộc **thẩm quyền ban hành của Hiệu trưởng** — kể cả khi Phó Hiệu trưởng ký thay (KT.) theo ủy quyền.

**Không áp dụng khi**: văn bản do đơn vị khác của Trường ban hành theo thẩm quyền riêng; hoặc là công văn, kế hoạch, thông báo, báo cáo, tờ trình...

**Không áp dụng cho văn bản của Đảng ủy/chi bộ Trường và văn bản đoàn thể** — các hệ thống độc lập.

| Kiểm tra | Kết luận |
|---|---|
| Thỏa (a) và (b), có QĐ 1976 ở vị trí đầu | Đạt — **không được coi là lỗi** |
| Thỏa (a) và (b), thiếu hoặc xếp sai vị trí | Mức 1 – Bắt buộc sửa |
| Không thỏa đồng thời (a) và (b) | **Không áp dụng quy tắc này — không được bắt lỗi "thiếu căn cứ QĐ 1976"** |

**Lưu ý hiệu lực — chuỗi 3 đời, đối chiếu theo NGÀY BAN HÀNH của dự thảo đang rà soát:**

| Dự thảo ban hành | Căn cứ đúng | Nếu dẫn văn bản khác |
|---|---|---|
| Từ **14/9/2026** trở đi | **QĐ 1976/QĐ-CĐKT ngày 14/9/2026** | Dẫn QĐ 988 hoặc QĐ 49 → **Mức 1** |
| Từ 12/5/2026 đến trước 14/9/2026 | QĐ 988/QĐ-CĐKT ngày 12/5/2026 | Đúng tại thời điểm ban hành — **không nêu là lỗi** |
| Trước 12/5/2026 | QĐ 49/QĐ-CĐKT ngày 24/7/2025 | Đúng tại thời điểm ban hành — **không nêu là lỗi** |

QĐ 1976/QĐ-CĐKT **có hiệu lực kể từ ngày ký (14/9/2026)** và thay thế QĐ 988/QĐ-CĐKT ngày 12/5/2026
(Điều 2 của chính QĐ 1976). Quy chế kèm theo có **9 Chương, 40 Điều**. Người ký: Hiệu trưởng Lê Trí Khải.

**Không hồi tố**: văn bản cũ còn hiệu lực mà đang dẫn QĐ 988 **không tự động thành sai** — chỉ nêu
**Mức 4** đề nghị rà soát cập nhật khi có dịp sửa đổi, không nâng lên Mức 1/2.

**Thứ tự căn cứ chung (NĐ 30)**: nhóm căn cứ thẩm quyền/chức năng nhiệm vụ xếp trước, nhóm căn cứ nội dung xếp sau.

---

## 2. Cách viết từ ngữ

| Viết đúng | Viết sai thường gặp | Mức độ |
|---|---|---|
| **bảo đảm** | đảm bảo | Mức 3 – Nên sửa |
| **nhà trường** (viết thường) | Nhà trường | Mức 3 – Nên sửa |

- "nhà trường" chỉ viết hoa khi bắt buộc theo quy định chung: đứng đầu câu, sau dấu chấm, sau dấu hai chấm, trong tên riêng.
- Áp dụng cho **mọi hệ thống văn bản** của Trường.

---

## 2b. Viết hoa sau dấu hai chấm (:) — Quy ước riêng của Trường *(Bổ sung 23/8/2026)*

> ⚠️ **Đây là quy ước riêng của Trường theo TB 597/TB-CĐKT (Mục 3.1) — khác với NĐ 30/2020.** Khi NĐ 30 và quy ước Trường xung đột, áp dụng quy ước Trường cho văn bản của Trường Cao đẳng Kon Tum.

**Quy tắc**: Sau dấu hai chấm (:), **viết hoa chữ đầu** khi theo sau là:
- Tên cơ quan, đơn vị, tổ chức (phòng, khoa, bộ môn, ban...)
- Tên chức danh, chức vụ người ký
- Tên văn bản, tên cơ sở, tên riêng

**Ví dụ đúng:**
- `Đơn vị soạn thảo: Phòng Quản lý Đào tạo và Bảo đảm chất lượng`
- `Thẩm quyền: Hiệu trưởng`
- `Kính gửi: Ủy ban nhân dân tỉnh Quảng Ngãi`

**Ví dụ sai:**
- `Đơn vị soạn thảo: phòng Quản lý Đào tạo...` ← "phòng" phải viết hoa thành "Phòng"

**Phân loại**: Mức 3 – Nên sửa (quy ước riêng Trường, không phải lỗi pháp lý).

**Phạm vi kiểm tra**: Toàn bộ văn bản — đặc biệt các trường: Đơn vị soạn thảo, Thẩm quyền, Kính gửi, Kèm theo, căn cứ viện dẫn, liệt kê trong nội dung.

---

## 3. Tên đơn vị, tổ chức thuộc Trường
*(Căn cứ: Thông báo 597/TB-CĐKT ngày 19/5/2026; Quyết định 1355/QĐ-CĐKT ngày 03/6/2026)*

### 3.1. Quy tắc viết hoa
- **Phòng, khoa, bộ môn**: từ "phòng", "khoa", "bộ môn" viết **thường**; cụm từ chỉ tên viết hoa.
 - Đúng: `phòng Tổng hợp - Hành chính và Quản trị`, `khoa Y - Dược`, `bộ môn Ngoại ngữ`
 - Viết hoa chữ đầu chỉ khi đứng đầu dòng, sau dấu chấm, **sau dấu hai chấm** (xem Mục 2b).
- **Đơn vị đặc thù, chỉ có một** — viết hoa như danh từ riêng: `Ban Truyền thông`, `Ban Văn – Thể – Mỹ`, `Phòng khám Đa khoa`, `Nhà thuốc Phòng khám Đa khoa`.
- **Tên cơ sở** — viết hoa trong mọi tình huống.
- **Dấu phân cách khi liệt kê tên đơn vị trong cùng đoạn**: dùng dấu **phẩy (,)**, không dùng chấm phẩy (;).

### 3.2. Danh mục 5 cơ sở và địa chỉ

| Cơ sở | Viết tắt | Địa chỉ đầy đủ |
|---|---|---|
| Trụ sở chính (Cơ sở 1) | TSC hoặc CS1 | Số 14 Nguỵ Như Kon Tum, Tổ 10, phường Đăk Cấm, tỉnh Quảng Ngãi |
| Cơ sở 2: Khoa Kinh tế - Nông Lâm và Khu thực nghiệm | CS2 hoặc Khoa KT-NL&KTN | Đường Võ Nguyên Giáp, Tổ 10, phường Đăk Cấm, tỉnh Quảng Ngãi |
| Cơ sở 3: Khoa Y - Dược | CS3 hoặc Khoa Y-D | Số 347 Bà Triệu, Tổ 8, phường Kon Tum, tỉnh Quảng Ngãi |
| Cơ sở 4: Khoa Kỹ thuật - Công nghệ và Đào tạo - Sát hạch lái xe | CS4 hoặc Khoa KT-CN&ĐT-SHLX | Đường Trương Vĩnh Ký, Tổ 5, phường Đăk Bla, tỉnh Quảng Ngãi |
| Cơ sở 5: Khoa các Khoa học cơ bản | CS5 hoặc Khoa CKHCB | Đường Nguyễn Thị Định, Tổ 10, phường Đăk Cấm, tỉnh Quảng Ngãi |

### 3.3. Danh mục 15 bộ môn (bản hiện hành, cập nhật 17/8/2026)

bộ môn Giáo dục Mầm non và Nghệ thuật · bộ môn Khoa học giáo dục và Tiếng Việt · bộ môn Y học cơ sở và Dược · bộ môn Lâm sàng – Y tế công cộng và Điều dưỡng · bộ môn Lý luận chính trị và Giáo dục thể chất · bộ môn Tự nhiên và Xã hội · bộ môn Công nghệ thông tin · bộ môn Ngoại ngữ · bộ môn Kinh tế - Du lịch và Pháp lý · bộ môn Nông Lâm nghiệp · bộ môn Chăn nuôi – Thú y và Thuỷ sản · bộ môn Cơ khí và Xây dựng · bộ môn Điện - Điện tử và Công nghệ May · bộ môn Đào tạo lái xe ô tô · bộ môn Đào tạo và Sát hạch lái xe mô tô

> ⚠️ **Chỉ dùng danh mục 15 bộ môn ở trên.** Danh mục cũ (14 bộ môn) đã hết giá trị áp dụng.

### 3.4. Bảng chữ viết tắt 18 đơn vị (TB 597 mục 3.1c)

| Tên đơn vị | Chữ viết tắt tên **đơn vị soạn thảo văn bản** | Chữ viết tắt **tên đơn vị** |
|---|---|---|
| phòng Tổng hợp – Hành chính và Quản trị | THHCQT | Phòng TH-HC&QT |
| phòng Tổ chức cán bộ và Công tác học sinh – sinh viên | TCCB | Phòng TCCB&CTHSSV |
| phòng Tài chính – Kế toán | TCKT | Phòng TC-KT |
| phòng Quản lý Đào tạo và Bảo đảm chất lượng | QLĐT | Phòng QLĐT&BĐCL |
| phòng Quản lý khoa học công nghệ và Hợp tác phát triển | QLKHCN | Phòng QLKHCN&HTPT |
| khoa các Khoa học cơ bản | KHCB | Khoa CKHCB |
| khoa Sư phạm | KSP | Khoa SP |
| khoa Y – Dược | KYD | Khoa Y-D |
| khoa Kỹ thuật và Công nghệ | KTCN | Khoa KT&CN |
| khoa Kinh tế và Nông Lâm | KTNL | Khoa KT&NL |
| khoa Đào tạo và Sát hạch lái xe | ĐTSHLX | Khoa ĐT&SHLX |
| Ban Truyền thông | BTT | BTT |
| Ban Văn – Thể – Mỹ | VTM | Ban VTM |
| Phòng khám Đa khoa | PKĐK | PKĐK |
| Nhà thuốc Phòng khám Đa khoa | NTPKĐK | NTPKĐK |
| Đoàn Thanh niên | ĐTN | ĐTN |
| Hội Sinh viên | HSV | HSV |
| Công đoàn cơ sở Trường | CĐCS | CĐCS |

☐ **Hai cột viết tắt KHÔNG được dùng lẫn** (TB 597 mục 3.1c, phần Lưu ý):

- **Cột giữa** = viết tắt tên đơn vị **soạn thảo**. Dùng ở phần số, ký hiệu văn bản và dòng `Lưu:` trong Nơi nhận. Ví dụ: `Số:      123/TB-THHCQT` và `- Lưu: VT, THHCQT.`
- **Cột phải** = viết tắt **tên đơn vị**. Dùng khi nhắc tên đơn vị trong hành văn, sơ đồ tổ chức và các nội dung khác. Ví dụ: `Phòng TH-HC&QT chủ trì thực hiện`.
- Dùng sai cột → Mức 2.

> ⚠️ **Không mở rộng cột giữa sang phần liệt kê nơi nhận** *(bổ sung 08/9/2026)*: cột giữa chi phối dòng `Lưu:`, **không** chi phối tên các đơn vị **được nhận** văn bản. Mẫu chính thức tại TB 597 ghi đầy đủ:
>
> `Nơi nhận:` / `- Lãnh đạo Trường;` / `- Đảng ủy Trường;` / `- Công đoàn Trường;` / `- Đoàn Trường;` / `- Hội Sinh viên Trường;` / `- Các đơn vị thuộc Trường;` / `- Lưu: VT, THHCQT.`
>
> Vì vậy **tuyệt đối không bắt lỗi** khi Nơi nhận ghi `- Công đoàn Trường;` hoặc `- Đoàn Trường;` thay cho `- CĐCS;` / `- ĐTN;`. Chính văn bản quy ước dùng cách ghi đầy đủ này.

> ✏️ **Sửa lỗi ngày 31/8/2026 (xác nhận Phòng TH-HC&QT):**
> 1. Viết tắt hành văn chuẩn của "phòng Tổng hợp - Hành chính và Quản trị" là **"Phòng TH-HC&QT"** (CÓ gạch nối giữa TH và HC) — trước đây ghi sai thành "Phòng THHC&QT" (không gạch nối).
> 2. **[Đính chính 09/9/2026 — đảo ngược kết luận cũ, đối chiếu trực tiếp TB 597 mục 3.1c và QĐ 1355/QĐ-CĐKT ngày 03/6/2026 "đặt tên các cơ sở"]**: tên khoa viết đúng là **"Kinh tế và Nông Lâm"** (chữ "Lâm" viết **hoa**, viết tắt **KT&NL**). Kết luận trước đây (ghi ngày 31/8/2026, tự nhận đã "xác nhận bởi Phòng TH-HC&QT") sửa thành "Nông lâm" (lâm thường) là **sai chiều** — cả TB 597 (bảng viết tắt lẫn câu văn Điều mục 2) và QĐ 1355 (Điều 1, Điều 2.1, Điều 2.2) đều dùng "Nông Lâm" (Lâm hoa) khi nói tên khoa, không riêng gì tên Cơ sở 2. Phân biệt thật giữa 2 tên gọi **không nằm ở chữ hoa/thường của "Lâm"** mà ở cấu trúc: tên **cơ sở** (Điều 2.1 QĐ 1355, viết hoa trong mọi tình huống) là `Cơ sở 2: Khoa Kinh tế - Nông Lâm và Khu thực nghiệm` (có dấu gạch nối, có thêm "và Khu thực nghiệm"); tên **khoa/đơn vị** (Điều 2.2 QĐ 1355 = TB 597, "khoa" viết thường khi không đứng đầu câu) là `khoa Kinh tế và Nông Lâm` — hai tên khác nhau ở cấu trúc câu, cùng viết "Lâm" hoa ở cả hai. Không được tự ý sửa "Nông Lâm" thành "Nông lâm" khi đang nói về Khoa.

### 3.5. Kiểm tra tên cơ sở khi xuất hiện trong nội dung văn bản *(cập nhật 23/8/2026)*

> ⚠️ Áp dụng cho **tất cả 5 cơ sở**, không chỉ riêng Cơ sở 4.

**Từ khóa cần quét**: `Cơ sở`, `CS1`, `CS2`, `CS3`, `CS4`, `CS5`, `Trụ sở chính`, `Kỹ thuật`, `Công nghệ`, `lái xe`, `Trung tâm`, `Nông Lâm`, `Y - Dược`, `Khoa học cơ bản`.

**Bảng tên cũ — SAI và cần phát hiện:**

| Tên cũ (SAI — không dùng) | Tên đúng hiện hành | Mức |
|---|---|---|
| "Khoa Kỹ thuật – Công nghệ và các Trung tâm" | **Cơ sở 4: Khoa Kỹ thuật - Công nghệ và Đào tạo - Sát hạch lái xe** | Mức 1 |
| "Khoa KT-CN và các Trung tâm" | **Khoa KT-CN&ĐT-SHLX** hoặc **CS4** | Mức 1 |
| "khoa Kỹ thuật Công nghệ" (thiếu phần Đào tạo lái xe) | **khoa Kỹ thuật - Công nghệ và Đào tạo - Sát hạch lái xe** | Mức 1 |
| Tên bất kỳ cơ sở nào không khớp bảng Mục 3.2 | Tên đúng theo Mục 3.2 | Mức 1 |
| Tên cơ sở viết tắt không đúng mẫu | Xem cột "Viết tắt" Mục 3.2 | Mức 2 |

---

## 4. Thông số thể thức riêng của Trường
*(TB 597/TB-CĐKT thu hẹp khoảng dao động của NĐ 30 thành số cứng — áp dụng số của Trường)*

| Thành phần | TB 597 (áp dụng) | NĐ 30 (khoảng cho phép) |
|---|---|---|
| Quốc hiệu | in hoa, **cỡ 13**, đứng, đậm | 12–13 |
| Tiêu ngữ | in thường, **cỡ 14**, đứng, đậm; đường kẻ dùng lệnh Draw, **không dùng Underline** | 13–14 |
| Tên cơ quan chủ quản | in hoa, **cỡ 13**, đứng | 12–13 |
| Tên đơn vị ban hành | in hoa, **cỡ 13**, đứng, đậm | 12–13 |
| Số, ký hiệu | "Số" in thường, ký hiệu in hoa, **cỡ 13**, đứng. Sau "Số:" để trống tối thiểu 6 ký tự; số nhỏ hơn 10 thêm số 0 phía trước | 13 |
| Địa danh, ngày tháng | in thường, **cỡ 14**, nghiêng | 13–14 |
| Tên loại văn bản | in hoa, **cỡ 14**, đứng, đậm | 13–14 |
| Trích yếu (có tên loại) | in thường, **cỡ 14**, đứng, đậm | 13–14 |
| Trích yếu công văn | in thường, **cỡ 13**, đứng; đặt canh giữa dưới số ký hiệu, cách dòng **6pt** | — |
| Căn cứ ban hành | in thường, **nghiêng, cỡ 14** | 13–14 |
| Nội dung | in thường, đứng, **cỡ 14**, dàn đều hai lề; thụt đầu dòng 1–1,27cm; cách đoạn tối thiểu 6pt | 13–14 |
| Quyền hạn, chức vụ người ký | in hoa, **cỡ 14**, đứng, đậm | 13–14 |
| Họ tên người ký | in thường, **cỡ 14**, đứng, đậm | 13–14 |
| "Kính gửi" và tên nơi nhận | in thường, **cỡ 14**, đứng | 13–14 |
| Từ "Nơi nhận" | in thường, **cỡ 12**, nghiêng, đậm, dòng riêng, sát lề trái | 12 |
| Danh sách nơi nhận | in thường, **cỡ 11**, đứng | 11 |

**Ký hiệu văn bản**: `Số: /BC-CĐKT`, `/TTr-CĐKT`, `/TB-CĐKT`, `/QĐ-CĐKT`. Công văn: `/CĐKT-<viết tắt đơn vị soạn thảo>`.

---

## 5. Quyền hạn ký và các quy tắc bổ sung

### 5.1. Ba hình thức ký thay — đủ cả TUQ.

| Trường hợp | Cách ghi |
|---|---|
| Phó Hiệu trưởng ký thay | `KT. HIỆU TRƯỞNG` / `PHÓ HIỆU TRƯỞNG` |
| Cấp phó được giao phụ trách | Thực hiện như cấp phó ký thay cấp trường |
| Trưởng đơn vị ký thừa lệnh | `TL. HIỆU TRƯỞNG` / `TRƯỞNG PHÒNG QUẢN LÝ ĐÀO TẠO VÀ BẢO ĐẢM CHẤT LƯỢNG` |
| Ký **thừa ủy quyền** | `TUQ. HIỆU TRƯỞNG` / `TRƯỞNG PHÒNG TỔNG HỢP - HÀNH CHÍNH VÀ QUẢN TRỊ` |

☐ Dùng `KT.` `TL.` `TUQ.` **có dấu chấm**, **không** dùng `K/T` `T/L` có gạch chéo (hệ Đảng).

### 5.2–5.4. Các quy tắc khác
☐ Ban, hội đồng không được dùng con dấu Trường → chỉ ghi chức danh trong ban/hội đồng. Ghi thừa → Mức 2.
☐ Đơn vị soạn thảo chỉ ghi tháng và năm, để trống ngày; khoảng cách 6 ký tự. Ngày <10 và tháng 1, 2 thêm số 0.
☐ Không ghi học hàm, học vị trước họ tên người ký.
☐ Viện dẫn lần đầu ghi đầy đủ; các lần sau chỉ ghi tên loại và số, ký hiệu.

---

## 6. Bảng tự kiểm nhanh

| # | Nội dung | Đạt |
|---|---|---|
| 1 | Nếu là quyết định của Hiệu trưởng: QĐ 1976/QĐ-CĐKT ở vị trí căn cứ đầu tiên | ☐ |
| 2 | Không xuất hiện từ "đảm bảo" | ☐ |
| 3 | "nhà trường" viết thường (trừ vị trí bắt buộc viết hoa) | ☐ |
| **3b** | **Sau dấu ":" là tên riêng/đơn vị/chức danh → viết hoa chữ đầu (quy ước TB 597 Mục 2b)** | **☐** |
| 4 | Tên phòng/khoa/bộ môn viết đúng quy tắc hoa–thường | ☐ |
| 5 | Tên và địa chỉ cơ sở khớp QĐ 1355 (đủ thông tin "Tổ") | ☐ |
| **5b** | **Mọi chỗ nhắc đến tên cơ sở (tất cả 5 cơ sở) trong nội dung văn bản đều khớp bảng Mục 3.2** | **☐** |
| 6 | Tên bộ môn khớp danh mục 15 bộ môn hiện hành | ☐ |
| 7 | Liệt kê tên đơn vị dùng dấu phẩy, không dùng chấm phẩy | ☐ |
| 8 | Cỡ chữ từng thành phần khớp bảng mục 4 | ☐ |
| 9 | Ký hiệu văn bản đúng mẫu, số nhỏ hơn 10 có số 0 phía trước | ☐ |
| 10 | Không ghi học hàm/học vị trước họ tên người ký | ☐ |
| 11 | Viết tắt tên đơn vị đúng cột (số/ký hiệu vs hành văn) theo bảng mục 3.4 | ☐ |
| 12 | Ngày ban hành để trống đúng cách, cách 6 ký tự; tháng 1, 2 có số 0 | ☐ |
| 13 | Ký thay dùng KT./TL./TUQ. có dấu chấm, không dùng K/T T/L của hệ Đảng | ☐ |
| 14 | Mẫu đầu văn bản khớp đúng 1 trong 9 mẫu tại Phụ lục TB 597 (mục 7) | ☐ |

---

## 7. Mẫu thể thức đầu văn bản (Phụ lục TB 597) — 9 mẫu, 3 hệ thống

> ⚠️ Trường Cao đẳng Kon Tum ban hành văn bản thuộc **BA hệ thống thể thức khác nhau**. Xác định đúng hệ trước khi rà soát (Bước 0).

### 7.1. Hệ văn bản Đảng (mẫu 1.1–1.4) — theo HD 05-HD/VPTW

| Mẫu | Cột trái | Ký hiệu | Cột phải |
|---|---|---|---|
| 1.1 Đảng ủy Trường | `ĐẢNG BỘ UBND TỈNH QUẢNG NGÃI` / `ĐẢNG ỦY TRƯỜNG CAO ĐẲNG KON TUM` / `*` | `Số -.../ĐU` | `ĐẢNG CỘNG SẢN VIỆT NAM` + địa danh, ngày |
| 1.2 Ủy ban Kiểm tra | `ĐẢNG ỦY TRƯỜNG CAO ĐẲNG KON TUM` / `ỦY BAN KIỂM TRA` / `*` | `Số -.../UBKT` | như trên |
| 1.3 Bộ phận Văn phòng Đảng ủy | `ĐẢNG ỦY TRƯỜNG CAO ĐẲNG KON TUM` / `BỘ PHẬN VĂN PHÒNG ĐẢNG ỦY` / `*` | `Số -.../BPVPĐU` | như trên |
| 1.4 Các chi bộ trực thuộc | `ĐẢNG BỘ TRƯỜNG CAO ĐẲNG KON TUM` / `CHI BỘ ...` / `*` | `Số -.../CB` | như trên |

☐ Dấu sao `*` bắt buộc với văn bản Đảng. Thiếu → Mức 2.
☐ **Trước khi nhận xét về tên cơ quan ban hành ở mẫu 1.1 và 1.4**, bắt buộc đọc `29-Phu-Luc-3-Tai-Co-Cau-To-Chuc-Dang-2026.md`.

### 7.2. Hệ hành chính nhà nước (mẫu 2.1–2.2) — theo NĐ 30

| Mẫu | Cột trái | Cột phải |
|---|---|---|
| 2.1 Văn bản Trường | `UBND TỈNH QUẢNG NGÃI` / `TRƯỜNG CAO ĐẲNG KON TUM` / `Số: /...-CĐKT` | Quốc hiệu, Tiêu ngữ, địa danh ngày |
| 2.2 Văn bản đơn vị thuộc Trường | `TRƯỜNG CAO ĐẲNG KON TUM` / `PHÒNG, KHOA...` / `Số: /...-...` | như trên |

### 7.3. Hệ đoàn thể (mẫu 3.1–3.3) — KHÔNG áp NĐ 30, KHÔNG áp HD 05

| Mẫu | Cột trái | Cột phải |
|---|---|---|
| 3.1 Công đoàn cơ sở | `LIÊN ĐOÀN LAO ĐỘNG TỈNH QUẢNG NGÃI` / `CÔNG ĐOÀN CƠ SỞ TRƯỜNG CAO ĐẲNG KON TUM` / `Số: /...-CĐCS` | Quốc hiệu, Tiêu ngữ, địa danh ngày |
| 3.2 Đoàn Thanh niên | `ĐOÀN KHỐI CQ & DN TỈNH QUẢNG NGÃI` / `BCH ĐOÀN TRƯỜNG CAO ĐẲNG KON TUM` / `***` / `Số: -.../ĐTN` | `ĐOÀN TNCS HỒ CHÍ MINH` + địa danh, ngày |
| 3.3 Hội Sinh viên | `HỘI SINH VIÊN TỈNH QUẢNG NGÃI` / `BCH TRƯỜNG CAO ĐẲNG KON TUM` / `***` / `Số: -.../HSV` | Chỉ có địa danh và ngày, **không có dòng tiêu đề tổ chức** |

> ✅ **Mẫu 3.3 trình bày như TB 597 là ĐÚNG** — Phòng TH-HC&QT xác nhận ngày 18/8/2026. **Tuyệt đối không nêu đây là lỗi thiếu tiêu đề.**

---

## 8. Văn bản bị thay thế — không nêu lỗi với văn bản ban hành trước

| Văn bản cũ | Bị thay bởi | Từ ngày |
|---|---|---|
| Thông báo 340/TB-CĐCĐ (13/6/2023) | **TB 597/TB-CĐKT** | 19/5/2026 |
| Công văn 109/CĐCĐ-HCQT (14/5/2020) | **TB 597/TB-CĐKT** | 19/5/2026 |
| QĐ 215/QĐ-CĐKT (15/02/2024) | **QĐ 389/QĐ-CĐKT** | 26/02/2026 |
| QĐ 49/QĐ-CĐKT (24/7/2025) | **QĐ 988/QĐ-CĐKT** | 12/5/2026 |
| QĐ 988/QĐ-CĐKT (12/5/2026) | **QĐ 1976/QĐ-CĐKT** (Quy chế tổ chức và hoạt động) | 14/9/2026 |
| QĐ 50/QĐ-CĐKT (25/7/2025) | **QĐ 1299/QĐ-CĐKT** (Quy chế làm việc) | 27/5/2026 |
| QĐ 1060/QĐ-CĐKT (09/8/2024) | **QĐ 1400/QĐ-CĐKT** (chế độ làm việc nhà giáo) | 12/6/2026 |

---

## Lịch sử cập nhật
- **09/9/2026 (đính chính)**: Đảo ngược v2.9 (dòng dưới) về cách viết "Nông Lâm" — đối chiếu trực tiếp TB 597 mục 3.1c và QĐ 1355/QĐ-CĐKT (03/6/2026), xác nhận đúng phải là **"Nông Lâm" (Lâm hoa)**, không phải "Nông lâm" như v2.9 đã sửa. Xem chi tiết tại Mục 3.4. `superseded_by` dòng này: kết luận "Nông lâm (lâm thường)" của v2.9 dưới đây.
- **31/8/2026 v2.9**: Sửa lỗi Mục 3.4: "Phòng THHC&QT" → "Phòng TH-HC&QT" (có gạch nối); "khoa Kinh tế và Nông Lâm" → "khoa Kinh tế và Nông lâm" (lâm thường, phân biệt với tên Cơ sở 2). Xác nhận bởi Phòng TH-HC&QT. **[Đã bị đảo ngược 09/9/2026 — xem dòng trên]**
- **23/8/2026 v2.8**: Bổ sung Mục 2b (viết hoa sau dấu ":"), mở rộng Mục 3.5 (tất cả 5 cơ sở), bổ sung câu 3b và 5b Bảng tự kiểm. **Chuyển về đúng vị trí: KTC-Ra-Soat-897-v2-Cai-tien/references/Checklist/** (trước đây nằm nhầm tại KTC-Database/02-KTC-Regulations).
- **22/8/2026 v2.7**: Bổ sung Mục 3.5 — kiểm tra tên cơ sở trong nội dung (ban đầu chỉ Cơ sở 4).
- **18/8/2026 v2.6**: Phiên bản đầu tiên chính thức.

**Nguồn**: TB 597/TB-CĐKT (19/5/2026) · QĐ 1355/QĐ-CĐKT (03/6/2026) · QĐ 1976/QĐ-CĐKT (14/9/2026) · NĐ 30/2020/NĐ-CP

**Người kiểm tra**: Phòng TH-HC&QT · **Trạng thái**: Bản nháp đang hoàn thiện
