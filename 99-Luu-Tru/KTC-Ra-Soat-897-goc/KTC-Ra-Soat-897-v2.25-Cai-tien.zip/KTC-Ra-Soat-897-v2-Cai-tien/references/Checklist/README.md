# Checklist — Bộ kiểm tra rà soát văn bản (9 checklist)

## Danh mục

| File | Nội dung | Ngôn ngữ/Tình trạng |
|---|---|---|
| `01-The-Thuc.md` | 9 thành phần thể thức bắt buộc + bổ sung, dấu, chữ ký số, quyền hạn ký. Kèm số liệu cỡ chữ theo TB 597 | Tiếng Việt, có số liệu định lượng (viết lại 18/8/2026) |
| `02-Noi-Dung.md` | Căn cứ ban hành, điều khoản bắt buộc theo 8 loại văn bản, hợp pháp - thẩm quyền, quy trình ban hành, thống nhất nội bộ | Tiếng Việt, có số liệu (viết lại 18/8/2026) |
| `03-Phap-Ly.md` | Nguyên tắc xác minh hiệu lực, thứ bậc hiệu lực pháp lý, **4 hệ quy chiếu** (A hành chính / B Đảng / C VBQPPL / D đoàn thể), danh sách cặp văn bản đã thay thế | Tiếng Việt, có số liệu (cập nhật 14/9/2026, v2.24) |
| `04-Ngon-Ngu.md` | Từ ngữ chuẩn hóa, **viết hoa sau dấu hai chấm**, **2 lỗi chính tả thể thức (UỶ/ỦY, HOÀ/HÒA)**, cụm từ mơ hồ, **quy tắc thống nhất một dạng ngày tháng (ưu tiên `05/3/2026`)**, đánh số mục | Tiếng Việt, có số liệu (bổ sung 14/9/2026, v2.24) |
| `05-Hinh-Thuc.md` | Khổ giấy, định lề, phông chữ, cách dòng, số trang; so sánh 2 hệ; cách kiểm tra thực tế từ tệp .docx | Tiếng Việt, có số liệu (viết lại 18/8/2026) |
| `06-Metadata.md` | Phiên bản và ghi chú sử dụng checklist | — |
| `07-Theo-Loai-Van-Ban.md` | Checklist bổ sung riêng theo từng loại văn bản | — |
| `08-Quy-Uoc-Rieng-CDKT.md` | **Quy ước riêng của Trường**: QĐ 1976, "bảo đảm"/"nhà trường", tên đơn vị, 5 cơ sở, 15 bộ môn, bảng 16 dòng cỡ chữ TB 597, bổ sung từ QĐ 389 | Tiếng Việt (mới 18/8/2026) |
| `09-Checklist-He-D-Doan-The.md` | **Hệ D — Đoàn thể**: tách D1 Công đoàn/D2 Đoàn Thanh niên/D3 Hội Sinh viên, mỗi tiểu-hệ 1 mẫu thể thức riêng, kèm quy tắc kiểm tra chéo bắt buộc khi hồ sơ có nhiều văn bản đoàn thể | Tiếng Việt, có số liệu (mới 31/8/2026, v2.21) |

## Cách dùng

1. **Mọi tác vụ**, khi cơ quan ban hành là Trường Cao đẳng Kon Tum → **bắt buộc** dùng `08-Quy-Uoc-Rieng-CDKT.md`.
2. Văn bản hành chính nhà nước → `01` đến `05` + `07` + `08`.
3. Văn bản của Đảng → **không dùng `01` và `05`** (thiết kế cho NĐ 30). Dùng `../Skill-Library/29-Skill-Van-Ban-Dang.md`, `29-Phu-Luc-2-Co-Chu-Kieu-Chu-VB-Dang.md`, `29-Phu-Luc-3-Tai-Co-Cau-To-Chuc-Dang-2026.md`, cộng `02` `03` `04` `08`.
4. Văn bản quy phạm pháp luật → `../Skill-Library/30-Skill-Van-Ban-Quy-Pham-Phap-Luat.md`, cộng `02` `03` `04`.
5. Văn bản đoàn thể (Công đoàn/Đoàn Thanh niên/Hội Sinh viên) → **bắt buộc** `09-Checklist-He-D-Doan-The.md` (tách 3 tiểu-hệ, không dùng chung 1 mẫu), cộng `02` `03` `04` `08` mục 7.3. **Không dùng `01` và `05`.**

## Quy ước mức độ (thống nhất Mẫu prompt 897)
Mức 1 – Bắt buộc sửa · Mức 2 – Cần sửa · Mức 3 – Nên sửa · Mức 4 – Góp ý nâng cao
