# 04-Ngon-Ngu — Checklist ngôn ngữ và chất lượng soạn thảo

**Nhóm ưu tiên**: thứ 7 (chất lượng diễn đạt). Không dành trọng tâm cho nhóm này khi văn bản còn tồn tại lỗi pháp lý hoặc lỗi thẩm quyền chưa nêu rõ.

## 1. Từ ngữ bắt buộc chuẩn hóa

| Viết đúng | Viết sai | Mức | Đạt |
|---|---|---|---|
| **bảo đảm** | đảm bảo | Mức 3 | ☐ |
| **nhà trường** (viết thường) | Nhà trường | Mức 3 | ☐ |

- "nhà trường" chỉ viết hoa khi bắt buộc: đứng đầu câu, sau dấu chấm, sau dấu hai chấm, trong tên riêng.
- Áp dụng cho **mọi hệ thống văn bản** của Trường (hành chính nhà nước và Đảng).

## 2. Viết hoa sau dấu hai chấm — quy ước riêng của Trường

**Căn cứ**: TB 597/TB-CĐKT mục 3.1 và `08-Quy-Uoc-Rieng-CDKT.md` mục 2b — **không phải NĐ 30/2020**. Vì vậy phân loại **Mức 3 – Nên sửa**, không được nâng lên Mức 1/2.

☐ Quét mọi vị trí sau dấu `:` — đặc biệt: `Đơn vị soạn thảo:`, `Thẩm quyền:`, `Kính gửi:`, `Nơi nhận:`, `Kèm theo:`, đầu dòng căn cứ viện dẫn nếu có dấu hai chấm
☐ Tên phòng, khoa, bộ môn: từ "phòng", "khoa", "bộ môn" viết **thường**; cụm từ chỉ tên riêng viết hoa
☐ Viết hoa chữ đầu **chỉ khi** đứng đầu dòng, sau dấu chấm, hoặc **sau dấu hai chấm**

> Ví dụ lỗi: *"Đơn vị soạn thảo: **p**hòng Quản lý Đào tạo và Bảo đảm chất lượng"* → đúng: *"Đơn vị soạn thảo: **P**hòng Quản lý Đào tạo và Bảo đảm chất lượng"*

## 3. Hai lỗi chính tả thể thức hệ thống — quét toàn văn, không chỉ tiêu đề

| Viết sai | Viết đúng | Mức |
|---|---|---|
| UỶ BAN | **ỦY BAN** | Mức 3 |
| CỘNG HOÀ | **CỘNG HÒA** | Mức 3 |

☐ Đã quét **toàn văn bản** (kể cả nơi nhận, phụ lục, chân trang), không dừng ở vị trí đầu tiên tìm thấy

## 4. Từ ngữ cần hạn chế trong văn phong hành chính

| Nhóm | Ví dụ | Hướng xử lý |
|---|---|---|
| Cụm từ cảm tính | "vô cùng quan trọng", "hết sức cần thiết", "rất mong" | Bỏ hoặc thay bằng diễn đạt khách quan |
| "mong muốn" dùng để nêu **yêu cầu** | "nhà trường mong muốn các đơn vị nộp trước ngày..." | → "nhà trường **yêu cầu**..." (giữ "mong muốn" khi thực sự là nguyện vọng) |
| Diễn đạt rườm rà, thừa từ | "đang thực hiện việc tổ chức triển khai" | → "đang triển khai" |
| | "tiến hành thực hiện công tác kiểm tra" | → "kiểm tra" |
| Tiếng nước ngoài khi đã có từ tiếng Việt | deadline, KPI (khi chưa chú thích) | Dùng từ tiếng Việt hoặc chú thích lần đầu |
| Từ đa nghĩa, từ địa phương, từ lóng | | Thay bằng từ phổ thông, đơn nghĩa |

☐ Đã rà và đề xuất thay thế các trường hợp trên (trừ khi ngữ cảnh cho phép)

## 5. Cụm từ mơ hồ — chỉ ra và đề nghị làm rõ

| Cụm từ | Vấn đề | Đề nghị |
|---|---|---|
| "các quy định khác có liên quan" | Không xác định phạm vi | Liệt kê cụ thể hoặc bỏ |
| "kịp thời", "trong thời gian sớm nhất", "khẩn trương" | Không có mốc thời gian | Ghi mốc cụ thể (ngày/tháng) |
| "các đơn vị có liên quan" | Không xác định chủ thể | Ghi rõ tên đơn vị |
| "khi cần thiết" | Không xác định điều kiện | Nêu điều kiện cụ thể |
| "theo quy định" (không dẫn văn bản) | Không truy được căn cứ | Dẫn số hiệu văn bản |

☐ Ngoại lệ: chấp nhận từ ngữ khái quát khi **cần thiết và phù hợp** với tính chất loại văn bản (ví dụ điều khoản quét trong quy chế)
☐ Khi nêu, mô tả thêm **hệ quả thực tế**: *"điều khoản chưa rõ ràng, có thể dẫn đến cách hiểu khác nhau giữa các đơn vị thực hiện, gây khó khăn khi phân định trách nhiệm"* — hệ quả phải dựa trên nội dung thực tế, không suy diễn xa

## 6. Tên cơ quan, tổ chức, chức danh

☐ Viết đầy đủ, chính xác theo tên gọi chính thức (theo quyết định thành lập hoặc văn bản quy định về tổ chức)
☐ **Không tự ý viết tắt tùy tiện**; chữ viết tắt phải đã được quy định hoặc chú thích rõ lần đầu
☐ **Nhất quán xuyên suốt** — không đổi qua lại giữa các từ đồng nghĩa để chỉ cùng một đối tượng (ví dụ "Trung tâm" – "Cơ sở" – "Đơn vị")
☐ Quy tắc viết hoa phòng/khoa/bộ môn, danh mục 5 cơ sở, 15 bộ môn, bảng chữ viết tắt tên đơn vị: xem **`08-Quy-Uoc-Rieng-CDKT.md` mục 3**
☐ Dấu phân cách khi liệt kê tên đơn vị trong cùng đoạn: **dấu phẩy (,)**, không dùng chấm phẩy (;)

## 7. Ngày tháng và số liệu

| # | Quy tắc | Đạt |
|---|---|---|
| 1 | **Chỉ dùng MỘT cách trình bày ngày tháng năm trong toàn văn bản.** Đã chọn dạng rút gọn `05/3/2026` thì mọi chỗ đều rút gọn; đã chọn dạng đầy đủ `ngày 05 tháng 3 năm 2026` thì mọi chỗ đều đầy đủ — **không xen lẫn hai dạng** | ☐ |
| 1b | **Dạng ưu tiên của Trường: rút gọn `05/3/2026`.** Khi dự thảo chưa nhất quán và phải chọn lại một dạng, **đề nghị quy về dạng rút gọn**. Dự thảo dùng dạng đầy đủ **một cách nhất quán** thì **KHÔNG phải lỗi** — chỉ nêu **Mức 4** gợi ý chuyển sang dạng ưu tiên, không nâng Mức 3 | ☐ |
| 2 | **Ngoại lệ duy nhất**: thành phần thể thức "địa danh, ngày tháng năm ban hành" đặt dưới Quốc hiệu – Tiêu ngữ **luôn viết dạng đầy đủ** `Quảng Ngãi, ngày ... tháng ... năm ...` (NĐ 30, Phụ lục I). Dạng này **không tính** là xen lẫn, kể cả khi phần còn lại của văn bản dùng `dd/mm/yyyy` | ☐ |
| 3 | Cách phát hiện: quét toàn văn hai mẫu `\d{1,2}/\d{1,2}/\d{4}` và `ngày ... tháng ... năm ...`. Nếu **cả hai cùng xuất hiện** ngoài phần ngày ban hành → **Mức 3**, nêu rõ từng vị trí và đề nghị quy về **dạng rút gọn** (dạng ưu tiên, xem dòng 1b) | ☐ |
| 4 | **Số 0 phía trước — chỉ hai trường hợp**: ngày **nhỏ hơn 10** và tháng **1, 2**. Tháng 3–12 **không** thêm số 0 (`ngày 05 tháng 3 năm 2026` là ĐÚNG; `tháng 03` là sai). Căn cứ: NĐ 30, Phụ lục I, Phần I mục 4 | ☐ |
| 4b | Quy tắc số 0 ở dòng trên **áp dụng cho cả dạng rút gọn**: `05/3/2026` · `05/01/2026` · `15/11/2026`. Không viết `5/3/2026` (thiếu số 0 ở ngày) cũng không viết `05/03/2026` (thừa số 0 ở tháng 3) | ☐ |
| 5 | Không lẫn lộn số và chữ khi không cần thiết ("05 (năm) ngày" chỉ dùng khi cần chống sửa chữa) | ☐ |
| 6 | Đơn vị đo, đơn vị tiền tệ ghi thống nhất | ☐ |
| 7 | Số liệu trong bảng khớp với số liệu nêu trong phần lời văn | ☐ |
| 8 | **Trích số hiệu văn bản nội bộ phải kèm ngày ban hành** — Trường có văn bản trùng số khác nội dung (ví dụ QĐ 1229 ≠ QĐ 1299/QĐ-CĐKT) | ☐ |

## 8. Chính tả, ngữ pháp, dấu câu

☐ Không lỗi chính tả, đặc biệt tên riêng, tên đơn vị, tên văn bản viện dẫn
☐ Câu đủ chủ ngữ - vị ngữ; không câu cụt, không câu dài quá 3 dòng gây tối nghĩa
☐ Không lặp ý giữa các đoạn
☐ Dấu câu đúng: cuối mỗi căn cứ dấu `;`, căn cứ cuối dấu `.`; kết thúc nội dung văn bản có dấu `./.`
☐ Không dùng dấu chấm than, dấu ba chấm tùy tiện trong văn bản hành chính

## 9. Đánh số, ký hiệu mục

| Cấp | Ký hiệu | Ví dụ |
|---|---|---|
| Phần | Chữ số La Mã | Phần I |
| Chương | Chữ số La Mã | Chương II |
| Mục | Chữ số Ả-rập | Mục 1 |
| Điều | Chữ số Ả-rập + dấu chấm | Điều 3. |
| Khoản | Chữ số Ả-rập + dấu chấm | 1. |
| Điểm | Chữ cái + ngoặc đơn đóng | a) |

☐ Thống nhất, logic, không nhảy số, không trùng số
☐ Không dùng lẫn `-`, `+`, `*` làm ký hiệu cấp trong cùng một cấp

## 10. Văn phong hành chính

☐ Trang trọng, khách quan, rõ ràng, ngắn gọn, dễ hiểu
☐ Không dùng ngôi thứ nhất số ít; không dùng giọng văn nói
☐ Không nhận định cảm tính, không suy diễn ý chí cơ quan ban hành

## 11. Điều kiện đạt
Không lỗi chính tả, ngữ pháp; thuật ngữ và tên gọi nhất quán; không còn cụm từ mơ hồ chưa được chỉ ra; đánh số thống nhất; từ ngữ đúng quy ước của Trường.

## 12. Liên quan
`08-Quy-Uoc-Rieng-CDKT.md` · `../Skill-Library/19-Skill-Danh-Gia-Chat-Luong-Van-Ban.md` · `../Skill-Library/18-Skill-Kiem-Tra-Tinh-Thong-Nhat.md`
