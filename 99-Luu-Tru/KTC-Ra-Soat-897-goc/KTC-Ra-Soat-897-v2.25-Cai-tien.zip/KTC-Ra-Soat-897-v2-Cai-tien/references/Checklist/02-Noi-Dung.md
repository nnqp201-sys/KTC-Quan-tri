# 02-Noi-Dung — Checklist nội dung văn bản

**Nhóm ưu tiên**: cao hơn thể thức. Theo Mẫu prompt 897, thứ tự ưu tiên là: tính hợp pháp → thẩm quyền → hiệu lực văn bản viện dẫn → điều khoản bắt buộc → thống nhất nội bộ → thể thức → diễn đạt.

## 1. Căn cứ ban hành

| # | Nội dung kiểm tra | Mức nếu sai | Đạt |
|---|---|---|---|
| 1 | **Thứ tự hai nhóm căn cứ**: nhóm (1) văn bản quy định thẩm quyền, chức năng, nhiệm vụ của cơ quan/chức danh ban hành **xếp trước**; nhóm (2) văn bản quy định nội dung, cơ sở ban hành xếp sau | Mức 1 | ☐ |
| 2 | **Quy tắc QĐ 1976/QĐ-CĐKT**: chỉ áp dụng khi ĐỒNG THỜI (a) loại văn bản là **quyết định** VÀ (b) thuộc thẩm quyền Hiệu trưởng (kể cả Phó HT ký thay KT.). Khi đó QĐ 1976 ngày 14/9/2026 phải là căn cứ **đầu tiên**. Không thỏa cả hai → **không được nêu quy tắc này** | Mức 1 | ☐ |
| 3 | Trong mỗi nhóm, sắp theo **thứ bậc hiệu lực pháp lý**: Luật > Nghị định > Thông tư > văn bản UBND tỉnh > quy chế nội bộ Trường | Mức 2 | ☐ |
| 4 | Ghi đầy đủ: số hiệu, ngày ban hành, cơ quan ban hành, trích yếu. Riêng luật/pháp lệnh chỉ ghi tên và ngày ban hành | Mức 2 | ☐ |
| 5 | Mỗi căn cứ một dòng, cuối dòng dấu `;`, dòng cuối dấu `.` ; in thường **nghiêng** cỡ **14**. **Không dùng dấu gạch ngang đầu dòng** (đó là quy tắc của văn bản Đảng) | Mức 2 | ☐ |
| 6 | Văn bản viện dẫn **còn hiệu lực** tại thời điểm ban hành dự thảo | Mức 1 | ☐ |
| 7 | Không viện dẫn văn bản cấp dưới trái với văn bản cấp trên | Mức 1 | ☐ |
| 8 | Câu cuối phần căn cứ với văn bản của Trường: `Xét đề nghị của Trưởng phòng ...` | Mức 3 | ☐ |

### Bắt buộc về hiệu lực văn bản viện dẫn

☐ Đã kiểm tra từng văn bản viện dẫn trong kho `01-Legal-Database` và `02-KTC-Regulations`
☐ Ghi rõ trong Phần I: đã xác minh hay chưa, thời điểm xác minh, phạm vi xác minh
☐ Nếu không có công cụ tra cứu web: ghi *"Chưa được xác minh bằng nguồn bên ngoài"*
☐ Dùng cách diễn đạt dè dặt ("có khả năng", "cần xác minh thêm") khi chưa đủ căn cứ — **không khẳng định tuyệt đối**

**Cặp văn bản đã biết cần lưu ý** (từ `00-Metadata-Index-Tong-Hop.md` của kho 01):
- Chuỗi 3 đời: QĐ 49 (24/7/2025) → QĐ 988 (12/5/2026) → **QĐ 1976 (14/9/2026)**. Đối chiếu theo **ngày ban hành của dự thảo**: dự thảo cũ dẫn đúng văn bản đang hiệu lực tại thời điểm đó là **hợp lệ**, không nêu lỗi. Chi tiết: `08-Quy-Uoc-Rieng-CDKT.md` mục 1
- QĐ 1299/QĐ-CĐKT (27/5/2026, Quy chế làm việc) — **không nhầm** với QĐ 1229/QĐ-CĐKT (22/9/2023, Quy chế đào tạo GDNN), hai số hiệu chỉ lệch một chữ số
- Luật Thi đua khen thưởng 2022 và Luật sửa đổi 2026 — chưa xác định phạm vi còn hiệu lực của bản 2022
- Luật BHVBQPPL gốc và Luật sửa đổi số 87 — **chưa xác định bản nào là bản hợp nhất hiện hành**

## 2. Điều khoản bắt buộc theo loại văn bản

> **Tuyệt đối không áp dụng yêu cầu của loại văn bản này cho loại khác.** Ví dụ: "phải có điều khoản hiệu lực thi hành" và "điều khoản giao trách nhiệm thi hành" **chỉ áp dụng cho quyết định**, không áp cho công văn, kế hoạch, báo cáo, thông báo. Nếu không chắc loại văn bản, phải nêu rõ sự không chắc chắn thay vì mặc định áp tiêu chí của quyết định.

| Loại | Điều khoản bắt buộc |
|---|---|
| **Quyết định** | Nội dung quyết định; đối tượng/phạm vi áp dụng; **hiệu lực thi hành (ghi rõ ngày)**; trách nhiệm tổ chức thực hiện; **điều khoản giao trách nhiệm thi hành** (thường là điều cuối, ghi rõ cơ quan/cá nhân chịu trách nhiệm); nếu thay thế văn bản cũ phải nêu rõ số hiệu, ngày ban hành |
| **Nghị quyết, chỉ thị** | Căn cứ pháp lý; nội dung chỉ đạo/kết luận; phân công tổ chức thực hiện; hiệu lực thi hành |
| **Công văn** | Trích yếu; nội dung đề nghị/thông báo/trả lời rõ ràng; thời hạn thực hiện (nếu có); đầu mối liên hệ |
| **Tờ trình** | Căn cứ; **sự cần thiết**; nội dung trình; kiến nghị cụ thể; đề xuất cấp có thẩm quyền xem xét, quyết định |
| **Kế hoạch** | Căn cứ; mục đích/yêu cầu; nội dung công việc; phân công trách nhiệm; tiến độ; kinh phí (nếu có); tổ chức thực hiện |
| **Báo cáo** | Kỳ báo cáo; kết quả kèm số liệu; tồn tại, nguyên nhân; nhiệm vụ kỳ tới; kiến nghị. Với báo cáo công tác theo TB 736/TB-CĐKT: đủ 6 Trục kết quả trọng tâm theo TB 817/TB-CĐKT — xem `../Skill-Library/Skill-Tu-hoc-Phong-Cach-Bao-Cao-ra-soat.md` |
| **Thông báo** | Căn cứ; nội dung thông báo; đối tượng thực hiện; thời hạn (nếu có) |
| **Biên bản** | Thời gian, địa điểm; thành phần; nội dung diễn biến; ý kiến; kết luận/biểu quyết; chữ ký người ghi và người chủ trì |

☐ Nếu người dùng đính kèm **văn bản mẫu hoặc văn bản gốc cùng loại**, **bắt buộc thực hiện đối chiếu**, không được bỏ qua
☐ Khi phát hiện thiếu điều khoản bắt buộc: chỉ rõ thiếu điều khoản gì, căn cứ quy định nào yêu cầu, và đề xuất nội dung bổ sung cụ thể

## 3. Tính hợp pháp và thẩm quyền

| # | Nội dung | Mức nếu sai | Đạt |
|---|---|---|---|
| 1 | Nội dung không trái quy định pháp luật hiện hành | Mức 1 | ☐ |
| 2 | Thẩm quyền ban hành phù hợp với nội dung (Hiệu trưởng / Hội đồng trường / Trưởng đơn vị theo Quy chế làm việc và QĐ 1976) | Mức 1 | ☐ |
| 3 | Không tự đặt thêm thủ tục, hồ sơ, thời hạn ngoài mức pháp luật yêu cầu | Mức 1 | ☐ |
| 4 | Không quy định nội dung vượt phạm vi tự chủ của đơn vị sự nghiệp | Mức 1 | ☐ |
| 5 | Ký hiệu **không chứa năm** — nếu có năm thì là VBQPPL, Trường không có thẩm quyền ban hành → chuyển Skill 30 | Mức 1 | ☐ |

## 4. Tính hợp thức của quy trình ban hành

Nêu ở mức **"cần xác nhận thêm"**, không khẳng định là vi phạm (AI chỉ thấy dự thảo, không thấy toàn bộ hồ sơ):

| Loại việc | Thủ tục nội bộ cần xác nhận |
|---|---|
| Quyết định kỷ luật | Biên bản họp hội đồng kỷ luật |
| Ban hành quy chế, quy định | Biên bản họp thông qua dự thảo |
| Định mức kinh tế - kỹ thuật, dự toán | Ý kiến thẩm định của phòng Tài chính - Kế toán |
| Nội dung liên quan thẩm quyền, tính hợp pháp | Ý kiến pháp chế (phòng TH-HC&QT) |

Câu mẫu: *"Cần xác nhận đã hoàn thành thủ tục [...] trước khi ban hành; dự thảo hiện chưa thể hiện căn cứ này."*

## 5. Tính chính xác và thống nhất nội bộ

| # | Nội dung | Mức nếu sai | Đạt |
|---|---|---|---|
| 1 | Các điều, khoản, phụ lục, biểu mẫu không mâu thuẫn nhau | Mức 2 | ☐ |
| 2 | Viện dẫn nội bộ chính xác — dẫn "khoản 3 Điều 9" thì Điều 9 phải có khoản 3 | Mức 2 | ☐ |
| 3 | Số liệu khớp: tổng khớp chi tiết, tỷ lệ % khớp số tuyệt đối, phụ lục khớp nội dung | Mức 2 | ☐ |
| 4 | Mốc thời gian nhất quán, không chồng lấn, không lùi về quá khứ vô lý | Mức 2 | ☐ |
| 5 | Tên cơ quan, đơn vị, chức danh nhất quán xuyên suốt (đối chiếu `08-Quy-Uoc-Rieng-CDKT.md`) | Mức 2 | ☐ |
| 6 | Thống nhất giữa căn cứ – nội dung – kết luận/kiến nghị | Mức 2 | ☐ |
| 7 | **Định mức thiết bị/kinh phí tính GỘP một lần** trên tổng số đối tượng đủ điều kiện, rồi mới phân bổ — làm tròn riêng lẻ từng đơn vị rồi cộng dồn là **Mức 1** (sai số tích lũy có thể gấp nhiều lần định mức) | Mức 1 | ☐ |

## 6. Điều kiện đạt
Không có mâu thuẫn nội bộ; đủ điều khoản bắt buộc đúng loại văn bản; căn cứ đúng thứ tự và còn hiệu lực; thẩm quyền phù hợp nội dung.

## 7. Liên quan
`03-Phap-Ly.md` · `07-Theo-Loai-Van-Ban.md` · `08-Quy-Uoc-Rieng-CDKT.md` · `../Skill-Library/03-Skill-Kiem-Tra-Can-Cu.md` · `../Skill-Library/15-Skill-Kiem-Tra-Logic.md` · `../Skill-Library/17-Skill-Kiem-Tra-Tham-Quyen.md` · `../Skill-Library/18-Skill-Kiem-Tra-Tinh-Thong-Nhat.md`
