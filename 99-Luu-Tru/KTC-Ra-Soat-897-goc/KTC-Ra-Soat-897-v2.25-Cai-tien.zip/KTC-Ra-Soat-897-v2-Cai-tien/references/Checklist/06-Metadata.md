# 06-Metadata — Phiên bản và quy tắc sử dụng bộ checklist

## 1. Thông tin phiên bản

| Trường | Giá trị |
|---|---|
| Bộ checklist | KTC-Ra-Soat-897 |
| Phiên bản gói | v2.24 |
| Số checklist | 9 (01–09) |
| Ngày tạo | 12/8/2026 |
| Ngày cập nhật gần nhất | 14/9/2026 |
| Đơn vị chủ quản | Phòng Tổng hợp - Hành chính và Quản trị |
| Người kiểm tra | Phó Trưởng phòng Tổng hợp - Hành chính và Quản trị |
| Trạng thái | ĐÃ PHÊ DUYỆT ngày 18/8/2026 (mục 1-4); Checklist 09 phê duyệt riêng ngày 31/8/2026 |
| Mốc rà soát lại | Tối thiểu 6 tháng một lần hoặc khi có văn bản pháp luật mới (Mục VII Thông báo 897/TB-CĐKT) |

## 2. Căn cứ pháp lý của bộ checklist

| Văn bản | Vai trò | Áp dụng cho checklist |
|---|---|---|
| Nghị định 30/2020/NĐ-CP và Phụ lục I | Thể thức, kỹ thuật trình bày văn bản hành chính | 01, 05 |
| Thông báo 597/TB-CĐKT ngày 19/5/2026 | Thu hẹp NĐ 30 thành số cứng riêng cho Trường | 01, 04, 05, 08 |
| Quyết định 1976/QĐ-CĐKT ngày 14/9/2026 | Quy chế tổ chức và hoạt động (thay QĐ 988 ngày 12/5/2026) | 02, 08 |
| Quyết định 389/QĐ-CĐKT ngày 26/02/2026 | Quy chế công tác văn thư, lưu trữ | 01, 08 |
| Quyết định 1355/QĐ-CĐKT ngày 03/6/2026 | Tên và địa chỉ 5 cơ sở, danh mục bộ môn | 04, 08 |
| Thông báo 897/TB-CĐKT ngày 04/8/2026 | Quy định sử dụng AI rà soát văn bản | Toàn bộ |
| Hướng dẫn 05-HD/VPTW ngày 27/5/2026 | Thể thức văn bản Đảng | 03; xem thêm Skill 29 |
| Quyết định 933/QĐ-TLĐ ngày 14/5/2024 | Thể thức văn bản Công đoàn (D1) | 09 |

## 3. Quy tắc chọn checklist theo hệ quy chiếu

| Hệ quy chiếu | Checklist áp dụng | Không dùng |
|---|---|---|
| Hành chính nhà nước | 01, 02, 03, 04, 05, 07, 08 | — |
| Văn bản của Đảng | 02, 03, 04, 08 + Skill 29 và hai phụ lục | **01, 05** (thiết kế cho NĐ 30) |
| Quy phạm pháp luật | 02, 03, 04 + Skill 30 | 01, 05 |
| Đoàn thể | **09 (bắt buộc, mới v2.21)** — tách D1 Công đoàn/D2 Đoàn Thanh niên/D3 Hội Sinh viên; xem thêm 02, 03, 04, 08 mục 7.3 | 01, 05 |

**Checklist 08 là bắt buộc ở cả 4 tác vụ** khi cơ quan ban hành là Trường Cao đẳng Kon Tum. **Checklist 09 là bắt buộc khi văn bản thuộc Hệ D (đoàn thể)** — không dùng thay thế bằng chỉ Checklist 08 mục 7.3, vì 09 mới có đủ bộ quy tắc chi tiết từng tiểu-hệ (xem `09-Checklist-He-D-Doan-The.md`).

## 4. Thang mức độ dùng chung

| Mức | Tên gọi | Phạm vi |
|---|---|---|
| 1 | Bắt buộc sửa | Trái quy định pháp luật, viện dẫn sai hoặc hết hiệu lực, sai thẩm quyền, sai căn cứ ban hành, thiếu điều khoản bắt buộc, mâu thuẫn làm thay đổi nội dung |
| 2 | Cần sửa | Sai thể thức, sai kỹ thuật trình bày, sai logic, sai viện dẫn nội bộ, thiếu tính thống nhất |
| 3 | Nên sửa | Văn phong, câu chữ, cách trình bày, khả năng đọc hiểu |
| 4 | Góp ý nâng cao | Đề xuất hoàn thiện, không bắt buộc sửa |

Thang này thống nhất với Mẫu prompt 897 và `../Skill-Library/28-Skill-Bao-Cao-Ra-Soat-Chuan.md`. **Không tự đặt thang khác.**

## 5. Quy tắc sử dụng

1. Checklist là **công cụ đối chiếu**, không thay thế việc đọc hiểu nội dung dự thảo.
2. Mỗi mục kiểm tra đều ghi sẵn mức độ khi sai — **không tự nâng hoặc hạ mức**.
3. Mục nào không đủ dữ liệu để kiểm tra (ví dụ chỉ nhận nội dung dạng văn bản thuần, không có tệp gốc để xem định dạng) thì **ghi rõ vào phạm vi giới hạn tại Phần I**, không suy đoán.
4. Khi checklist và văn bản gốc mâu thuẫn, **văn bản gốc thắng**; đồng thời báo lại Phòng TH-HC&QT để cập nhật checklist.
5. Không dùng checklist của hệ quy chiếu này cho hệ quy chiếu khác.

## 6. Lịch sử cập nhật bộ checklist

| Ngày | Nội dung |
|---|---|
| 09/9/2026 | v2.22: đính chính phiên bản gói và số checklist (đã lạc hậu từ v2.9 tới nay, tự ghi "v2.8/8 checklist" trong khi gói thật là v2.21/9 checklist) — đúng lỗi này đã từng vá 1 lần ở v2.9 (19/8) rồi tái lạc hậu qua 12 lần tăng bản không cập nhật lại; bổ sung Checklist 09 vào bảng mục 2, 3; bổ sung QĐ 933/QĐ-TLĐ làm căn cứ Checklist 09 |
| 13/9/2026 | v2.23: đồng bộ phiên bản sau đợt dọn nguồn và vá kiểm thử |
| 14/9/2026 | v2.24: QĐ 988/QĐ-CĐKT (12/5/2026) bị thay bởi **QĐ 1976/QĐ-CĐKT ngày 14/9/2026** — cập nhật căn cứ ở 14 tệp, bảng chuyển tiếp 3 đời, quy tắc không hồi tố. Cùng đợt: quy tắc **thống nhất một dạng ngày tháng** (ưu tiên `05/3/2026`), sửa quy tắc sai "tháng <10" → **tháng 1, 2** theo NĐ 30, hợp nhất `references/` rời, khôi phục QT18/QT19, chốt mốc NĐ 334 từ 05/10/2026, đồng bộ 4 tệp dùng chung toàn KTC-DIS |
| 19/8/2026 | v2.7–v2.8: vá 15 tệp Prompt-Library thiếu Bước 0 và Checklist 08; chuẩn hóa báo cáo xuất ra theo template .dotx (8 phần, A4 ngang); vá lỗi tô màu Mức 1 trong script xuất báo cáo |
| 18/8/2026 | Viết lại 01–05 bằng tiếng Việt kèm số liệu định lượng; tạo mới 08; viết lại 06; sửa tham chiếu hỏng tại 07 |
| 12/8/2026 | Phiên bản đầu, 7 checklist |

## 7. Liên quan
`README.md` (sơ đồ chọn checklist) · `../Skill-Library/00-Metadata-Schema.md` (chuẩn metadata của kho dữ liệu) · `../Skill-Library/28-Skill-Bao-Cao-Ra-Soat-Chuan.md`
