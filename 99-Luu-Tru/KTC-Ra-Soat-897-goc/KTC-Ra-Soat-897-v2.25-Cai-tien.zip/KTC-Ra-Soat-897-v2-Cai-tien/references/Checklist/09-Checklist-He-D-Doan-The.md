# 09-Checklist-He-D-Doan-The — Checklist thể thức văn bản đoàn thể

**Hệ quy chiếu**: Quy định thể thức của tổ chức cấp trên tương ứng (Liên đoàn Lao động tỉnh / Đoàn cấp trên / Hội Sinh viên cấp trên) — **KHÔNG áp NĐ 30/2020/NĐ-CP, KHÔNG áp Hướng dẫn 05-HD/VPTW**.
**Nguồn gốc bảng mẫu**: `08-Quy-Uoc-Rieng-CDKT.md` mục 7.3 (mẫu 3.1–3.3 Phụ lục TB 597) — file này chỉ mở rộng chi tiết, không thay thế nguồn đó; khi hai file lệch nhau, **Checklist 08 là nguồn ưu tiên cao hơn**.

> ✅ Bổ sung ngày 31/8/2026 (v2.21), sau khi rà soát thật phát hiện 1 dự thảo bị **hoán đổi thể thức giữa D1 và D2** (xem mục 4). Trước đây gói chỉ có 3 dòng tóm tắt cho cả Hệ D; file này viết mới hoàn toàn, không kế thừa từ nhánh `v3.0` (nội dung Checklist tương ứng của nhánh đó không tồn tại thật trên Drive).

---

## 0. Cách xác định đúng tiểu-hệ trước khi kiểm thể thức

Đọc **tên đơn vị ban hành** để chốt tiểu-hệ, không đoán theo nội dung văn bản:

| Tên đơn vị ban hành có chữ | → Tiểu-hệ |
|---|---|
| "Công đoàn", "CĐCS" | **D1 — Công đoàn** |
| "Đoàn", "ĐTN", "Đoàn Thanh niên", "BCH Đoàn" | **D2 — Đoàn Thanh niên** |
| "Hội Sinh viên", "HSV" | **D3 — Hội Sinh viên** |

Sau khi chốt tiểu-hệ, kiểm **đúng bảng mẫu của tiểu-hệ đó** — không dùng chéo mẫu.

---

## 1. D1 — Công đoàn (mẫu 3.1 Phụ lục TB 597)

| # | Thành phần | Yêu cầu | Đạt |
|---|---|---|---|
| 1 | Cột trái, dòng 1 (chủ quản) | `LIÊN ĐOÀN LAO ĐỘNG TỈNH QUẢNG NGÃI` — in hoa, không đậm | ☐ |
| 2 | Cột trái, dòng 2 (đơn vị ban hành) | `CÔNG ĐOÀN CƠ SỞ TRƯỜNG CAO ĐẲNG KON TUM` — in hoa, đậm. **Lưu ý: phải có đủ chữ "CƠ SỞ"** — thiếu chữ này (chỉ ghi "CÔNG ĐOÀN TRƯỜNG CAO ĐẲNG KON TUM") là sai tên đơn vị, Mức 2 | ☐ |
| 3 | Cột trái, dòng 3 (số hiệu) | `Số: .../...-CĐCS` — ký hiệu có "CĐCS", không phải "CĐ" đơn thuần | ☐ |
| 4 | Cột phải | **CÓ ĐẦY ĐỦ** Quốc hiệu "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM" + Tiêu ngữ "Độc lập - Tự do - Hạnh phúc" + địa danh, ngày tháng — giống hệt văn bản hành chính. **Đây là tiểu-hệ DUY NHẤT trong Hệ D dùng Quốc hiệu/Tiêu ngữ.** | ☐ |
| 5 | Khối ký | Theo mẫu tổ chức Công đoàn (thường "TM. BAN CHẤP HÀNH" / "CHỦ TỊCH" hoặc "KT. CHỦ TỊCH" / "PHÓ CHỦ TỊCH"); không ghi học hàm/học vị trước tên | ☐ |

**Lỗi hay gặp nhất**: dùng nhầm tiêu đề "ĐOÀN TNCS HỒ CHÍ MINH" + dấu sao (thuộc D2) thay cho Quốc hiệu/Tiêu ngữ ở cột phải → **Mức 1** (sai hoàn toàn hệ quy chiếu thể thức, không phải lỗi nhỏ).

---

## 2. D2 — Đoàn Thanh niên (mẫu 3.2 Phụ lục TB 597)

| # | Thành phần | Yêu cầu | Đạt |
|---|---|---|---|
| 1 | Cột trái, dòng 1 (chủ quản) | `ĐOÀN KHỐI CÁC CƠ QUAN VÀ DOANH NGHIỆP TỈNH QUẢNG NGÃI` — in hoa, không đậm | ☐ |
| 2 | Cột trái, dòng 2 (đơn vị ban hành) | `BCH ĐOÀN TRƯỜNG CAO ĐẲNG KON TUM` — in hoa, đậm | ☐ |
| 3 | Cột trái, dòng 3 | `***` (ba dấu sao) — nằm bên **cột trái**, ngay dưới dòng 2. **Không phải 1 sao, không phải 7 sao — đúng 3 sao** | ☐ |
| 4 | Cột trái, dòng 4 (số hiệu) | `Số: .../...-ĐTN` | ☐ |
| 5 | Cột phải | `ĐOÀN TNCS HỒ CHÍ MINH` (in hoa, đậm) + địa danh, ngày tháng ngay dưới. **TUYỆT ĐỐI KHÔNG** dùng Quốc hiệu "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM" hay Tiêu ngữ ở đây | ☐ |
| 6 | Khối ký | Theo mẫu tổ chức Đoàn (thường "TM. BAN CHẤP HÀNH" / "BÍ THƯ" hoặc "KT. BÍ THƯ" / "PHÓ BÍ THƯ") | ☐ |

**Lỗi hay gặp nhất** (đã bắt được thật, 31/8/2026): dùng nhầm Quốc hiệu/Tiêu ngữ (thuộc D1) ở cột phải thay vì "ĐOÀN TNCS HỒ CHÍ MINH" → **Mức 1**. Đây thường là lỗi hoán đổi cặp với D1 trong cùng một hồ sơ nhiều văn bản — nếu phát hiện lỗi này ở một văn bản, **kiểm tra ngay cả các văn bản Công đoàn khác trong cùng hồ sơ** vì khả năng cao bị hoán đổi ngược lại.

---

## 3. D3 — Hội Sinh viên (mẫu 3.3 Phụ lục TB 597)

| # | Thành phần | Yêu cầu | Đạt |
|---|---|---|---|
| 1 | Cột trái, dòng 1 (chủ quản) | `HỘI SINH VIÊN TỈNH QUẢNG NGÃI` — in hoa, không đậm. **Không được bỏ dòng này** — nếu chỉ ghi "HỘI SINH VIÊN TRƯỜNG CAO ĐẲNG KON TUM" (thiếu dòng chủ quản cấp tỉnh) là thiếu thành phần, Mức 2 | ☐ |
| 2 | Cột trái, dòng 2 (đơn vị ban hành) | `BCH TRƯỜNG CAO ĐẲNG KON TUM` — in hoa, đậm. Ghi "BAN CHẤP HÀNH" đầy đủ thay vì viết tắt "BCH" không phải lỗi nội dung nhưng nên thống nhất viết tắt theo mẫu | ☐ |
| 3 | Cột trái, dòng 3 | `***` (ba dấu sao) | ☐ |
| 4 | Cột trái, dòng 4 (số hiệu) | `Số: .../HSV` — **có dấu hai chấm sau "Số"**; thiếu dấu hai chấm là lỗi kỹ thuật trình bày, Mức 3 | ☐ |
| 5 | Cột phải | **CHỈ CÓ** địa danh, ngày tháng. **KHÔNG có bất kỳ dòng tiêu đề tổ chức nào** ở cột phải — đây là đặc thù đã xác nhận bởi Phòng TH-HC&QT (18/8/2026), **TUYỆT ĐỐI KHÔNG nêu là lỗi thiếu tiêu đề Mức 1/2** | ☐ |
| 6 | Khối ký | Theo mẫu tổ chức Hội Sinh viên (thường "TM. BAN CHẤP HÀNH" / "CHỦ TỊCH") | ☐ |

---

## 4. Quy tắc kiểm tra chéo bắt buộc khi hồ sơ có nhiều văn bản đoàn thể

Khi một hồ sơ/file chứa **từ 2 văn bản đoàn thể trở lên** (ví dụ: 1 Thông báo Công đoàn + 1 Thông báo Đoàn Thanh niên trong cùng file), **bắt buộc dựng bảng đối chiếu cả 3 tiểu-hệ song song** trước khi kết luận từng văn bản — không rà từng văn bản độc lập rồi bỏ qua so sánh chéo. Lý do: lỗi hoán đổi thể thức giữa 2 tiểu-hệ chỉ lộ rõ khi đặt cạnh nhau (mỗi văn bản đứng riêng có thể trông "hợp lý" nếu người rà soát không nhớ chính xác mẫu chuẩn của tiểu-hệ kia).

---

## 5. Giới hạn đã biết (ghi rõ, không giả vờ đã kiểm đủ)

- Khối ký cụ thể (TM./KT./quyền hạn chính xác) của cả 3 tiểu-hệ **chưa có Mẫu prompt/Skill chuyên biệt riêng** — nếu phát hiện bất thường trong khối ký, ghi Mức 4 "cần xác minh với tổ chức cấp trên tương ứng", không tự suy đoán đúng/sai.
- Định dạng chính xác ký hiệu số D1/D2 (`.../...-CĐCS`, `.../...-ĐTN`) trong bảng gốc Checklist 08 dùng dấu `-` trước tiền tố nhưng không ghi rõ số thứ tự đặt trước hay sau — nếu văn bản thực tế dùng thứ tự khác (ví dụ `15/TB-CĐ` thay vì `.../TB-CĐCS`), ghi nhận là **cần xác minh cách viết ký hiệu chính thức với tổ chức Công đoàn/Đoàn/Hội cấp trên**, không mặc định là lỗi Mức 1 chỉ vì khác cách viết trong bảng mẫu rút gọn.
