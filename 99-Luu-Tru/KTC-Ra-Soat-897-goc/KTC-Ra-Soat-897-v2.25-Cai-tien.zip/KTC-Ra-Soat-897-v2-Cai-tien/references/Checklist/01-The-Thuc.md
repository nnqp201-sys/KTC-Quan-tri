# 01-The-Thuc — Checklist thể thức văn bản hành chính nhà nước

**Hệ quy chiếu**: Nghị định 30/2020/NĐ-CP và Phụ lục I · **Thu hẹp riêng cho Trường**: Thông báo 597/TB-CĐKT ngày 19/5/2026
**Không dùng cho**: văn bản Đảng (→ Skill 29 + `29-Phu-Luc-2`), VBQPPL (→ Skill 30)

> Nguyên tắc: khi TB 597 quy định số cứng trong khoảng NĐ 30 cho phép, **áp dụng số của Trường**. Bảng đầy đủ 16 dòng cỡ chữ tại `08-Quy-Uoc-Rieng-CDKT.md` mục 4.

## 1. Chín thành phần thể thức bắt buộc

| # | Thành phần | Yêu cầu định lượng | Đạt |
|---|---|---|---|
| 1 | **Quốc hiệu** | "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM"; in hoa, cỡ **13** (TB 597), đứng, đậm; phía trên cùng bên phải trang đầu | ☐ |
| 2 | **Tiêu ngữ** | "Độc lập - Tự do - Hạnh phúc"; in thường, cỡ **14**, đứng, đậm; canh giữa dưới Quốc hiệu; đường kẻ ngang nét liền dài bằng dòng chữ, **dùng lệnh Draw không dùng Underline**; cách Quốc hiệu dòng đơn | ☐ |
| 3 | **Tên cơ quan ban hành** | Chủ quản `UBND TỈNH QUẢNG NGÃI` in hoa cỡ 13 đứng; đơn vị ban hành `TRƯỜNG CAO ĐẲNG KON TUM` in hoa cỡ 13 đứng **đậm**, canh giữa dưới chủ quản; đường kẻ ngang dài **1/3–1/2** dòng chữ, đặt cân đối | ☐ |
| 4 | **Số, ký hiệu** | "Số" in thường, ký hiệu in hoa, cỡ **13**, đứng; sau "Số:" để trống **tối thiểu 6 ký tự**; số <10 thêm số 0 phía trước; giữa số và ký hiệu có dấu `/`, giữa các nhóm viết tắt có dấu `-`, không cách chữ | ☐ |
| 5 | **Địa danh, ngày tháng** | `Quảng Ngãi, ngày ... tháng ... năm ...`; in thường, cỡ **14** (TB 597 thu hẹp từ khoảng 13–14 của NĐ 30), **nghiêng**; cùng dòng với số ký hiệu; canh giữa dưới Quốc hiệu/Tiêu ngữ; sau địa danh có dấu phẩy. **Viết đầy đủ chữ "ngày/tháng/năm"**, chữ số Ả Rập; thêm số 0 khi ngày <10 và tháng 1, 2 (tháng 3–12 không thêm) | ☐ |
| 6 | **Tên loại và trích yếu** | Tên loại in hoa cỡ **14** đứng đậm, canh giữa; trích yếu in thường cỡ **14** đứng đậm ngay dưới; đường kẻ ngang dài **1/3–1/2** dòng chữ. Riêng công văn: không có tên loại, trích yếu in thường cỡ **13** đứng, dưới số ký hiệu, cách **6pt** | ☐ |
| 7 | **Nội dung** | in thường cỡ **14** đứng, dàn đều hai lề (xem checklist 05) | ☐ |
| 8 | **Chức vụ, họ tên, chữ ký** | Quyền hạn/chức vụ in hoa cỡ **14** đứng đậm; họ tên in thường cỡ **14** đứng đậm, canh giữa so với chức vụ; **không ghi học hàm, học vị, danh hiệu** (TS, ThS, BS, KS, CN...) | ☐ |
| 9 | **Nơi nhận** | Từ "Nơi nhận" in thường cỡ **12** nghiêng đậm, dòng riêng, sát lề trái, ngang hàng dòng chức vụ người ký, sau có dấu hai chấm; danh sách in thường cỡ **11** đứng, mỗi nơi một dòng, đầu dòng có `-` sát lề trái, cuối dòng có `;`, dòng cuối `Lưu: VT, <đơn vị soạn thảo>.` | ☐ |

## 2. Ký hiệu văn bản của Trường

| Loại | Ký hiệu | Loại | Ký hiệu |
|---|---|---|---|
| Quyết định | `/QĐ-CĐKT` | Báo cáo | `/BC-CĐKT` |
| Thông báo | `/TB-CĐKT` | Tờ trình | `/TTr-CĐKT` |
| Kế hoạch | `/KH-CĐKT` | Biên bản | `/BB-CĐKT` |
| Công văn | `/CĐKT-<viết tắt đơn vị soạn thảo>` — ví dụ `/CĐKT-THHCQT`, `/CĐKT-KTCN` | | |

☐ Ký hiệu **không chứa năm ban hành** (có năm → là VBQPPL, chuyển sang Skill 30)

## 3. Thành phần thể thức bổ sung (kiểm tra khi có)

| Thành phần | Yêu cầu | Đạt |
|---|---|---|
| **Phụ lục** | Dòng chỉ dẫn xuất xứ — **xem mục 3a bên dưới, đọc trước khi bắt lỗi**. Số trang mỗi phụ lục đánh **riêng, độc lập**, bắt đầu lại từ 1 — **đúng quy định, tuyệt đối không nêu là lỗi trùng số trang** | ☐ |
| **Ký số phụ lục** | Cùng tệp với văn bản chính → **chỉ ký số văn bản chính**. Tệp riêng → ký số cơ quan trên từng tệp; thông tin số ký hiệu + thời gian ký in thường đứng cỡ **10** màu đen, góc trên bên phải trang đầu, **không hiển thị hình ảnh chữ ký số** | ☐ |
| **Dấu chỉ mức độ mật** | TUYỆT MẬT / TỐI MẬT / MẬT, đóng ô số 10a Mục IV Phần I Phụ lục I NĐ 30 | ☐ |
| **Dấu chỉ mức độ khẩn** | Khẩn / Thượng khẩn / Hỏa tốc | ☐ |
| **Chỉ dẫn phạm vi lưu hành** | "XEM XONG TRẢ LẠI", "LƯU HÀNH NỘI BỘ"; trong khung chữ nhật viền đơn, in hoa, cỡ **13–14**, đứng, đậm, ô số 11 | ☐ |
| **Ký hiệu người soạn thảo, số lượng bản** | Cuối phần nơi nhận, ô số 12 | ☐ |

## 3a. Dòng chỉ dẫn xuất xứ của văn bản ban hành kèm theo — KHÔNG bắt lỗi với văn bản điện tử

> **Đây là lỗi dương tính giả bị lặp nhiều lần.** Đọc hết mục này trước khi ghi bất kỳ vấn đề nào
> về dòng chỉ dẫn xuất xứ.

**Dòng chỉ dẫn xuất xứ** là dòng đặt ngay dưới tên của văn bản được ban hành kèm theo một văn bản khác.
Nó xuất hiện dưới **nhiều cách viết khác nhau — tất cả đều là cùng một thành phần**:

- `(Ban hành kèm theo Quyết định số .../QĐ-CĐKT ngày ... tháng ... năm ... của Hiệu trưởng ...)`
- `(Kèm theo Quyết định số ... ngày ... của ...)`
- `(Kèm theo văn bản số .../...-... ngày ...)`
- `(Ban hành kèm theo Thông báo/Kế hoạch số ... ngày ...)`

**Áp dụng cho MỌI loại văn bản được ban hành kèm theo**, không chỉ thứ có chữ "Phụ lục" trong tên:
Quy chế · Quy định · Quy trình · Điều lệ · Đề án · Kế hoạch · Danh mục · Biểu mẫu · Phụ lục.

### Quy tắc phân mức

| Hình thức văn bản | Thiếu dòng chỉ dẫn xuất xứ | Ghi vào báo cáo |
|---|---|---|
| **Văn bản điện tử ký số** | **KHÔNG phải lỗi** — hệ thống quản lý văn bản tự sinh số hiệu và ngày khi phát hành, người soạn thảo không thể điền trước | **Tuyệt đối không nêu**, kể cả Mức 4 |
| **Văn bản giấy** | Là thiếu sót thể thức | **Mức 2** |
| **Chưa xác định hình thức** | Chưa đủ căn cứ kết luận | **Hỏi người dùng** văn bản phát hành dạng giấy hay điện tử. Chưa có trả lời → **không nêu lỗi**, ghi vào phạm vi "chưa xác minh" |

### Mặc định của Trường Cao đẳng Kon Tum
Trường **phát hành văn bản điện tử ký số**. Khi người dùng không nói rõ hình thức, **mặc định là điện tử**
→ **không bắt lỗi này**. Chỉ chuyển sang xử lý như văn bản giấy khi người dùng nêu rõ là bản giấy.

### Cấm suy diễn ngược
Không được lập luận *"dự thảo chưa có số hiệu/ngày nên phải bổ sung khối số hiệu, ngày tháng, thẩm quyền ký
như một văn bản hành chính độc lập"*. Dự thảo chưa có số và ngày là **trạng thái bình thường của mọi dự thảo
trước khi trình ký**, không phải khiếm khuyết thể thức.

## 4. Dấu và chữ ký số

| # | Nội dung | Đạt |
|---|---|---|
| 1 | Văn bản giấy: dấu **màu đỏ tươi**, rõ ràng, ngay ngắn, đúng chiều, trùm khoảng **1/3** chữ ký về **phía bên trái** | ☐ |
| 2 | Văn bản điện tử: hình ảnh dấu màu đỏ, định dạng **.png nền trong suốt**, kích thước bằng kích thước thực tế con dấu, trùm khoảng **1/3** hình ảnh chữ ký số của người có thẩm quyền về bên trái | ☐ |
| 3 | Dấu giáp lai: khoảng giữa mép phải, mỗi dấu tối đa **5 tờ** | ☐ |
| 4 | Dấu treo trên phụ lục: trang đầu, trùm một phần tên cơ quan hoặc tiêu đề phụ lục | ☐ |
| 5 | Không đóng dấu vào giấy không có nội dung, không đóng dấu trước khi ký, không đóng dấu sẵn trên giấy trắng | ☐ |

## 5. Quyền hạn ký (theo QĐ 389/QĐ-CĐKT Điều 11)

| Trường hợp | Cách ghi | Đạt |
|---|---|---|
| Hiệu trưởng ký trực tiếp | `HIỆU TRƯỞNG` | ☐ |
| Phó Hiệu trưởng ký thay | `KT. HIỆU TRƯỞNG` / `PHÓ HIỆU TRƯỞNG` | ☐ |
| Trưởng đơn vị ký thừa lệnh (chỉ văn bản hành chính thông thường) | `TL. HIỆU TRƯỞNG` / `TRƯỞNG PHÒNG ...` | ☐ |
| Ký thừa ủy quyền | `TUQ. HIỆU TRƯỞNG` / `TRƯỞNG PHÒNG ...` | ☐ |

☐ Dùng `KT.` `TL.` `TUQ.` **có dấu chấm** (hệ hành chính nhà nước), **không** dùng `K/T` `T/L` có gạch chéo (hệ Đảng)
☐ Chỉ ghi chức danh, **không ghi lại tên Trường**, trừ văn bản liên ngành

## 6. Điều kiện đạt
Đủ 9 thành phần bắt buộc, đúng vị trí và đúng thông số cỡ chữ/kiểu chữ. Thiếu thành phần bắt buộc → **Mức 2 – Cần sửa**. Sai cỡ chữ, kiểu chữ, vị trí → **Mức 2**. Sai thẩm quyền ký → **Mức 1 – Bắt buộc sửa**.

## 7. Liên quan
`08-Quy-Uoc-Rieng-CDKT.md` (bảng cỡ chữ đầy đủ, tên đơn vị, 5 cơ sở, 15 bộ môn) · `05-Hinh-Thuc.md` (khổ giấy, lề, số trang) · `../Skill-Library/14-Skill-Ky-Thuat-Trinh-Bay.md`
