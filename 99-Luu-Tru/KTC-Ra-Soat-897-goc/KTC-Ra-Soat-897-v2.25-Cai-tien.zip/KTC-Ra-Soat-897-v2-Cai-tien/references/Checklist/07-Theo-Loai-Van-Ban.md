# 07-Theo-Loai-Van-Ban

## Purpose
Checklist bổ sung riêng cho từng loại văn bản, dùng cùng với 5 checklist chung (01-05). Dùng **sau** khi đã đối chiếu xong 01–05, và **luôn kèm** `08-Quy-Uoc-Rieng-CDKT.md` khi cơ quan ban hành là Trường Cao đẳng Kon Tum.

## Checklist Quyết định
- Đúng thẩm quyền ký (xem `../Skill-Library/17-Skill-Kiem-Tra-Tham-Quyen.md` và `08-Quy-Uoc-Rieng-CDKT.md` mục 5)
- Đúng căn cứ (luật, nghị định, quy chế Trường). Nếu là quyết định thuộc thẩm quyền Hiệu trưởng: QĐ 1976/QĐ-CĐKT phải là căn cứ đầu tiên — xem `08-Quy-Uoc-Rieng-CDKT.md` mục 1
- Đúng tên loại (quy phạm hay cá biệt). Ký hiệu **có chứa năm** là văn bản quy phạm pháp luật — Trường không có thẩm quyền ban hành, chuyển `../Skill-Library/30-Skill-Van-Ban-Quy-Pham-Phap-Luat.md`
- Đúng thể thức (quốc hiệu, số/ký hiệu, trích yếu)
- Đúng người ký, đúng hiệu lực thi hành
- Đúng phụ lục kèm theo (nếu ban hành quy chế/quy định)
- Đúng nơi nhận để thi hành

## Checklist Kế hoạch
- Đúng bố cục: căn cứ → mục tiêu → nhiệm vụ → giải pháp → tổ chức thực hiện
- Chỉ tiêu, mốc thời gian cụ thể, đo lường được
- Không có nhiệm vụ "mồ côi" — nhiệm vụ không gắn với đơn vị thực hiện hoặc mốc thời gian (xem `../Skill-Library/15-Skill-Kiem-Tra-Logic.md`)
- Có phân công đơn vị/cá nhân rõ ràng
- Khớp với kế hoạch cấp trên hoặc kế hoạch kỳ trước

## Checklist Báo cáo
- Đúng bố cục theo mẫu báo cáo chuẩn
- Đúng số liệu, nhất quán với kỳ trước
- Có minh chứng cho các nhận định "đạt"/"hoàn thành"
- Có đánh giá kết quả, có nêu tồn tại hạn chế
- Có nêu nguyên nhân và giải pháp/phương hướng kỳ tới

## Checklist Thông báo
- Trích yếu rõ nội dung, không mơ hồ
- Rõ ai làm gì, khi nào (nếu là thông báo yêu cầu thực hiện)
- Không mang tính quyết định (không thay thế Quyết định)

## Checklist Tờ trình
- Nội dung đề nghị cụ thể, dễ phê duyệt
- Đủ căn cứ pháp lý và thực tiễn
- Đủ hồ sơ/đề án/dự toán kèm theo (nếu có)
- Không vượt thẩm quyền của cấp trình hoặc cấp nhận

## Checklist Công văn
- Đúng cấp bậc quan hệ hành chính (kính gửi đúng cơ quan/chức danh)
- Có đề nghị cụ thể để người nhận biết cần phản hồi gì
- Không dùng để ban hành quyết định/quy định

## Checklist Biên bản
- Đủ thành phần tham dự bắt buộc
- Ghi trung thực diễn biến, không diễn giải chủ quan
- Kết luận khớp với nội dung đã thống nhất
- Đủ chữ ký xác nhận các bên/thành viên bắt buộc

## Checklist Nghị quyết, Kết luận, Chỉ thị (văn bản của Đảng)
- Không áp thể thức NĐ 30 — dùng `../Skill-Library/29-Skill-Van-Ban-Dang.md` và hai phụ lục kèm theo
- Đủ tiêu đề "ĐẢNG CỘNG SẢN VIỆT NAM", dấu sao dưới tên cơ quan ban hành, 5 dấu gạch nối dưới trích yếu
- Mỗi căn cứ có **dấu gạch ngang đầu dòng** (khác NĐ 30)
- Quyền hạn ký dùng T/M, K/T, T/L có gạch chéo (không dùng KT., TL. có dấu chấm)
- Trước khi nhận xét về tên cơ quan ban hành: bắt buộc đọc `../Skill-Library/29-Phu-Luc-3-Tai-Co-Cau-To-Chuc-Dang-2026.md`

## Checklist văn bản đoàn thể (Công đoàn, Đoàn Thanh niên, Hội Sinh viên)
- **[Cập nhật 09/9/2026]** Dùng `09-Checklist-He-D-Doan-The.md` làm bộ quy tắc chính, đầy đủ D1 Công đoàn/D2 Đoàn Thanh niên/D3 Hội Sinh viên, kèm quy tắc kiểm tra chéo bắt buộc khi hồ sơ có nhiều văn bản đoàn thể. `08-Quy-Uoc-Rieng-CDKT.md` mục 7.3 (mẫu 3.1–3.3) là nguồn gốc bảng mẫu, ưu tiên cao hơn khi hai file lệch nhau.
- Đối chiếu mẫu 3.1–3.3 tại `08-Quy-Uoc-Rieng-CDKT.md` mục 7.3
- Công đoàn dùng Quốc hiệu, Tiêu ngữ; Đoàn Thanh niên và Hội Sinh viên dùng ba dấu sao và ký hiệu kiểu Đảng
- Mẫu 3.3 Hội Sinh viên **không có dòng tiêu đề tổ chức** ở cột phải — đây là đúng, không nêu là lỗi
- **[Đã lạc hậu, không dùng]** Dòng cũ ghi "Skill chưa có bộ quy tắc đầy đủ cho hệ đoàn thể" — không còn đúng từ khi có Checklist 09 (v2.21, 31/8/2026). Không ghi lại câu này vào Phần I báo cáo.

## Liên quan
`08-Quy-Uoc-Rieng-CDKT.md` · `06-Metadata.md` · `README.md`
