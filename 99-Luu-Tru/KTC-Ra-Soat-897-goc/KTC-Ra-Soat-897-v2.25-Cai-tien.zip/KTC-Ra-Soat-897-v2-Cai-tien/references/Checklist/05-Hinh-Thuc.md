# 05-Hinh-Thuc — Checklist khổ giấy, định lề, phông chữ, số trang

**Hệ quy chiếu**: Nghị định 30/2020/NĐ-CP, Phụ lục I, Phần I mục I
**Nguyên tắc**: chỉ nêu lỗi khi **xác định rõ được từ định dạng file thật**; **có công cụ đọc bytes thật thì phải dùng**, không suy đoán khi thiếu dữ liệu.

## 0. Bắt buộc đo bằng công cụ, không đọc mắt thường

☐ Chạy `tools/_read_input_properties.py` (`read_input_properties(docx_path)`) để đọc lề trang qua `section.*_margin`, cỡ chữ/đậm qua `run.font.size`/`run.font.bold` — đây là bước bổ sung bên cạnh đọc nội dung chữ, **không thay thế**
☐ Nếu nền tảng không cung cấp bytes thật của file .docx đầu vào: ghi `FORMAT_BINARY_UNVERIFIED`, vẫn tiếp tục các kiểm tra nội dung không phụ thuộc bytes, **không giả vờ đã đo lề/cỡ chữ**
☐ Khi kiểm tra lề: áp dụng `round(val, 1)` trước khi so sánh + ngưỡng an toàn `EPS=0.01`, tránh báo sai do làm tròn số học

## 1. Khổ giấy và định lề — văn bản hành chính nhà nước

| Thông số | Quy định NĐ 30 | Mặc định dùng | Đạt |
|---|---|---|---|
| Khổ giấy | **A4 (210mm × 297mm)** | A4 | ☐ |
| Kiểu trình bày | Theo chiều dài khổ A4. Trường hợp có bảng biểu không làm phụ lục riêng → có thể trình bày theo chiều rộng | Dọc | ☐ |
| Lề trên | **20 – 25mm** | 20mm | ☐ |
| Lề dưới | **20 – 25mm** | 20mm | ☐ |
| **Lề trái** | **30 – 35mm** | **30mm** | ☐ |
| **Lề phải** | **15 – 20mm** | **15mm** | ☐ |

> ⚠️ Lỗi hay gặp: đặt lề trái 20mm theo thói quen Word mặc định. **Lề trái dưới 30mm là sai NĐ 30 → Mức 2.**

## 2. Phông chữ

| Thông số | Quy định | Đạt |
|---|---|---|
| Phông chữ | **Times New Roman** | ☐ |
| Bộ mã | **Unicode theo TCVN 6909:2001** | ☐ |
| Màu chữ | **Đen** | ☐ |
| Cỡ chữ từng thành phần | Xem bảng 16 dòng tại `08-Quy-Uoc-Rieng-CDKT.md` mục 4 (số cứng theo TB 597) và checklist `01-The-Thuc.md` | ☐ |

## 3. Trình bày nội dung

| Thông số | Quy định (TB 597) | Đạt |
|---|---|---|
| Dàn lề | Dàn đều **cả hai lề** | ☐ |
| Thụt đầu dòng | **1cm đến 1,27cm** (1 default tab) | ☐ |
| Cách đoạn (Spacing) | Tối thiểu **6pt** | ☐ |
| Cách dòng (Line spacing) | Tối thiểu single hoặc **15pt (exactly)** trở lên; tối đa **1,5 lines** | ☐ |
| Cỡ chữ phần lời văn | **Thống nhất một cỡ** trong toàn văn bản | ☐ |

## 4. Số trang

| # | Quy tắc | Đạt |
|---|---|---|
| 1 | Chữ số **Ả-rập**, cỡ **13–14**, kiểu **đứng** | ☐ |
| 2 | **Canh giữa** theo chiều ngang, đặt trong **phần lề trên** | ☐ |
| 3 | **Không hiển thị số trang thứ nhất** | ☐ |
| 4 | Đánh số bắt đầu từ 1 | ☐ |

### Số trang của phụ lục — quy tắc riêng, tuyệt đối không nhầm là lỗi

☐ Số trang **mỗi phụ lục** được đánh **riêng, độc lập** với văn bản chính và với các phụ lục khác; mỗi phụ lục thường bắt đầu lại từ 1 — **đây là ĐÚNG quy định**
☐ **Tuyệt đối không nêu lỗi** "trùng lặp số trang" hay "đặt lại số trang" khi so sánh giữa các phụ lục với nhau, hoặc giữa phụ lục với văn bản chính
☐ Chỉ nêu lỗi số trang phụ lục khi **trong cùng một phụ lục** có số trang bị trùng hoặc nhảy số không hợp lý

## 5. So sánh nhanh với hai hệ khác — không áp lẫn

| Thông số | Hành chính nhà nước (NĐ 30) | Văn bản Đảng (HD 05) |
|---|---|---|
| Khổ giấy | Chỉ A4 | A4; văn bản/giấy tờ hành chính có thể A5 |
| Lề trên/dưới | 20–25mm (khoảng) | **20mm** (cố định) |
| Lề trái | 30–35mm (khoảng) | **30mm** (cố định) |
| Lề phải | 15–20mm (khoảng) | **15mm** (cố định) |
| In hai mặt | Không quy định | Mặt sau **đảo lề**: trái 15mm, phải 30mm |
| Thụt đầu dòng | 1–1,27cm | **10mm** |
| Cách dòng | Tối thiểu single/15pt, tối đa 1,5 lines | **18–22pt (Exactly)** |
| Số trang | Canh giữa lề trên | Giữa, cách mép trên **10mm** |

Chi tiết văn bản Đảng: `../Skill-Library/29-Phu-Luc-2-Co-Chu-Kieu-Chu-VB-Dang.md`

## 6. Cách kiểm tra thực tế

| Cần kiểm tra | Cách làm |
|---|---|
| Lề, khổ giấy | Mở tệp .docx → Layout → Margins / Size; hoặc đọc `word/document.xml`, thẻ `<w:pgMar>` (đơn vị twips, 1mm ≈ 56,7 twips) |
| Phông chữ, cỡ chữ | Thẻ `<w:rFonts>` và `<w:sz>` (nửa point: cỡ 14 → `w:val="28"`) |
| Cách dòng, cách đoạn | Thẻ `<w:spacing>` |

☐ Nếu chỉ nhận được nội dung dạng văn bản thuần (không có tệp gốc): **ghi rõ không có điều kiện kiểm tra định dạng**, đưa vào phạm vi giới hạn ở Phần I — **không suy đoán**

## 7. Điều kiện đạt
Khổ giấy, định lề, phông chữ, cỡ chữ, cách dòng, số trang đúng quy định; hoặc đã ghi rõ không đủ dữ liệu để kiểm tra.

## 8. Liên quan
`01-The-Thuc.md` · `08-Quy-Uoc-Rieng-CDKT.md` · `../Skill-Library/14-Skill-Ky-Thuat-Trinh-Bay.md` · `../Skill-Library/29-Phu-Luc-2-Co-Chu-Kieu-Chu-VB-Dang.md`
