# 29-Phu-Luc-2 — Bảng cỡ chữ, kiểu chữ văn bản của Đảng

**Nguồn**: Phụ lục 2 Hướng dẫn số 05-HD/VPTW ngày 27/5/2026 của Văn phòng Trung ương Đảng
**Thuộc**: Skill 29 (Văn bản Đảng) · **Dùng để**: rà soát định lượng, thay cho nhận xét định tính

> Phông chữ toàn văn bản: **Times New Roman**, bộ mã Unicode theo TCVN 6909:2001, màu đen (Phần II mục IV.1).

---

## 1. Bảng 15 thành phần thể thức

| TT | Thành phần thể thức | Loại chữ | Cỡ | Kiểu chữ | Minh họa |
|---|---|---|---|---|---|
| 1 | Tiêu đề "Đảng Cộng sản Việt Nam" | In hoa | **15** | Đứng, đậm | ĐẢNG CỘNG SẢN VIỆT NAM |
| 2a | Tên cơ quan cấp trên trực tiếp | In hoa | **14** | Đứng | ĐẢNG BỘ TỈNH LÂM ĐỒNG |
| 2b | Tên cơ quan ban hành văn bản | In hoa | **14** | Đứng, **đậm** | ĐẢNG UỶ ĐẶC KHU PHÚ QUÝ |
| 3 | Số và ký hiệu văn bản | In thường | **14** | Đứng | Số 127-QĐ/TW |
| 4 | Địa danh và ngày, tháng, năm | In thường | **14** | **Nghiêng** | Hà Nội, ngày 20 tháng 10 năm 2025 |
| 5a | Thể loại (tên loại) văn bản | In hoa | **15–16** | Đứng, đậm | BÁO CÁO |
| 5b | Trích yếu nội dung văn bản | In thường | **14–15** | Đứng, đậm | kết quả đại hội chi bộ nhiệm kỳ 2025 - 2030 |
| 5c | Trích yếu nội dung **công văn** | In thường | **12** | **Nghiêng** | về việc chuẩn bị hội nghị trực tuyến... |
| 6 | Nội dung văn bản | In thường | **14–15** | Đứng | Trong công tác chỉ đạo... |
| 6a | Từ "Phần", "Chương" và số thứ tự | In thường | **14–15** | Đứng, đậm | Phần I; Chương II |
| 6b | Tên phần, chương | In hoa | **14–15** | Đứng, đậm | QUY ĐỊNH CHUNG |
| 6c | Từ "Mục" và số thứ tự | In thường | **14–15** | Đứng, đậm | Mục 1 |
| 6d | Tên mục | In hoa | **14–15** | Đứng, đậm | QUẢN LÝ VĂN BẢN ĐI |
| 6đ | Từ "Điều", số thứ tự và tên điều | In thường | **14–15** | Đứng, đậm | Điều 1. Phạm vi điều chỉnh... |
| 6e | Khoản | In thường | **14–15** | Đứng | 1. Quy định về… |
| 6g | Điểm | In thường | **14–15** | Đứng | a) Đại hội đại biểu đảng bộ tỉnh... |
| 7a | Quyền hạn ký văn bản, bản sao | In hoa | **14** | Đứng, đậm | T/M BAN THƯỜNG VỤ |
| 7b | Chức vụ người ký | In hoa | **14** | Đứng | PHÓ BÍ THƯ |
| 7c | Họ tên người ký | In thường | **14** | Đứng, **đậm** | Nguyễn Văn A |
| 8 | Dấu tổ chức ban hành/sao văn bản | — | — | Theo quy định của Ban Bí thư, hướng dẫn của Ban Tổ chức Trung ương và Bộ Công an | — |
| 9a | Từ "Kính gửi" (công văn), "Kính trình" (tờ trình) | In thường | **14** | **Nghiêng** | Kính gửi: |
| 9b | Tên cơ quan sau "Kính gửi"/"Kính trình" | In thường | **14–15** | Đứng | - Ban Bí thư Trung ương; |
| 9c | Từ "Nơi nhận" | In thường | **14** | Đứng, **có gạch chân** | Nơi nhận: |
| 9d | Tên cơ quan sau "Nơi nhận" | In thường | **12** | Đứng | - Các đảng uỷ xã, phường trực thuộc; |
| 10 | Dấu chỉ mức độ mật | — | — | Theo hướng dẫn của Bộ Công an | — |
| 11 | Dấu chỉ mức độ khẩn | In hoa | **14** | Đứng, đậm | KHẨN |
| 12a | Chỉ dẫn phạm vi lưu hành | In hoa | **12** | Đứng, đậm | TÀI LIỆU HỘI NGHỊ |
| 12b | Chỉ dẫn dự thảo văn bản | In thường | **14** | **Nghiêng** | Dự thảo lần 2 |
| 13 | Ký hiệu người soạn thảo và số lượng bản phát hành | In thường | **11** | Đứng | NguyenVanAn-26 |
| 14 | Thông tin liên hệ của cơ quan ban hành | In thường | **10** | Đứng | Số 9A, Nguyễn Cảnh Chân, Ba Đình, Hà Nội; điện thoại:... |
| 15 | Số trang văn bản, phụ lục | In thường | **14** | Đứng | 28 |

---

## 2. Bốn cặp rất dễ nhầm cỡ chữ — kiểm tra riêng

| Cặp | Phân biệt |
|---|---|
| Tên sau **"Kính gửi"** vs tên sau **"Nơi nhận"** | 14–15 ↔ **12** |
| Trích yếu văn bản **có tên loại** vs trích yếu **công văn** | 14–15 đứng đậm ↔ **12 nghiêng** |
| Tiêu đề "ĐẢNG CỘNG SẢN VIỆT NAM" vs tên cơ quan ban hành | **15** ↔ **14** |
| Thể loại văn bản vs trích yếu | **15–16** ↔ 14–15 |

Ba thành phần có định dạng đặc thù dễ bỏ sót:
- Từ **"Nơi nhận"**: có **gạch chân** (khác văn bản hành chính nhà nước — TB 597 quy định nghiêng đậm, không gạch chân).
- **Họ tên người ký**: in thường **đậm** (văn bản Đảng), trong khi chức vụ in hoa **không đậm**.
- **Địa danh, ngày tháng**: nghiêng.

---

## 3. Định lề, khổ giấy, số trang (Phần II mục IV)

| Thông số | Văn bản Đảng (HD 05) | So với NĐ 30 |
|---|---|---|
| Khổ giấy | A4 (210×297mm); văn bản/giấy tờ hành chính có thể A5 (148×210mm) hoặc mẫu in sẵn | NĐ 30 chỉ A4 |
| Lề trên | **20mm** (cố định) | 20–25mm (khoảng) |
| Lề dưới | **20mm** (cố định) | 20–25mm |
| Lề trái | **30mm** (cố định) | 30–35mm |
| Lề phải | **15mm** (cố định) | 15–20mm |
| In hai mặt, mặt sau | Đảo lề: trái 15mm, phải 30mm | NĐ 30 không quy định |
| Số trang | Chữ số Ả-rập, giữa, cách mép trên **10mm**, không hiển thị trang thứ nhất | Canh giữa lề trên, không hiển thị trang 1 |
| Số trang phụ lục | **Ghi riêng cho từng phụ lục** | Đánh số riêng, độc lập |

> Lề của văn bản Đảng là **mốc cố định**, không phải khoảng dao động. Nêu lỗi khi lệch khỏi đúng con số, không dùng khoảng của NĐ 30.

---

## 4. Kỹ thuật trình bày nội dung (Phần II mục 6.2)

| Thông số | Quy định |
|---|---|
| Dàn lề | Dàn đều cả hai lề |
| Thụt đầu dòng | Khoảng **10mm** |
| Cách đoạn (Spacing) | Tối thiểu **6pt** |
| Cách dòng (Line spacing) | **18pt đến 22pt (Exactly)** |
| Kết thúc nội dung | Có dấu chấm (.) |

> Cách dòng 18–22pt Exactly là điểm **khác rõ** với TB 597 của Trường (tối thiểu single hoặc 15pt exactly, tối đa 1,5 lines). Không áp lẫn hai bộ thông số.

**Phần căn cứ ban hành** (nếu có): ghi đầy đủ tên loại, số, ký hiệu, cơ quan ban hành, ngày tháng năm và trích yếu (riêng luật, pháp lệnh chỉ ghi tên và năm ban hành). Mỗi căn cứ một dòng/khổ riêng, **trước mỗi căn cứ có một dấu gạch ngang (-)**, sau mỗi căn cứ có dấu chấm phẩy (;), căn cứ cuối cùng có dấu chấm (.).

> Khác văn bản hành chính nhà nước: NĐ 30 **không** dùng dấu gạch ngang đầu mỗi căn cứ. Đây là lỗi rất hay gặp khi soạn văn bản Đảng theo quán tính NĐ 30.

**Tên loại và trích yếu**: phía dưới có **05 dấu gạch nối (-----)** ngăn cách với nội dung. Đây cũng là điểm không có trong NĐ 30.

---

## 5. Bảng tự kiểm nhanh

| # | Nội dung | Đạt |
|---|---|---|
| 1 | Tiêu đề "ĐẢNG CỘNG SẢN VIỆT NAM" cỡ 15 in hoa đậm, góc phải dòng đầu, có đường kẻ ngang dài bằng tiêu đề | ☐ |
| 2 | Tên cơ quan ban hành cỡ 14 in hoa đậm, góc trái, phía dưới có **dấu sao (*)** | ☐ |
| 3 | Số văn bản nhỏ hơn 10 có số 0 phía trước; định dạng `Số 05-QĐ/ĐU` (gạch nối giữa số và tên loại, gạch chéo trước tên cơ quan) | ☐ |
| 4 | Địa danh + ngày tháng cỡ 14 **nghiêng**; ngày <10 và tháng <3 thêm số 0 | ☐ |
| 5 | Tên loại cỡ 15–16, trích yếu cỡ 14–15, phía dưới có **5 dấu gạch nối** | ☐ |
| 6 | Căn cứ ban hành: mỗi căn cứ một dòng, **có dấu gạch ngang đầu dòng** | ☐ |
| 7 | Cách dòng 18–22pt Exactly; thụt đầu dòng 10mm; cách đoạn ≥6pt | ☐ |
| 8 | Lề: trên 20 / dưới 20 / trái 30 / phải 15mm — đúng con số cố định | ☐ |
| 9 | Quyền hạn ký dùng **T/M, K/T, T/L** (có gạch chéo), không dùng TM., KT., TL. | ☐ |
| 10 | Họ tên người ký in thường **đậm**; không ghi học hàm, học vị, quân hàm | ☐ |
| 11 | Từ "Nơi nhận" có **gạch chân**; danh sách nơi nhận cỡ **12** | ☐ |
| 12 | Nếu là công văn: trích yếu cỡ **12 nghiêng**, đặt dưới số ký hiệu; có "Kính gửi" ở giữa trang | ☐ |
| 13 | Không ghi tên cấp uỷ kèm chức vụ người ký (trừ ban chỉ đạo/tiểu ban/hội đồng không có dấu riêng và văn bản liên cơ quan) | ☐ |
| 14 | Không ký nháy, ký tắt trên văn bản ban hành chính thức | ☐ |

---

## 6. Liên kết

- Cảnh báo tên gọi loại hình tổ chức đảng: xem `29-Phu-Luc-3-Tai-Co-Cau-To-Chuc-Dang-2026.md` (bắt buộc đọc trước).
- Quy ước riêng của Trường (áp dụng cả hệ Đảng: "nhà trường" viết thường): xem `../Checklist/08-Quy-Uoc-Rieng-CDKT.md`.
- Mẫu thể thức văn bản Đảng của Trường: Phụ lục TB 597/TB-CĐKT, mẫu 1.1–1.4.

**Nguồn dữ liệu**: HD 05-HD/VPTW ngày 27/5/2026, Phụ lục 2 và Phần II mục IV, 6.2 · **Người kiểm tra**: Phó Trưởng phòng Tổng hợp - Hành chính và Quản trị · **Trạng thái**: ĐÃ PHÊ DUYỆT ngày 18/8/2026
