# Quy tắc vận hành theo tình huống

Chỉ đọc các mục liên quan đến hồ sơ đang xử lý. Các chốt an toàn áp dụng cho mọi hồ sơ đã nằm trong
`SKILL.md` và `00-Nguyen-Tac-Chung.md`.

## Văn bản gốc, sửa đổi và hợp nhất

- Khi văn bản có bản sửa đổi, phải tra cả văn bản gốc và văn bản sửa đổi; không đọc một phía.
- Khi gặp “hợp nhất” hoặc “VBHN”, áp dụng đúng tài liệu trigger và skill viện dẫn văn bản hợp nhất.
- Tên gọi theo hệ cũ không đương nhiên là lỗi nếu còn quy định chuyển tiếp; phải xác minh thời điểm áp dụng.
- Không lấy chênh lệch dung lượng byte làm bằng chứng duy nhất rằng hai văn bản khác nội dung.

## Số liệu, định mức và mô hình doanh nghiệp

- Với định mức tính gộp toàn Trường, kiểm tra tổng đối tượng đủ điều kiện trước rồi mới đối chiếu phân bổ.
- Trích số hiệu văn bản nội bộ phải kèm ngày ban hành vì có thể có văn bản trùng số nhưng khác nội dung.
- Với đề án/quyết định về doanh nghiệp hoặc góp vốn, phải tách kiểm tra thẩm quyền, mô hình pháp lý,
  nguồn vốn, định giá tài sản và cơ chế đại diện vốn; không suy luận từ tên gọi đề án.
- Khi có nhiều cách hiểu đều có căn cứ, trình bày phương án, rủi ro và điểm cần người có thẩm quyền quyết định.

## Phản hồi, giải trình và dữ liệu chưa đủ

- Không tin lời xác nhận “đã điều chỉnh”; phải đọc lại đoạn văn bản và kiểm tra đối chiếu.
- Giải trình với cơ quan ngoài chỉ trả lời đúng phạm vi được hỏi, không tự mở rộng cam kết.
- Khi metadata hoặc nội dung trích xuất thiếu ngày/số, ghi “không xác định từ nội dung trích xuất”; không đoán.
- Trường “Người kiểm tra” không được dùng tên công cụ AI kèm trạng thái chính thức.

## Tệp nhị phân và Drive

- Ưu tiên thao tác tải/copy tệp phía máy chủ hoặc API tải nội dung; không chép tay base64 dài.
- Với DOCX/DOTX, kiểm tra magic bytes `PK`, kích thước so với metadata và khả năng mở ZIP/OOXML.
- Nếu base64 buộc phải dùng, xác minh độ dài dự kiến trước khi giải mã và đối chiếu hash sau khi ghi.
- Giới hạn của một kênh thao tác không được dùng làm lý do bỏ một bước có thể thực hiện bằng kênh khác.

## Kỹ thuật Word

- Ưu tiên `python-docx` cho văn bản hành chính có bảng phức tạp; dùng OOXML trực tiếp cho tính năng thư viện
  không hỗ trợ như Track Changes hoặc thứ tự phần tử schema.
- Bảng cố định phải có `autofit=False`, `tblLayout=fixed` và width ở `gridCol`; kiểm tra tổng width trước khi
  thêm bảng vào tài liệu.
- Các dạng chính tả thể thức thường gặp cần kiểm tra: “UỶ BAN” → “ỦY BAN”, “CỘNG HOÀ” → “CỘNG HÒA”.
