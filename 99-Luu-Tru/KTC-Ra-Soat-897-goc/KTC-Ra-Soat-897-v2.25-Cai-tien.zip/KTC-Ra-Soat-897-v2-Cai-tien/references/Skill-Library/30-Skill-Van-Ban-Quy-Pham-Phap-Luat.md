# 30-Skill-Van-Ban-Quy-Pham-Phap-Luat

## Purpose
Rà soát dự thảo **văn bản quy phạm pháp luật (VBQPPL)** — hệ quy chiếu thứ ba trong Mẫu prompt 897 (mục 1C), song song với văn bản hành chính nhà nước (Skill 02/14, theo NĐ 30) và văn bản của Đảng (Skill 29, theo HD 05-HD/VPTW).

File này lấp khoảng trống đã được chính README của `KTC-Database/02-05-Huong-dan-AI-Ra-Soat` ghi nhận: *"chưa có skill riêng cho văn bản quy phạm pháp luật — dù Mẫu prompt 897 đã bao phủ rà soát cả 2 hệ thống văn bản này."*

## Skill role
**Không dùng thể thức NĐ 30 (Skill 02, 14) cho VBQPPL** và ngược lại. Hai hệ khác nhau về trình tự ban hành, thể thức, và điều khoản bắt buộc.

---

## 1. Nhận diện — khi nào dùng skill này

Dùng khi Bước 0 xác định dự thảo là VBQPPL. Dấu hiệu:
- Tên loại là **Nghị quyết của HĐND** hoặc **Quyết định của UBND** (cấp tỉnh, cấp xã).
- Văn bản do cơ quan có thẩm quyền ban hành theo **trình tự lập pháp/lập quy** (có bước lấy ý kiến, thẩm định, thẩm tra).
- Ký hiệu có **năm ban hành**: `Số: 38/2026/QĐ-UBND`, `Số: 12/2026/NQ-HĐND` — khác văn bản hành chính (`Số: 988/QĐ-CĐKT`, không có năm).

> **Dấu hiệu phân biệt nhanh và đáng tin nhất: ký hiệu có chứa năm ban hành hay không.**

### Trường Cao đẳng Kon Tum KHÔNG có thẩm quyền ban hành VBQPPL

Trường là đơn vị sự nghiệp công lập, không thuộc chủ thể được ban hành VBQPPL. Vì vậy skill này dùng cho **hai tình huống thực tế**:

| Tình huống | Vai trò của Trường |
|---|---|
| (a) Trường **tham mưu, dự thảo** để UBND tỉnh Quảng Ngãi ban hành | Rà soát dự thảo trước khi trình UBND tỉnh |
| (b) Trường **góp ý** dự thảo VBQPPL do cơ quan khác chủ trì | Rà soát để làm văn bản góp ý |

Trong cả hai trường hợp, **không áp dụng quy tắc căn cứ QĐ 1976/QĐ-CĐKT** (quy tắc đó chỉ dành cho quyết định hành chính của Hiệu trưởng).

---

## 2. Căn cứ pháp lý áp dụng

| Văn bản | Vai trò |
|---|---|
| Luật Ban hành văn bản quy phạm pháp luật | Luật nền — trình tự, thẩm quyền, thể thức |
| Nghị định 34/2016/NĐ-CP, sửa đổi bổ sung bởi Nghị định 154/2020/NĐ-CP | Quy định chi tiết thể thức, kỹ thuật trình bày |

> ⚠️ **Bắt buộc xác minh hiệu lực trước khi viện dẫn.** Lĩnh vực này có nhiều lần sửa đổi. Kho `01-Legal-Database/01-01` có tệp **"Luật BHVBQPPL"** và **"Luật sửa đổi bổ sung Luật BHVBQPPL số 87"** — theo `00-Metadata-Index-Tong-Hop.md` của kho, **chưa xác định bản nào là bản hợp nhất hiện hành**. Phải nêu rõ điều này trong Phần I của báo cáo rà soát, không tự chọn một bản để viện dẫn.
>
> Nếu phiên làm việc không có công cụ tra cứu web: ghi *"Chưa được xác minh bằng nguồn bên ngoài"* và đề nghị bộ phận pháp chế xác minh tại vbpl.vn hoặc Công báo Chính phủ.

---

## 3. Trình tự, thủ tục ban hành — kiểm tra trước thể thức

Đặc thù quan trọng nhất của VBQPPL: **trình tự, thủ tục phức tạp hơn nhiều** so với văn bản hành chính. AI chỉ thấy nội dung dự thảo, không thấy toàn bộ hồ sơ, nên:

**Nguyên tắc**: nêu ở mức **"cần xác nhận thêm"**, không khẳng định là vi phạm.

Bảng kiểm cần khuyến nghị người dùng xác nhận:

| # | Bước trong quy trình | Đã hoàn thành? |
|---|---|---|
| 1 | Lập đề nghị/đề xuất xây dựng văn bản, đưa vào chương trình | ☐ |
| 2 | Đánh giá tác động của chính sách (nếu thuộc trường hợp bắt buộc) | ☐ |
| 3 | Lấy ý kiến đối tượng chịu tác động trực tiếp và cơ quan liên quan | ☐ |
| 4 | Đăng tải công khai để lấy ý kiến (thời hạn theo quy định) | ☐ |
| 5 | Thẩm định của cơ quan tư pháp (Sở Tư pháp với văn bản cấp tỉnh) | ☐ |
| 6 | Thẩm tra của Ban HĐND (với nghị quyết HĐND) | ☐ |
| 7 | Hồ sơ trình đầy đủ theo quy định | ☐ |

**Câu mẫu đưa vào Phần II**: *"Cần xác nhận đã hoàn thành thủ tục [tên bước] trước khi trình ban hành; dự thảo hiện chưa thể hiện căn cứ này."* — xếp Mức 2, không xếp Mức 1 khi chưa có căn cứ khẳng định là thiếu.

---

## 4. Điều khoản bắt buộc phải có

| Điều khoản | Bắt buộc | Ghi chú |
|---|---|---|
| **Phạm vi điều chỉnh** | Có | Xác định rõ vấn đề, lĩnh vực được điều chỉnh |
| **Đối tượng áp dụng** | Có | Xác định rõ chủ thể chịu tác động |
| **Nội dung quy phạm** | Có | Phải là quy tắc xử sự chung, áp dụng nhiều lần — **không phải quyết định cá biệt** |
| **Điều khoản chuyển tiếp** | Nếu có thay đổi ảnh hưởng quan hệ đang tồn tại | Thiếu khi cần → Mức 1 |
| **Hiệu lực thi hành** | Có | Ghi rõ ngày, hoặc mốc xác định được |
| **Điều khoản thi hành / trách nhiệm tổ chức thực hiện** | Có | Ghi rõ cơ quan, cá nhân chịu trách nhiệm |
| **Xử lý văn bản cũ** | Nếu thay thế/bãi bỏ | Phải nêu rõ số hiệu, ngày ban hành văn bản bị thay thế/bãi bỏ; thiếu → Mức 1 |

### Lỗi bản chất hay gặp nhất

**Dùng hình thức VBQPPL để ban hành nội dung cá biệt** (hoặc ngược lại). Kiểm tra: nội dung có phải quy tắc xử sự chung, áp dụng cho nhóm đối tượng không xác định cụ thể, áp dụng nhiều lần? Nếu chỉ giải quyết một việc, một người, một lần → **không phải VBQPPL**, phải chuyển sang hình thức quyết định hành chính. Đây là lỗi **Mức 1**.

---

## 5. Thể thức và kỹ thuật trình bày

Áp dụng Nghị định 34/2016/NĐ-CP (sửa đổi bởi NĐ 154/2020/NĐ-CP), **không** áp NĐ 30.

### Điểm khác biệt cốt lõi so với NĐ 30

| Thành phần | VBQPPL | Văn bản hành chính (NĐ 30) |
|---|---|---|
| **Ký hiệu** | **Có năm ban hành**: `38/2026/QĐ-UBND` | Không có năm: `988/QĐ-CĐKT` |
| Bố cục | Phần → Chương → Mục → **Tiểu mục** → Điều → Khoản → Điểm | Thường chỉ Điều → Khoản → Điểm |
| Tên điều | **Mỗi điều phải có tên điều** | Không bắt buộc |
| Căn cứ ban hành | Chỉ viện dẫn văn bản **đang có hiệu lực** tại thời điểm ban hành, theo thứ bậc hiệu lực pháp lý | Tương tự, nhưng nhóm thẩm quyền xếp trước |
| Hiệu lực | Có thời điểm hiệu lực tối thiểu tính từ ngày ký/công bố theo Luật | Thường hiệu lực từ ngày ký |
| Đăng Công báo | **Bắt buộc** | Không bắt buộc |

### Quy tắc trình bày điều, khoản, điểm

- **Điều**: `Điều 1. Phạm vi điều chỉnh` — số Ả-rập, sau số có dấu chấm, tên điều bắt buộc.
- **Khoản**: `1.` — số Ả-rập, sau số có dấu chấm. Khoản có nhiều đoạn thì mỗi đoạn xuống dòng.
- **Điểm**: `a)` — chữ cái tiếng Việt theo thứ tự a, b, c, sau chữ cái có dấu ngoặc đơn đóng.
- **Không dùng dấu gạch đầu dòng (-) để đánh số nội dung quy phạm** — đây là lỗi hay gặp khi soạn theo quán tính văn bản hành chính. Mức 2.
- Viện dẫn nội bộ phải chính xác: dẫn "khoản 3 Điều 9" thì Điều 9 phải thực sự có khoản 3. Sai → Mức 2.

---

## 6. Kiểm tra tính hợp pháp và thống nhất

Đây là nhóm ưu tiên cao nhất, xếp trước thể thức:

| # | Nội dung kiểm tra | Mức nếu sai |
|---|---|---|
| 1 | **Thẩm quyền về hình thức**: chủ thể có được ban hành loại văn bản này? | Mức 1 |
| 2 | **Thẩm quyền về nội dung**: nội dung có thuộc phạm vi được phân cấp, phân quyền? | Mức 1 |
| 3 | **Không trái văn bản cấp trên**: không quy định trái luật, nghị định, thông tư | Mức 1 |
| 4 | **Không quy định vượt thẩm quyền**: không tự đặt thêm thủ tục hành chính, phí, lệ phí, chế tài khi không được luật cho phép | Mức 1 |
| 5 | **Không hồi tố bất lợi**: không quy định trách nhiệm pháp lý mới cho hành vi đã xảy ra trước khi văn bản có hiệu lực | Mức 1 |
| 6 | **Tính thống nhất nội bộ**: các điều không mâu thuẫn nhau; phụ lục khớp với nội dung | Mức 2 |
| 7 | **Không trùng lặp** với văn bản đang có hiệu lực cùng cấp | Mức 2 |

**Lưu ý riêng về thủ tục hành chính**: nếu dự thảo có nội dung quy định thủ tục hành chính, phải kiểm tra chủ thể có được luật giao quy định thủ tục đó hay không. Cấp tỉnh chỉ được quy định thủ tục hành chính khi **được luật, nghị quyết của Quốc hội giao**. Vi phạm → Mức 1.

---

## 7. Đối chiếu kho 01-04 (Nguyên tắc 1 bắt buộc)

| Kho | Tìm gì |
|---|---|
| `01-Legal-Database/01-01` | Luật BHVBQPPL và luật sửa đổi — **xác định bản hợp nhất hiện hành trước khi viện dẫn** |
| `01-Legal-Database/01-04` | NĐ 34/2016, NĐ 154/2020 (nếu chưa có → ghi vào phạm vi chưa xác minh) |
| `01-Legal-Database/01-05` | Văn bản của Bộ chuyên ngành điều chỉnh cùng lĩnh vực với dự thảo |
| `01-Legal-Database/01-06` | Văn bản của Tỉnh ủy, UBND tỉnh Quảng Ngãi — kiểm tra trùng lặp, xung đột |
| `02-KTC-Regulations` | Quy chế nội bộ Trường liên quan (nếu Trường là cơ quan tham mưu) |
| `04-Good-Documents` | Văn bản tham khảo chuẩn: BC UBND-HĐND, BC UBND-BTC trong `04-06-04` |

Nếu không tìm thấy NĐ 34/2016 và NĐ 154/2020 trong kho: **không suy diễn nội dung**, ghi rõ *"chưa tìm thấy tài liệu đối chiếu trong kho 01-04 tại thời điểm rà soát"* và đề nghị bổ sung qua `11-Input`.

---

## 8. Khuyến nghị bắt buộc đưa vào Phần V và Phần VI

Với mọi dự thảo VBQPPL, báo cáo rà soát phải nêu rõ:

> *"Do đặc thù trình tự, thủ tục ban hành văn bản quy phạm pháp luật phức tạp hơn văn bản hành chính thông thường (lấy ý kiến, thẩm định, thẩm tra), kết quả rà soát này chỉ bao phủ nội dung và thể thức của dự thảo. Đề nghị đơn vị chủ trì xác nhận đã thực hiện đủ trình tự, thủ tục theo quy định và xin ý kiến thẩm định của cơ quan tư pháp trước khi trình ban hành."*

Kết luận về mức độ sẵn sàng phát hành: **không được kết luận "Có thể ban hành ngay"** đối với VBQPPL nếu chưa có bằng chứng đã qua thẩm định. Mức cao nhất được phép: *"Có thể ban hành sau khi chỉnh sửa nhỏ, với điều kiện đã hoàn thành thẩm định."*

---

## Related
- Bước 0 phân loại hệ quy chiếu: `SKILL.md` mục "Bước 0"
- Mẫu prompt gốc: `assets/Mau-Prompt-Chinh-Thuc-Ra-Soat-897.docx` mục 1C
- Chuẩn báo cáo đầu ra: `28-Skill-Bao-Cao-Ra-Soat-Chuan.md`
- Kiểm tra thẩm quyền: `17-Skill-Kiem-Tra-Tham-Quyen.md`
- Kiểm tra căn cứ: `03-Skill-Kiem-Tra-Can-Cu.md`
- Không dùng lẫn: `02-Skill-Kiem-Tra-The-Thuc.md` và `14-Skill-Ky-Thuat-Trinh-Bay.md` (dành cho NĐ 30); `29-Skill-Van-Ban-Dang.md` (dành cho văn bản Đảng)

**Người kiểm tra**: Phó Trưởng phòng Tổng hợp - Hành chính và Quản trị · **Trạng thái**: ĐÃ PHÊ DUYỆT ngày 18/8/2026
