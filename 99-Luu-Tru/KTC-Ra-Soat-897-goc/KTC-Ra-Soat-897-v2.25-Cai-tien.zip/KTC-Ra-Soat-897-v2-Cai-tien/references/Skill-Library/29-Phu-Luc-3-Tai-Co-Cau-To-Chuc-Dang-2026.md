# 29-Phu-Luc-3 — Tái cơ cấu hệ thống tổ chức Đảng 2026 và tác động đến rà soát thể thức

**Ngày lập**: 18/8/2026 · **Thuộc**: Skill 29 (Văn bản Đảng) · **Mức ưu tiên**: ĐỌC TRƯỚC khi rà soát bất kỳ văn bản Đảng nào

---

## 1. Vì sao file này tồn tại

Hai văn bản mới của Trung ương đã thay đổi **tên gọi các loại hình tổ chức đảng ở cấp cơ sở**:

| Văn bản | Ngày | Cơ quan ban hành | Người ký |
|---|---|---|---|
| Quy định số 208-QĐ/TW về thi hành Điều lệ Đảng | 26/7/2026 | Ban Chấp hành Trung ương khóa XIV | T/M BCH TW, Tổng Bí thư Tô Lâm |
| Hướng dẫn số 02-HD/TW một số vấn đề cụ thể thi hành Điều lệ Đảng | 07/8/2026 | Ban Bí thư | — |

Cả hai đều **ban hành SAU** hai văn bản nền mà Skill 29 đang dựa vào:
- Quy định số 399-QĐ/TW ngày 09/01/2026 (thể loại, thẩm quyền, thể thức)
- Hướng dẫn số 05-HD/VPTW ngày 27/5/2026 (thể thức, kỹ thuật trình bày)

Hệ quả: phần quy định về **tên cơ quan ban hành văn bản** trong HD 05-HD/VPTW (mục 2.1.2 điểm c, d, đ) và phần **thẩm quyền theo cấp** trong QĐ 399-QĐ/TW (Điều 10, Điều 11) đang dùng hệ tên gọi cũ, chưa đồng bộ với 208-QĐ/TW.

---

## 2. Nội dung thay đổi (nguyên văn 208-QĐ/TW)

**Mục 1.2**: *"**Thí điểm** thống nhất, đồng bộ tên gọi các loại hình tổ chức đảng ở cấp cơ sở trong toàn Đảng là: đảng bộ cơ sở, đảng bộ trực thuộc cơ sở và chi bộ."*

**Mục 1.3**: *"**Thí điểm** tổ chức cơ sở đảng được xác định gồm đảng bộ trực thuộc cơ sở và chi bộ."*

> ⚠️ Lưu ý bắt buộc: 208-QĐ/TW dùng từ **"Thí điểm"** ở cả hai mục. Khi rà soát, không được trình bày như một quy định đã áp dụng phổ quát và dứt khoát.

### Bảng ánh xạ tên gọi (tham khảo, chưa phải quy định ánh xạ chính thức)

| Hệ cũ (dùng trong 399-QĐ/TW, HD 05-HD/VPTW) | Hệ mới (208-QĐ/TW) |
|---|---|
| Đảng bộ cấp trên trực tiếp của tổ chức cơ sở đảng (đảng ủy cấp trên cơ sở) | **Đảng bộ cơ sở** |
| Đảng bộ cơ sở (đảng ủy cơ sở) | **Đảng bộ trực thuộc cơ sở** |
| Chi bộ cơ sở **và** chi bộ trực thuộc đảng ủy cơ sở (2 loại riêng) | **Chi bộ** (gọi chung, không phân biệt) |
| Đảng bộ bộ phận trực thuộc đảng ủy cơ sở | **Đảng bộ bộ phận** trực thuộc đảng ủy trực thuộc cơ sở (208 mục 5.4) |

**Bổ sung từ HD 02-HD/TW**:
- Mục 14.3: nhiệm kỳ đảng ủy bộ phận theo nhiệm kỳ đảng bộ trực thuộc cơ sở; **số cấp ủy viên không quá 7**.
- Mục 14.4: **thí điểm** nhiệm kỳ chi bộ là 5 năm, từ nhiệm kỳ 2025–2030.

---

## 3. Áp dụng cho Trường Cao đẳng Kon Tum — ĐÃ GHI NHẬN LOẠI HÌNH THEO CV 2844

### 3.1. Dữ kiện đã xác minh

Thông báo số 597/TB-CĐKT ngày 19/5/2026 (Phụ lục, mẫu 1.1) quy định thể thức đầu văn bản của Đảng ủy Trường:

```
ĐẢNG BỘ UBND TỈNH QUẢNG NGÃI
ĐẢNG ỦY TRƯỜNG CAO ĐẲNG KON TUM
*
```

→ Đảng ủy Trường **trực thuộc Đảng bộ UBND tỉnh Quảng Ngãi**, không trực thuộc thẳng Tỉnh ủy.

CV 2844-CV/ĐU của Đảng ủy UBND tỉnh (tháng 10/2026, bản trong kho còn trống ngày) thống nhất đổi tên chi bộ cơ sở, đảng bộ cơ sở trực thuộc Đảng bộ UBND tỉnh thành chi bộ, đảng bộ trực thuộc cơ sở. Nơi nhận là các chi bộ, đảng bộ trực thuộc cơ sở, không nêu tên Trường. Con dấu giữ nguyên, chờ hướng dẫn của Ban Tổ chức Tỉnh ủy.

### 3.2. Hai khả năng — mỗi khả năng có căn cứ riêng

**Khả năng A — Đảng bộ TRỰC THUỘC CƠ SỞ**

Căn cứ: 208-QĐ/TW mục 2.2.1 xác định đảng bộ UBND tỉnh trực thuộc cấp ủy cấp tỉnh; tổ chức đảng đứng dưới cấp đó sẽ ở nấc "trực thuộc cơ sở". Phù hợp thực tế phân cấp thể hiện tại TB 597.

Cập nhật: phù hợp CV 2844 — khả năng A là hướng được ghi nhận.

Điểm yếu: 208-QĐ/TW **không gán tên loại** cho "đảng bộ UBND tỉnh" tại mục 2.2.1. Đây là suy luận bắc cầu, không phải quy định minh thị. Mục 4.3 (nói về đảng bộ trực thuộc cơ sở do đảng ủy UBND tỉnh thành lập) chỉ điều chỉnh *"đơn vị thành viên, chi nhánh của tập đoàn, tổng công ty, doanh nghiệp"* — không bao gồm đơn vị sự nghiệp.

**Khả năng B — Đảng bộ CƠ SỞ**

Căn cứ: 208-QĐ/TW **mục 4.2** (nguyên văn): *"Căn cứ quy mô, phạm vi tác động, cấp ủy cấp tỉnh quyết định thành lập **đảng bộ cơ sở** thuộc cấp ủy cấp tỉnh đối với doanh nghiệp, **đơn vị sự nghiệp** của tỉnh, thành phố hoặc của Trung ương có trụ sở đóng trên địa bàn tỉnh, thành phố."*

Trường Cao đẳng Kon Tum **là đơn vị sự nghiệp của tỉnh** → thuộc phạm vi điều chỉnh của mục 4.2.

Điểm yếu: mục 4.2 gắn với điều kiện "căn cứ quy mô, phạm vi tác động" và do **cấp ủy cấp tỉnh** quyết định — trong khi hiện trạng theo TB 597 là trực thuộc Đảng bộ UBND tỉnh.

Cập nhật: không còn là hướng được ghi nhận sau CV 2844.

### 3.3. Ghi nhận loại hình theo CV 2844

> Ghi nhận loại hình: **đảng bộ trực thuộc cơ sở** (theo CV 2844). Chỉ để ghi nhớ, không đổi cách trình bày tiêu đề (mẫu 1.1 TB 597 giữ nguyên). Chưa có hướng dẫn riêng về cách ghi tên cơ quan ban hành nên nhận xét về tên cơ quan vẫn chỉ ở Mức 4.

Căn cứ: CV 2844-CV/ĐU, Đảng ủy UBND tỉnh Quảng Ngãi. Văn bản gửi chung, không nêu tên Trường; nếu cần xác nhận riêng cho Trường thì hỏi Đảng bộ UBND tỉnh hoặc Ban Tổ chức Tỉnh ủy Quảng Ngãi.

---

## 4. Điều khoản chuyển tiếp — căn cứ để KHÔNG vội kết luận là lỗi

208-QĐ/TW, Chương VIII:

- **Mục 2**: giao Bộ Chính trị, Ban Bí thư chỉ đạo *"rà soát, khẩn trương sửa đổi, bổ sung hoặc thay thế các quy định, hướng dẫn của Trung ương... **hoàn thành trong năm 2026**"* → 399-QĐ/TW và HD 05-HD/VPTW nằm trong diện có thể bị sửa đổi.
- **Mục 3**: *"Trong thời gian chưa ban hành văn bản điều chỉnh... thì **các quy định hiện hành tiếp tục được thực hiện** cho đến khi có văn bản sửa đổi, bổ sung hoặc thay thế."*
- **Mục 5**: *"Các quy định trước đây trái với nội dung Quy định này đều bãi bỏ."*

**Hệ quả cho việc rà soát**: một dự thảo dùng tên gọi theo hệ **cũ** (theo HD 05-HD/VPTW) **không đương nhiên là lỗi**, vì mục 3 cho phép quy định hiện hành tiếp tục áp dụng. Chỉ nêu ở mức **Mức 4 – Góp ý nâng cao**, kèm khuyến nghị xác minh, trừ khi có văn bản của cấp có thẩm quyền xác định rõ tên gọi áp dụng cho Trường.

---

## 5. Quy tắc thực thi khi rà soát văn bản Đảng của Trường

1. Xác định văn bản ban hành **trước hay sau 26/7/2026**. Trước → áp dụng hệ cũ, không nêu vấn đề tên gọi.
2. Nếu sau 26/7/2026 và văn bản có nhắc tên loại hình tổ chức đảng → đối chiếu CV 2844 (loại hình: đảng bộ trực thuộc cơ sở). Cách ghi tên cơ quan ban hành vẫn theo mẫu TB 597 cho đến khi có hướng dẫn của Ban Tổ chức Tỉnh ủy.
3. Nếu văn bản dùng tên khác mẫu TB 597 → ghi vào Phần I (phạm vi chưa xác minh) và nêu ở Phần II mức Mức 4, **không** xếp Mức 1 hay Mức 2.
4. Không áp dụng bảng ánh xạ mục 2 như một quy tắc sửa tự động.
5. Mọi nội dung khác về thể thức (tiêu đề, số ký hiệu, T/M–K/T–T/L, định lề, cỡ chữ) **vẫn áp dụng nguyên HD 05-HD/VPTW** — 208-QĐ/TW không điều chỉnh thể thức trình bày.

---

## 6. Tác động cần xử lý ngoài phạm vi Skill

**Thông báo 597/TB-CĐKT có 4 mẫu thể thức văn bản Đảng** (Phụ lục, mẫu 1.1–1.4):

| Mẫu | Nội dung hiện tại | Cần rà lại nếu tên gọi thay đổi |
|---|---|---|
| 1.1 | ĐẢNG BỘ UBND TỈNH QUẢNG NGÃI / ĐẢNG ỦY TRƯỜNG CAO ĐẲNG KON TUM | Có |
| 1.2 | ĐẢNG ỦY TRƯỜNG CAO ĐẲNG KON TUM / ỦY BAN KIỂM TRA | Có |
| 1.3 | ĐẢNG ỦY TRƯỜNG CAO ĐẲNG KON TUM / BỘ PHẬN VĂN PHÒNG ĐẢNG ỦY | Có |
| 1.4 | ĐẢNG BỘ TRƯỜNG CAO ĐẲNG KON TUM / CHI BỘ ... | Có |

Đây là việc của Phòng TH-HC&QT, không phải việc của Skill. Skill chỉ có trách nhiệm **cảnh báo** khi phát hiện.

---

## 7. Nguồn dữ liệu

| Tài liệu | Vị trí |
|---|---|
| Quy định 208-QĐ/TW ngày 26/7/2026 | `01-Legal-Database/01-03- VB cua TW Dang` — đã có |
| Hướng dẫn 02-HD/TW ngày 07/8/2026 | `01-Legal-Database/01-03- VB cua TW Dang` — đã có |
| Quy định 399-QĐ/TW ngày 09/01/2026 | `01-Legal-Database/01-03` — đã có |
| Hướng dẫn 05-HD/VPTW ngày 27/5/2026 | `01-Legal-Database/01-03` — đã có (bản .docx) |
| Thông báo 597/TB-CĐKT ngày 19/5/2026 | `02-KTC-Regulations/02-01` — đã có |
| CV 2844-CV/ĐU, tháng 10/2026 | `01-Legal-Database/01-06- VB cua Tinh uy - Dang uy UBND tinh` — đã có |

**Người kiểm tra**: Phó Trưởng phòng Tổng hợp - Hành chính và Quản trị · **Trạng thái**: ĐÃ PHÊ DUYỆT ngày 15/10/2026 (cập nhật theo CV 2844)
