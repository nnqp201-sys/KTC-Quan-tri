# Skill-Tu-hoc-Phong-Cach-Bao-Cao-ra-soat
## Skill tự học suốt đời — Học từ KTC-Bao-Cao và 12-Output để rà soát báo cáo tốt hơn
### Phiên bản: v1.4 — Cập nhật: 22/08/2026
### Vị trí: KTC-Ra-Soat-897-v2-Cai-tien/references/Skill-Library/
### Nguồn học:
### — KTC-Database/04-Good-Documents/04-06- Bao cao/  *(tên thư mục thật trên Drive, có dấu cách)*
### — KTC-Bao-Cao/references/Skill-Library/  *(chưa xác minh — không tìm thấy hệ này trên Drive ngày 14/9/2026)*
### — KTC-Ra-Soat-897-v2-Cai-tien/12-Output/ *(báo cáo rà soát thực tế đã xuất)*
### — Phản hồi trực tiếp từ Anh Phục trong quá trình sử dụng thực tế

---

## ❖ MỤC ĐÍCH VÀ SỰ KHÁC BIỆT VỚI KTC-BAO-CAO

Skill này **không dạy cách viết báo cáo**. Skill này dạy KTC-Ra-Soat-897 **nhận diện báo cáo tốt và báo cáo chưa tốt** để rà soát chính xác hơn.

| | KTC-Bao-Cao dùng Skill này để... | KTC-Ra-Soat-897 dùng Skill này để... |
|---|---|---|
| Mục đích | Viết đúng phong cách cấp cao | **Rà soát phát hiện lỗi phong cách** |
| Câu hỏi chủ đạo | "Viết câu này như thế nào?" | **"Câu này đúng chuẩn chưa? Thiếu gì?"** |
| Kết quả | Bản thảo báo cáo | **Báo cáo rà soát với vấn đề phân loại Mức 1/2/3** |

---

## 1. Chuẩn đối chiếu — DNA cấu trúc báo cáo tốt

Khi rà soát bất kỳ báo cáo công tác nào, đối chiếu với 6 khối bắt buộc sau. Thiếu hoặc sai bất kỳ khối nào → ghi nhận vấn đề tương ứng.

### 1.1. Khối Mở đầu — Kiểm tra 4 yếu tố
| Yếu tố | Chuẩn | Nếu thiếu → Phân loại |
|---|---|---|
| Căn cứ trực tiếp | Có văn bản chỉ đạo, kế hoạch hoặc kỳ báo cáo rõ ràng | Mức 2 |
| Bối cảnh kép | Nêu đồng thời thuận lợi VÀ khó khăn | Mức 2 |
| Tinh thần chỉ đạo | Có nêu quyết sách/hành động điều hành đã triển khai | Mức 3 |
| Nhận định tổng quát | Có câu đánh giá chung kết thúc đoạn mở, có kiểm chứng | Mức 2 |

### 1.2. Khối Chỉ tiêu — Kiểm tra 4 yếu tố
| Yếu tố | Chuẩn | Nếu thiếu → Phân loại |
|---|---|---|
| Chuẩn so sánh | Mỗi chỉ tiêu so với ít nhất 1 chuẩn: KH, kỳ trước, cùng kỳ | Mức 1 |
| Phân loại rõ | Có chỉ rõ: vượt / đạt / chưa đạt | Mức 2 |
| Không dùng tính từ không minh chứng | Không có "tích cực, hiệu quả" thiếu số liệu | Mức 2 |
| Giải thích thay đổi | Nếu số liệu khác BC trước: có giải thích | Mức 2 |

### 1.3. Khối Kết quả theo lĩnh vực — Kiểm tra chuỗi
Mỗi lĩnh vực phải đủ chuỗi:
**Kết quả chính → số liệu → so sánh → mức hoàn thành → hành động quản lý → vấn đề còn lại.**

Nếu chỉ có "kể việc" (đã tổ chức, đã ban hành...) mà thiếu kết quả → **Mức 1**.
Nếu có kết quả nhưng thiếu số liệu → **Mức 2**.
Nếu thiếu "vấn đề còn lại" → **Mức 3**.

### 1.4. Khối Tồn tại, hạn chế — Kiểm tra 3 yếu tố
| Yếu tố | Chuẩn | Nếu vi phạm → Phân loại |
|---|---|---|
| Gắn biểu hiện thực tế | Mỗi hạn chế có chỉ tiêu/tiến độ/sản phẩm cụ thể | Mức 2 |
| Không lặp kết quả | Không copy nguyên phần kết quả vào đây | Mức 2 |
| Nhóm hóa nguyên nhân | Hạn chế được nhóm theo nguyên nhân hệ thống | Mức 3 |

### 1.5. Khối Nguyên nhân — Kiểm tra phân tách
- Có phân biệt nguyên nhân khách quan / chủ quan không? Nếu không → **Mức 3**.
- Nguyên nhân có cụ thể không, hay chỉ nêu chung chung? Nếu chung chung → **Mức 2**.

### 1.6. Khối Nhiệm vụ, giải pháp — Kiểm tra công thức
Mỗi nhiệm vụ phải có tối thiểu **3 yếu tố**: việc phải làm + đối tượng/lĩnh vực + kết quả/trạng thái cần đạt.

- Thiếu 1 yếu tố → **Mức 2**.
- Nhiệm vụ chỉ lặp lại hạn chế mà không chuyển hóa thành hành động → **Mức 2**.
- Thiếu động từ mạnh (chỉ có "tiếp tục", "duy trì") → **Mức 3**.

---

## 2. Chuẩn hành văn — Bộ phát hiện lỗi ngôn ngữ

### 2.1. Dấu hiệu "kể việc thay vì báo cáo kết quả"
Nhận diện khi thấy các cụm: *"đã tổ chức họp...", "đã ban hành văn bản...", "đã triển khai..."* mà **không theo sau bởi kết quả cụ thể**.
→ Phân loại: **Mức 1** (lỗi phong cách nghiêm trọng làm mất giá trị báo cáo).

### 2.2. Dấu hiệu "tính từ không minh chứng"
Nhận diện: *"tích cực, hiệu quả, quyết liệt, kịp thời, đồng bộ..."* đứng độc lập không có số liệu/sản phẩm theo sau.
→ Phân loại: **Mức 2**.

### 2.3. Dấu hiệu "số liệu thiếu chuẩn so sánh"
Nhận diện: *"đạt X người", "tổ chức Y lớp"* không có: so kỳ trước / so KH / so cùng kỳ.
→ Phân loại: **Mức 1** (làm mất khả năng đánh giá mức hoàn thành).

### 2.4. Dấu hiệu "danh sách phẳng không có tầng ưu tiên"
Nhận diện: liệt kê 8–15 mục ngang nhau, không có phân nhóm, không có trọng tâm.
→ Phân loại: **Mức 2**.

### 2.5. Dấu hiệu câu chuyển logic yếu
Nhận diện: các đoạn nối bằng "tiếp theo", "ngoài ra" thay vì *"trên cơ sở đó", "để bảo đảm", "nhằm", "tuy nhiên"*.
→ Phân loại: **Mức 3** (gợi ý cải thiện).

### 2.6. Dấu hiệu "viết thường sau dấu hai chấm" *(học từ thực tế 21/8/2026 — đính chính 21/8/2026)*

**Căn cứ**: Quy ước riêng của Trường theo **TB 597/TB-CĐKT** và **Checklist 08-Quy-Uoc-Rieng-CDKT.md** (Mục 3.1) — **không phải NĐ 30/2020**.

> ⚠️ Đây là **quy ước riêng của Trường**, không phải quy định pháp luật. Chỉ áp dụng khi văn bản của Trường Cao đẳng Kon Tum. Phân loại là **Mức 3 – Nên sửa** (không phải Mức 2 như ghi nhận ban đầu).

**Quy tắc cụ thể (TB 597 – Mục 3.1)**:
- Tên phòng, khoa, bộ môn: từ "phòng", "khoa", "bộ môn" viết **thường**; cụm từ chỉ tên viết hoa.
- **Viết hoa chữ đầu CHỈ KHI**: đứng đầu dòng, sau dấu chấm, **sau dấu hai chấm**.

Ví dụ lỗi thực tế phát hiện:
> *"Đơn vị soạn thảo: **p**hòng Quản lý Đào tạo và Bảo đảm chất lượng"*

Sửa thành:
> *"Đơn vị soạn thảo: **P**hòng Quản lý Đào tạo và Bảo đảm chất lượng"*

→ Phân loại: **Mức 3 – Nên sửa** (quy ước riêng Trường, không phải lỗi pháp lý).

**Phạm vi kiểm tra**: Tất cả vị trí sau dấu ":" trong văn bản của Trường, đặc biệt các trường: Đơn vị soạn thảo, Kính gửi, Kèm theo, liệt kê đơn vị...

### 2.7. Dấu hiệu "bắt lỗi tên riêng chỉ tại 1 vị trí, bỏ sót các lần nhắc lại rải rác" *(học từ thực tế 22/8/2026)*

**Bối cảnh phát hiện**: Báo cáo rà soát ngày 20/8/2026 (hồ sơ "Báo cáo làm việc PCT UBND tỉnh") chỉ ghi nhận lỗi tên "Cơ sở 4" tại **1 vị trí** (Trang 1-2, Mục I.3 — bảng liệt kê tổ chức bộ máy). Khi Anh Phục đối chiếu bản PDF đầy đủ, phát hiện thêm **1 biến thể sai khác của cùng tên đơn vị** tại Trang 8, Mục 2.2 ("Khoa Kỹ thuật – Công nghệ và các Trung tâm" thay vì tên chuẩn), hoàn toàn không được ghi nhận.

**Nguyên nhân gốc**: Việc đối chiếu tên đơn vị/tên riêng theo Checklist 08 chỉ được áp dụng tại nơi tên xuất hiện **tập trung, dễ thấy** (bảng liệt kê tổ chức, danh mục cơ sở...), chứ chưa quét lại **toàn văn bản** để tìm mọi lần nhắc đến cùng tên ở các đoạn văn tường thuật rải rác khác (ví dụ: phần mô tả cơ sở vật chất, ký túc xá...).

→ Phân loại lỗi kiểu này khi bỏ sót: tùy mức độ nghiêm trọng của nội dung liên quan (nếu vị trí bị bỏ sót có mức 1/2 thì đây là bỏ sót Mức 1/2 tương ứng, không phải lỗi Mức 3 độc lập).

**Quy tắc bắt buộc từ nay**: Ngay khi phát hiện MỘT lỗi tên đơn vị/tên riêng/thuật ngữ chuẩn hóa (Cơ sở, khoa, bộ môn, ký hiệu văn bản, chức danh...) tại bất kỳ vị trí nào trong văn bản, phải **chạy tìm kiếm toàn văn bản** (grep/tìm kiếm chuỗi con của tên đó và các biến thể gần đúng) để liệt kê **TẤT CẢ** vị trí xuất hiện — không dừng lại sau khi tìm thấy vị trí đầu tiên. Ghi rõ từng vị trí (số trang/mục) trong cùng một dòng vấn đề của báo cáo rà soát.

### 2.8. Bộ nhớ pattern tốt đã xác nhận *(cập nhật khi học thêm)*

| Kỹ thuật tốt | Mô tả | Nguồn học | Ngày |
|---|---|---|---|
| "Thiết lập bối cảnh kép" | Thuận lợi và khó khăn song hành ngay đoạn đầu | UBND Quảng Ngãi | 13/8/2026 |
| "Chuỗi số liệu lịch sử" | So 3+ kỳ liên tiếp để chứng minh xu hướng | KTC — BC đánh giá | 13/8/2026 |
| "Chuyển tiếp kế hoạch" | Phần KH kỳ sau bắt đầu từ tồn tại kỳ này | KTC — BC tháng 7 | 13/8/2026 |
| "Nén tóm tắt cấp trên" | 3–5 kết quả nổi bật + 1–2 vấn đề + nội dung xin ý kiến | KTC — BC tóm tắt | 13/8/2026 |

---

## 3. Nguyên tắc suy luận khi rà soát

1. **Không kết luận vượt dữ liệu** — chỉ ghi nhận vấn đề khi có bằng chứng trong văn bản.
2. **Khi số liệu bất thường**: trước khi kết luận lỗi, kiểm tra 5 yếu tố: thay đổi phạm vi tính / mẫu số / phương pháp / thời điểm / chính sách-bộ máy.
3. **Phân biệt "kết quả hoạt động" và "kết quả điều hành"** — không nhầm lẫn khi phân loại.
4. **Không đồng nhất "đã ban hành văn bản" với "đã hoàn thành nhiệm vụ"** — đây là lỗi Mức 1.
5. **Khi tổng hợp nhận xét toàn báo cáo**: một nhận định chỉ được nâng lên cấp Trường khi có đủ độ bao phủ hoặc có giá trị trọng yếu.
6. **Phân biệt lỗi pháp lý và quy ước riêng Trường**: lỗi vi phạm NĐ 30 → Mức 1/2; vi phạm quy ước TB 597 → Mức 3; không được nâng mức chỉ vì "nghe có vẻ sai".
7. **Mọi lỗi tên đơn vị/tên riêng/thuật ngữ chuẩn hóa phải được quét toàn văn bản, không dừng ở vị trí đầu tiên tìm thấy** *(mới, 22/8/2026)* — xem chi tiết Mục 2.7.

---

## 4. Bộ tự kiểm khi rà soát báo cáo công tác

Trước khi chốt báo cáo rà soát (trước bước xuất .docx), kiểm tra 12 câu sau:

| # | Câu hỏi | Trạng thái |
|---|---|---|
| 1 | Đã kiểm đủ 6 khối cấu trúc chưa? | ☐ |
| 2 | Mọi vấn đề Mức 1 đã có vị trí chính xác trong văn bản không? | ☐ |
| 3 | Có nhầm "kể việc" với "lỗi phong cách" không? — chỉ Mức 1 khi thiếu kết quả hoàn toàn | ☐ |
| 4 | Số liệu thiếu chuẩn so sánh đã được ghi nhận đủ chưa? | ☐ |
| 5 | Phần nhiệm vụ/giải pháp đã được đối chiếu công thức 3 yếu tố chưa? | ☐ |
| 6 | Tồn tại hạn chế có gắn nguyên nhân chưa? | ☐ |
| 7 | Báo cáo rà soát có đủ 3 trường trách nhiệm (nguồn dữ liệu / người kiểm tra / trạng thái)? | ☐ |
| 8 | Các vấn đề được phân loại đúng Mức 1/2/3/4 chưa? Có nhầm quy ước Trường với lỗi pháp lý không? | ☐ |
| 9 | Sau dấu ":" có tên đơn vị/cơ quan bị viết thường không? *(quy ước TB 597, Mức 3)* | ☐ |
| 10 | **Với mọi lỗi tên đơn vị/tên riêng đã phát hiện, đã quét lại TOÀN VĂN BẢN (không chỉ bảng liệt kê) để tìm hết các vị trí khác chưa?** *(mới, 22/8/2026)* | ☐ |
| 11 | Có phát hiện pattern tốt nào cần ghi vào Mục 2.8 không? | ☐ |
| 12 | Có phát hiện lỗi mới nào cần ghi vào Mục 2 không? | ☐ |

---

## 5. Vòng lặp tự học — "Càng rà soát càng nhạy bén"

### 5.1. Bốn tình huống kích hoạt học

| Tình huống | Dấu hiệu | Hành động |
|---|---|---|
| **A — Học từ báo cáo tốt bên ngoài** | Anh Phục nói "hay", "chuẩn", hoặc đặt vào `04-Good-Documents/04-06-Bao-cao/` | Phân tích → trích kỹ thuật → hỏi xác nhận → ghi Mục 2.8 |
| **B — Học từ 12-Output** | Có file .docx mới trong `12-Output/` — báo cáo rà soát thực tế vừa hoàn thành | Đọc lại → nhận diện vấn đề nào hay gặp → đề xuất cập nhật tiêu chí |
| **C — Học từ phản hồi rà soát** | Anh Phục sửa lại kết quả rà soát, nói "đây không phải lỗi", "phân loại sai", "đây là quy ước Trường", "còn thiếu lỗi này" | Phân tích điểm sửa → cập nhật tiêu chí + căn cứ + mức phân loại |
| **D — Học từ tự phát hiện** | Khi rà soát thấy dạng lỗi chưa có trong Mục 2 | Đề xuất tiêu chí mới → hỏi xác nhận → bổ sung |

### 5.2. Cách học từ 12-Output
`12-Output/` chứa các file .docx báo cáo rà soát thực tế đã xuất — nguồn học gần nhất với thực tiễn.

**Khi nào đọc**: Trước mỗi lần rà soát mới, hoặc khi Anh Phục yêu cầu "học từ kết quả cũ".

**Đọc để rút ra**:
- Vấn đề Mức 1 nào xuất hiện thường xuyên nhất → ưu tiên kiểm tra sớm.
- Tiêu chí nào đã phân loại sai → cập nhật lại ngưỡng.
- Lỗi nào lặp lại nhiều hồ sơ → bổ sung vào Mục 2 như lỗi hệ thống.

**Lưu ý**: Không sao chép nội dung từ 12-Output. Chỉ học kỹ thuật và tiêu chí.

### 5.3. Quy trình học có kiểm soát

```
Phát hiện nguồn học (A/B/C/D)
 ↓
Phân tích: kỹ thuật/lỗi gì, căn cứ nào (NĐ30/TB597/quy ước Trường), phạm vi nào?
 ↓
Kiểm tra: đã có trong Skill chưa? Mức phân loại có đúng không?
 ↓
Hỏi xác nhận Anh Phục
 ↓
Ghi vào đúng mục + ghi provenance (nguồn + ngày)
```

### 5.4. Quy tắc "không làm suy giảm"
- Tiêu chí mới chỉ được bổ sung khi làm tăng độ chính xác rà soát.
- Khi xung đột: ưu tiên nguồn chính thức hơn, mới hơn, phù hợp loại văn bản hơn.
- Không tự xóa tiêu chí — chỉ Anh Phục xác nhận xóa.

### 5.5. Output bắt buộc mỗi lần học
Ít nhất một trong: dòng mới Mục 2.8, tiêu chí mới Mục 2, dòng mới Mục 6, cập nhật Mục 4.

---

## 6. Nhật ký tri thức *(cập nhật liên tục có kiểm soát)*

| Nguồn học | Kỹ thuật/lỗi rút ra | Áp dụng khi rà soát | Ngày |
|---|---|---|---|
| KTC-Bao-Cao — Skill-Tu-hoc (v2.0) | DNA cấu trúc 6 khối + công thức hành văn + 9 lỗi phổ biến | Mọi BC công tác | 13/8/2026 |
| KTC-Bao-Cao — 30-Skill-Phan-Loai-6-Truc | Cấu trúc 6 Trục/38 nội hàm — chuẩn phân loại nội dung | Rà soát BC tháng/quý/năm | 13/8/2026 |
| KTC-Bao-Cao — 33-Skill-Tong-Hop | Pipeline: bối cảnh → chỉ tiêu → 6 Trục → đánh giá → hạn chế → nguyên nhân → nhiệm vụ | Kiểm tra logic tổng thể BC | 13/8/2026 |
| UBND Quảng Ngãi — BC KT-XH 2025 | Cấu trúc điều hành cấp cao, cân bằng kết quả-hạn chế | Phát hiện BC không cân bằng | 13/8/2026 |
| KTC — BC tháng 7 | Kỹ thuật chuyển tiếp kế hoạch kỳ sau từ tồn tại kỳ này | Phát hiện nhiệm vụ không kết nối | 13/8/2026 |
| **Anh Phục phản hồi v1.2** | Lỗi viết thường sau dấu ":" — ghi nhận ban đầu. Căn cứ và phân loại chưa chính xác | Phát hiện ban đầu | 21/8/2026 |
| **Anh Phục đính chính v1.3** | **Đây là quy ước riêng Trường (TB 597 Mục 3.1), không phải NĐ 30. Phân loại đúng: Mức 3** — bài học quan trọng: phải tra Checklist 08 trước khi xác định căn cứ | Phân loại đúng khi gặp lỗi liên quan quy ước Trường | 21/8/2026 |
| **Anh Phục phản hồi 22/8/2026** | Báo cáo rà soát 20/8/2026 chỉ bắt lỗi tên "Cơ sở 4" tại 1 vị trí (Trang 1-2, Mục I.3), bỏ sót biến thể sai thứ 2 của cùng tên đơn vị tại Trang 8, Mục 2.2 ("và các Trung tâm") — do chỉ đối chiếu tại bảng liệt kê tổ chức bộ máy, chưa quét toàn văn bản cho mọi lần nhắc tên | **Mọi lỗi tên đơn vị/tên riêng — bắt buộc quét toàn văn bản, ghi hết mọi vị trí, không dừng ở vị trí đầu tiên** | **22/8/2026** |
| 12-Output/ *(cập nhật sau mỗi hồ sơ thực tế)* | — | — | — |

> **Quy tắc cập nhật**: Chỉ ghi khi tìm được kỹ thuật/lỗi **chưa có** hoặc **cần đính chính** và đã được Anh Phục xác nhận.

---

## 7. Quan hệ với các Skill khác trong KTC-Ra-Soat-897-v2

| Skill | Quan hệ |
|---|---|
| `08-Quy-Uoc-Rieng-CDKT.md` | **Bắt buộc tra trước** khi phân loại lỗi liên quan đến tên đơn vị, viết hoa, ký hiệu, cỡ chữ, quyền hạn ký — tránh nhầm quy ước Trường với lỗi NĐ 30 |
| `28-Skill-Bao-Cao-Ra-Soat-Chuan.md` | Khuôn 7 phần; Skill này cung cấp chuẩn đối chiếu nội dung |
| `15-Skill-Kiem-Tra-Logic.md` | Kiểm tra logic văn bản; Skill này kiểm tra logic cấu trúc báo cáo |
| `19-Skill-Danh-Gia-Chat-Luong-Van-Ban.md` | Bổ sung cho nhau — cùng đánh giá chất lượng từ góc độ khác nhau |
| `12-Output/` | **Nguồn học thực tế** — đọc lại các báo cáo rà soát đã xuất để cải thiện tiêu chí |

**Kích hoạt bắt buộc**: Tác vụ **(a) Rà soát chính thức** một báo cáo công tác → đọc Skill này trước khi viết Phần II và Phần V.

---

## Lịch sử cập nhật
- **22/8/2026 v1.4**: Bổ sung Mục 2.7 "Bắt lỗi tên riêng chỉ tại 1 vị trí, bỏ sót các lần nhắc lại rải rác" — học từ Tình huống C (Anh Phục đối chiếu bản PDF phát hiện báo cáo rà soát 20/8/2026 bỏ sót 1 biến thể sai tên "Cơ sở 4" ở trang 8). Bổ sung nguyên tắc suy luận số 7 (Mục 3). Bổ sung câu hỏi số 10 vào Bộ tự kiểm (Mục 4). Ghi nhật ký (Mục 6). **Bài học lớn nhất**: phát hiện một lỗi tên riêng ở một vị trí không có nghĩa là đã bắt hết — phải quét toàn văn bản.
- **21/8/2026 v1.3**: Đính chính Mục 2.6 — căn cứ từ NĐ 30 → đúng là TB 597/TB-CĐKT + Checklist 08 (quy ước riêng Trường); phân loại từ Mức 2 → đúng là Mức 3. Bổ sung nguyên tắc suy luận số 6 (Mục 3). Cập nhật Mục 4 câu 8 (phân biệt lỗi pháp lý và quy ước Trường). Bổ sung `08-Quy-Uoc-Rieng-CDKT.md` vào Mục 7. Ghi nhật ký đính chính (Mục 6). Bài học lớn nhất: phải tra Checklist 08 trước khi xác định căn cứ mọi lỗi liên quan đến hình thức văn bản Trường.
- **21/8/2026 v1.2**: Bổ sung Mục 2.6 "Viết thường sau dấu :" — lần tự học đầu tiên từ Tình huống C.
- **13/8/2026 v1.1**: Đổi tên, bổ sung 12-Output làm nguồn học thực tế.
- **13/8/2026 v1.0**: Khởi tạo.

*Xác nhận: Anh Phục (Phó Trưởng phòng TH-HC&QT)*
