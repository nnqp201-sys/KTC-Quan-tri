# Ghi chú kỹ thuật — lịch sử sự cố và lý do sinh ra quy tắc

> Tách khỏi `SKILL.md` ngày 09/9/2026 (giữ nguyên phiên bản gói v2.22) theo nguyên tắc
> Progressive Disclosure. **Toàn bộ nội dung dưới đây là lịch sử/giải thích, không phải
> chỉ dẫn hành động** — quy tắc đang có hiệu lực đã nằm trong `SKILL.md`.
> Chỉ đọc file này khi cần truy nguyên vì sao một quy tắc tồn tại, hoặc khi debug script.

---

## 1. Lịch sử `tools/build_ktc897_report.py`

Nội dung script hiện tại là **v3.6** (29/9/2026), kế thừa toàn bộ vá của v3.1 → v3.5.

### v3.6 (29/9/2026) — trường "Người kiểm tra" tự điền tên công cụ AI
Phát hiện bằng cách **chạy thật** script rồi đọc lại `.docx` bằng `python-docx` — không phải đọc code.
Bảng THÔNG TIN TRÁCH NHIỆM in ra:
`Người kiểm tra → "Hệ KTC-Ra-Soat-897-v2-Cai-tien (v2.25, 29/09/2026). [CẦN ĐIỀN TÊN VÀ CHỨC DANH] chịu trách nhiệm…"`
— mở đầu bằng tên công cụ AI, **vi phạm thẳng quy tắc bắt buộc** "Người kiểm tra không được điền tên
công cụ AI, phải là người thật chịu trách nhiệm" (Thông báo 897, Nguyên tắc 2).

Điểm đáng ghi nhớ: **chính docstring của `thong_tin_trach_nhiem()` đã nhắc đúng quy tắc đó**, nhưng thân
hàm lại tự ghép tên Hệ vào. Bài học lặp lại bài học v2.25: *quy tắc được viết ra không đồng nghĩa với
quy tắc được thi hành* — phải kiểm bằng đầu ra thật, không kiểm bằng lời tự mô tả của chính công cụ.

Đã sửa: "Người kiểm tra" chỉ còn tên người + chức danh; tên Hệ + phiên bản + ngày chạy chuyển sang
trường "Nguồn dữ liệu đã dùng" (vẫn truy vết đủ công cụ, không mạo danh người kiểm tra); footer mọi
trang giữ nguyên như cũ.

**Ghi chú đính chính kèm theo**: tài liệu quản trị của Hệ lâu nay mô tả "phiên bản Skill in vào dòng đầu
Phần I" — **sai chỗ**. Phần I chỉ có 6 dòng (Hệ quy chiếu · Loại văn bản · Cơ quan ban hành · Nguồn dữ
liệu · Thống nhất tiền đề · Thời điểm xác minh). Phiên bản thật nằm ở **footer mọi trang** và ở trường
"Nguồn dữ liệu đã dùng" (từ v3.6).

### v3.5 (13/9/2026)
Xem docstring đầu `tools/build_ktc897_report.py`.

### v3.4 (30/8/2026) — 5 lỗi thật được vá
Xác nhận bằng `validate.py` (skill docx) + chạy thử 3 lần với nội dung khác nhau, không chỉ đọc code:

1. Kiểm tra độ rộng bảng từ "chỉ có ghi chú" → nay thực sự `raise ValueError` nếu tổng > 25,7cm.
2. Độ rộng cứng trong `bang_2cot()` giảm từ đúng biên 25,7cm xuống **25,5cm**, tránh vỡ do sai số làm tròn EMU.
3. Thêm `_fix_app_xml_metadata()` — tự tính lại Pages/Words/Paragraphs thật (render PDF thật để đếm,
   không đoán) và ghi vào `docProps/app.xml`. Vá lỗi python-docx mặc định Pages=1 khiến một số trình xem
   (thanh trạng thái Word, Windows Explorer) hiển thị sai "chỉ có 1 trang".
4. Vá lỗi schema `<w:zoom>` thiếu `w:percent` bắt buộc.
5. **3 lỗi thứ tự schema OOXML có sẵn từ trước, chưa từng bị phát hiện vì chưa ai chạy `validate.py`** —
   `tblLayout`, `tcMar`, `shd` bị `append()` mù ở cuối `tcPr`/`tblPr` thay vì chèn đúng vị trí bắt buộc,
   khiến Word thật có thể từ chối mở file dù LibreOffice vẫn hiển thị bình thường.

### Sự cố "v3.0" (25/8/2026) — nguồn gốc quy tắc bảng màu
Khi hợp nhất 2 nhánh script đã **lấy nhầm bảng màu** từ nhánh `build_tcdm_review_fixed.py`
(dùng `002060`/`0000CC`/`D9EAF7` sai) thay vì bảng màu gốc trích từ template `.dotx` chuẩn,
đồng thời **làm rơi mất phần "Thông tin trách nhiệm"** khi viết lại.
Đã vá qua 3 bước (28/8/2026) thành v3.3, nội dung hợp nhất qua thao tác tải/ghi trực tiếp
qua Google Drive API (không transcribe thủ công).

→ Đây là lý do `SKILL.md` ghi cứng bảng màu và bắt buộc có `thong_tin_trach_nhiem()`.

### Sự cố width bảng (kiểm thử thật 25/8/2026) — nguồn gốc ràng buộc 3 bước
Phải đặt `t.autofit = False` **và** khai `w:tblLayout type="fixed"` **và** ghi `w:w` vào từng `w:gridCol`.
Thiếu bất kỳ bước nào thì Word bỏ qua width đã set, bảng co lại ~87% chiều rộng và tài liệu
phình từ 8 lên 12 trang.

### Script đã khai tử
`tools/build_tcdm_review_fixed.py` ngừng dùng hoàn toàn từ v2.14 và **đã bị loại khỏi gói**.
Mọi tính năng đã hợp nhất vào `build_ktc897_report.py`.

---

## 2. Đọc file nhị phân đầu vào (26/8/2026, LỆNH 7)

Đã kiểm chứng end-to-end trên ≥2 file `.docx` thực: file `.skill` 256KB giải mã byte-identical thành công;
`File-Test-Loi-KTC897.docx` 11.094 bytes giải mã thiếu 1.017 bytes do lỗi copy tay chuỗi base64 dài
(magic bytes `PK\x03\x04` hợp lệ, EOCD record tồn tại, nhưng nội dung giữa bị mất).

**Không được kết luận "tải binary DOCX là giới hạn chung của môi trường"** — sai bản chất và khiến
người đọc hiểu nhầm là không khắc phục được. Đúng bản chất: **lỗi truy xuất/thao tác thủ công theo
từng file cụ thể**. Ba bước fallback bắt buộc:

- Kiểm tra 4 byte đầu của nội dung đã giải mã có đúng `PK\x03\x04` không, in log rõ ràng nếu sai.
  Không để lỗi im lặng rồi suy diễn "môi trường không hỗ trợ".
- Kiểm tra kích thước file đã giải mã có khớp `fileSize` báo cáo trên Drive không — nếu lệch,
  đây là bằng chứng cắt cụt khi truyền/copy, không phải lỗi cấu trúc file gốc.
- Chuỗi base64 dài (>10.000 ký tự) rủi ro cao bị cắt khi copy thủ công — xác minh độ dài chuỗi
  khớp công thức `ceil(fileSize/3)*4` trước khi giải mã.

Sự cố xác nhận 30/8/2026: tự gõ lại một chuỗi base64 ~26.000 ký tự từ tool result vẫn lệch 22 byte
so với bản gốc → đây là lý do quy tắc vận hành #17 bắt ưu tiên `copy_file` / `download_file_content`.

---

## 3. Lịch sử sinh ra 4 bước xác minh sau đóng gói

- **v2.4 và v2.6** từng được báo "hoàn thành" nhưng thay đổi chưa thực sự tồn tại trong gói.
- **v2.13** đóng gói xong nhưng bỏ trống changelog.

Bốn bước xác minh trong `SKILL.md` sinh ra từ đúng ba sự cố này.

---

## 4. Nợ kỹ thuật Process Memory

Ghi nhận 25/8/2026: cơ chế Process Memory thiết kế từ 23/8 nhưng mới có 1 bản ghi trong khi
đã có hơn 15 ca rà soát. **Đây là nợ kỹ thuật phải trả**, không phải tùy chọn.

---

## 5. Đính chính tham chiếu file (09/9/2026)

Hai tên file từng được ghi trong Nguyên tắc bắt buộc #3 và #4 **không tồn tại thật** trên Drive
(đã xác nhận bằng tìm kiếm trực tiếp):

| Tên file ghi sai trước đây | Nội dung thật nằm ở |
|---|---|
| `KTC-Database/06-Skill-Library/31-Skill-Track-Changes-Bat-Buoc-Khi-Sua-Van-Ban.md` | `references/Skill-Library/Bo-Sung-Chuan-Hoa-TrackChanges-MauChu-PhienBanSkill_20260825.md` mục 1–2 |
| `KTC-Database/06-Skill-Library/32-Nguyen-Tac-Ra-Soat-Giai-Trinh-Duc-Ket.md` | cùng file trên, mục 4 (nguyên tắc a–e) |

Cũng trong đợt này: xác nhận lại **Skill 30 (VBQPPL) có nội dung thật, đầy đủ, đã phê duyệt 18/8/2026**
— không phải placeholder như DL-20260908-001 từng kết luận (xem DL-20260909-001, đã đính chính).

---

## 6. Assets đã loại khỏi gói (09/9/2026)

| File đã xóa | Lý do |
|---|---|
| `assets/Mau-Prompt-Chinh-Thuc-Ra-Soat-897-v2.0-KTC-Enhanced.docx` | MD5 `786cdb34783ddc34b3d0ceb5bb12146a` — **trùng tuyệt đối** với `Mau-Prompt-Chinh-Thuc-Ra-Soat-897.docx`. Không phải bản nâng cấp, chỉ là bản sao. |
| `assets/KTC-Ra-Soat-897_Template_Trong.docx` | Bản trung gian trước khi có `.dotx` chính thức. Chính SKILL.md đã tuyên bố "không phải chuẩn áp dụng". |

Chuẩn duy nhất còn lại: `assets/KTC-Ra-Soat-897_Template_Trong.dotx` và `assets/Mau-Prompt-Chinh-Thuc-Ra-Soat-897.docx`.
