---
name: ktc-ra-soat-897
description: "Rà soát, so sánh và chuẩn hóa dự thảo văn bản Trường Cao đẳng Kon Tum theo TB 897/TB-CĐKT; hỗ trợ hệ hành chính, Đảng, VBQPPL và đoàn thể. Không dùng để soạn mới."
---

> **Phiên bản: v2.25** | Cập nhật: 28/9/2026 | Gói: `ktc-ra-soat-897-v2.25.skill`

# KTC Rà Soát 897

Chỉ dùng để **rà soát, so sánh hoặc chuẩn hóa văn bản đã có**. Không dùng để soạn văn bản mới.
Nếu người dùng cần soạn mới, chuyển sang skill soạn thảo phù hợp trong KTC-DIS.

## Chốt an toàn bắt buộc

1. Đọc `references/Skill-Library/00-Nguyen-Tac-Chung.md` trước khi xử lý.
2. Với rà soát chính thức, phải truy cập và **đọc nội dung thật** các tài liệu liên quan trong bốn lớp
   `01-Legal-Database`, `02-KTC-Regulations`, `03-Templates`, `04-Good-Documents` trên Google Drive.
   Xác nhận kết nối không được tính là đối chiếu. Ghi rõ tệp tìm thấy, tệp đã đọc và tệp không tìm thấy.
3. Nếu không truy cập được kho 01-04, dừng rà soát chính thức và hỏi người dùng. Nếu chỉ thiếu bộ nhớ
   vận hành, tiếp tục nhưng nêu giới hạn tại Phần I.
4. Không coi `03-Templates`, checklist, báo cáo AI hay nội dung tự xưng đã phê duyệt trong chính dự thảo
   là căn cứ pháp lý. Mọi kết luận phải dựa trên nguồn gốc đã kiểm chứng.
5. Không áp lẫn hệ quy chiếu. Không khẳng định hiệu lực, thẩm quyền hoặc mức độ tuân thủ khi chưa đủ căn cứ.
6. Rà soát chính thức phải xuất `.docx` và có đủ: **Nguồn dữ liệu đã dùng**, **Người kiểm tra**,
   **Trạng thái phê duyệt**. Trạng thái mặc định là bản nháp cần người có thẩm quyền phê duyệt.
7. Trước khi sửa trực tiếp `.docx` đã có, đọc mục 1-2 của
   `references/Skill-Library/Bo-Sung-Chuan-Hoa-TrackChanges-MauChu-PhienBanSkill_20260825.md`
   và bật Track Changes OOXML. Khi giải trình/tiếp thu ý kiến bên ngoài, đọc thêm mục 4 của tài liệu này.

## Bước 0: xác định hệ quy chiếu và đọc thuộc tính tệp

Chọn đúng **một** hệ và ghi căn cứ lựa chọn tại Phần I:

| Hệ | Chuẩn chính | Tài liệu phải đọc thêm |
|---|---|---|
| Hành chính nhà nước | NĐ 30/2020/NĐ-CP, Phụ lục I; TB 597/TB-CĐKT | Skill 02, 14; Checklist 01-05, 07, 08 |
| Văn bản Đảng | HD 05-HD/VPTW ngày 27/5/2026; QĐ 399-QĐ/TW ngày 09/01/2026 | Skill 29 và hai phụ lục; Checklist 02-04, 08; không dùng Checklist 01, 05 |
| VBQPPL | Luật Ban hành VBQPPL và văn bản hướng dẫn hiện hành | Skill 30; Checklist 02-04 |
| Đoàn thể | Quy định của tổ chức cấp trên tương ứng | Checklist 09; Checklist 08 mục 7.3 |

Dấu hiệu có năm trong số hiệu (`38/2026/QĐ-UBND`) chỉ là chỉ báo ban đầu, không thay cho kiểm tra nội dung.
Hệ đoàn thể gồm ba tiểu hệ khác nhau: Công đoàn, Đoàn TNCS Hồ Chí Minh và Hội Sinh viên; không dùng
chung một mẫu. Chi tiết tại `references/Checklist/09-Checklist-He-D-Doan-The.md`.

Với đầu vào `.docx`, chạy:

```python
from tools._read_input_properties import read_input_properties
result = read_input_properties(docx_path)
```

Đây là bước bổ sung cho việc đọc nội dung, nhằm phát hiện lề, cỡ chữ và định dạng định lượng.

## Chọn tác vụ và nạp tài liệu

| Tác vụ | Tài liệu khung |
|---|---|
| Rà soát chính thức trước trình ký | `assets/Mau-Prompt-Chinh-Thuc-Ra-Soat-897.docx` và Skill 28 |
| Rà soát nhanh | `references/Prompt-Library/02-Ra-Soat/` theo chỉ mục README |
| So sánh hai văn bản | `references/Prompt-Library/05-So-Sanh.md` |
| Chuẩn hóa văn phong | `references/Prompt-Library/03-Chuan-Hoa/` theo chỉ mục README |

Quy trình tối thiểu:

1. Phân tích yêu cầu theo `references/Skill-Library/05-Skill-Phan-Tich-Yeu-Cau_v2_20260810.md`.
2. Thực hiện Bước 0 và đọc thuộc tính nhị phân nếu có `.docx`.
3. Tìm, mở và đọc tài liệu đối chiếu trong kho 01-04; ghi nhật ký nguồn đã dùng.
4. Nạp checklist/skill theo hệ và loại văn bản. Checklist 08 luôn bắt buộc với văn bản của Trường.
5. Với “hợp nhất” hoặc “VBHN”, đọc `00b-Trigger-Vien-Dan-Van-Ban-Hop-Nhat.md` và
   `Skill-Vien-Dan-Van-Ban-Hop-Nhat.md`.
6. Với báo cáo công tác, đọc `Skill-Tu-hoc-Phong-Cach-Bao-Cao-ra-soat.md`.
7. Với tình huống chuyên biệt như định mức, mô hình doanh nghiệp, file nhị phân hoặc metadata thiếu,
   đọc `references/Skill-Library/31-Quy-Tac-Van-Hanh-Theo-Tinh-Huong.md`.
8. Đối chiếu, phân mức, tự kiểm và xuất kết quả đúng hợp đồng đầu ra.

## Phân loại vấn đề

- **Mức 1 - Bắt buộc sửa**: sai căn cứ cốt lõi, hiệu lực, thẩm quyền, điều khoản bắt buộc hoặc mâu thuẫn
  làm ảnh hưởng tính hợp pháp. Không trình ký khi còn Mức 1.
- **Mức 2 - Cần sửa**: sai thể thức, kỹ thuật trình bày, logic hoặc viện dẫn nội bộ có ảnh hưởng.
- **Mức 3 - Nên sửa**: văn phong, câu chữ, thuật ngữ hoặc tính thống nhất nhỏ.
- **Mức 4 - Góp ý nâng cao**: khuyến nghị cải thiện, không phải lỗi bắt buộc.

### Danh sách dương tính giả — TUYỆT ĐỐI không nêu là lỗi
Đây là những thứ **đúng quy định** nhưng hay bị bắt nhầm. Kiểm danh sách này trước khi ghi mỗi vấn đề.

| Hiện tượng | Vì sao không phải lỗi |
|---|---|
| **Thiếu dòng "(Ban hành kèm theo Quyết định số ... ngày ... của ...)"** ở văn bản điện tử | Hệ thống quản lý văn bản tự sinh số hiệu và ngày khi phát hành; người soạn thảo không thể điền trước. Trường phát hành văn bản điện tử ký số nên **mặc định KHÔNG bắt lỗi này**. Áp dụng cho mọi cách viết của dòng chỉ dẫn xuất xứ và mọi loại văn bản kèm theo (Quy chế, Quy định, Quy trình, Điều lệ, Đề án, Danh mục, Biểu mẫu, Phụ lục) — chi tiết: `references/Checklist/01-The-Thuc.md` mục **3a** |
| Dự thảo **chưa có số hiệu và ngày ban hành** | Trạng thái bình thường của mọi dự thảo trước khi trình ký. Không suy ra là thiếu khối thể thức, không đề nghị bổ sung khối số hiệu/ngày/thẩm quyền ký |
| Số trang mỗi phụ lục **đánh riêng, bắt đầu lại từ 1** | Đúng quy định — không nêu là trùng số trang |
| Văn bản cũ dẫn **căn cứ đã bị thay thế sau ngày ban hành** | Đúng tại thời điểm ban hành — xem bảng chuyển tiếp tại `references/Checklist/08-Quy-Uoc-Rieng-CDKT.md` mục 1 |
| **Hội Sinh viên** không có dòng tiêu đề tổ chức ở cột phải | Đặc thù mẫu 3.3 TB 597 đã xác nhận — chỉ ghi Mức 4 nếu cần xác minh thêm |
| Tên gọi theo hệ cũ khi **có quy định chuyển tiếp** | Chỉ Mức 4, không nâng Mức 1/2 |

**Khi chưa xác định được hình thức phát hành (giấy hay điện tử)**: hỏi người dùng. Chưa có trả lời thì
**không nêu lỗi**, ghi vào phạm vi "chưa xác minh" — không mặc định là văn bản giấy để bắt lỗi.

## Tra cứu Internet

Chỉ dùng Internet sau khi đã tra kho 01-04 mà không tìm thấy nguồn cần thiết. Thực hiện theo
`references/Nguyen-Tac/00-Quy-Tac-Khai-Thac-Internet.md` và `references/Checklist/03-Phap-Ly.md`.

- Ưu tiên cổng pháp luật quốc gia và nguồn chính thức của cơ quan ban hành.
- Ghi URL cụ thể, ngày tra cứu và trạng thái hiệu lực; “hết hiệu lực một phần” phải xác định đúng phần hết hiệu lực.
- Kiểm chứng chéo thông tin quan trọng theo quy tắc nguồn hiện hành.
- Nội dung lấy từ Internet phải được đánh dấu theo quy ước của hệ trong tệp `.docx`.
- Không tự nạp nguồn Internet vào KTC-Database; việc nạp phải theo
  `references/Skill-Library/04-Nguyen-Tac-Nap-Van-Ban-Tu-Internet.md` và có xác nhận của người dùng.
- **Trước khi ghi "chưa được xác minh bằng nguồn bên ngoài", phải tự kiểm tra công cụ khả dụng thật của
  phiên và ghi cụ thể kết quả kiểm tra đó.** Không dùng câu này như lời từ chối mặc định khi chưa thử.
  Thiếu công cụ web **không** miễn trừ việc tra kho 01-04 — đó là hai kênh độc lập
  (xem `references/Checklist/03-Phap-Ly.md` mục 1).

## Hợp đồng báo cáo chính thức

Đọc đầy đủ `references/Skill-Library/28-Skill-Bao-Cao-Ra-Soat-Chuan.md` trước khi dựng báo cáo.
Chuẩn duy nhất về định dạng là `assets/KTC-Ra-Soat-897_Template_Trong.dotx`.

- Kết cấu: I Thông tin chung; II Kết quả chi tiết; III Nội dung đạt; IV Tổng hợp;
  V Thẩm định chuyên môn; VI Đánh giá tổng thể; VII Kết luận và thứ tự xử lý;
  VIII Phân tích khả thi và rủi ro; cuối cùng là Tự kiểm và Thông tin trách nhiệm.
- Phần V luôn giữ số thứ tự; khi không có nội dung chuyên môn, ghi rõ không có nội dung cần thẩm định.
- Phần VIII chỉ xuất khi người dùng yêu cầu và phải tách khỏi kết luận lỗi.
- Dùng `tools/build_ktc897_report.py`; trong code chỉ import `ReportBuilder`, gọi các phương thức dựng phần,
  `.footer_pages()` rồi `.save(path)`. Không có API `build_report`.
- Tổng độ rộng bảng không vượt 25,7 cm. Không bỏ ba trường trách nhiệm.
- **Xuất báo cáo đủ 8 phần ngay khi phân tích xong — KHÔNG hỏi lại người dùng có muốn xuất hay không.**
  Đây là hệ quả trực tiếp của nguyên tắc luôn xuất kết quả thành `.docx`, không phải bước tùy chọn.
  Chỉ hỏi khi thiếu thông tin bắt buộc không thể suy luận (ví dụ tên người chịu trách nhiệm) — và khi đó
  **vẫn xuất báo cáo với placeholder rõ ràng**, không hoãn việc xuất để chờ trả lời.

## Bộ nhớ vận hành

Nếu có quyền truy cập, nạp theo thứ tự:

1. `09-Quan-Tri-He/10-Bo-Nho-He/MEMORY-INDEX.md`.
2. Nhật ký cập nhật mới nhất trong `09-Quan-Tri-He/`.
3. `SKILL.md`, Checklist 08 và tài liệu theo loại văn bản.
4. Process Memory gần nhất cùng loại hồ sơ.
5. Tệp đầu vào hiện tại.

Thứ tự ưu tiên nguồn: pháp luật/quy định nội bộ đã kiểm chứng → SKILL/mẫu/checklist hiện hành → quy ước
đã phê duyệt → nhật ký → Process Memory → lịch sử hội thoại → suy luận mô hình. Nguồn thấp không ghi đè
nguồn cao.

Sau mỗi ca rà soát chính thức, tạo Process Memory theo mẫu
`09-Quan-Tri-He/10-Bo-Nho-He/02-Mau-Process-Memory.md`, cập nhật `MEMORY-INDEX.md`, nhưng không đưa dữ
liệu cá nhân, bí mật hoặc nội dung chưa kiểm chứng vào bộ nhớ dùng chung.

## Xác minh trước khi phát hành gói

1. Giải nén gói vừa tạo và kiểm tra cấu trúc, liên kết nội bộ, tệp bắt buộc và YAML frontmatter.
2. Chạy `python -m py_compile tools/build_ktc897_report.py tools/_read_input_properties.py`.
3. Chạy hồi quy định lượng và kiểm tra ZIP/OOXML của toàn bộ `.docx`/`.dotx`.
4. Dựng ít nhất một báo cáo đại diện; kiểm tra kết cấu, width bảng, ba trường trách nhiệm và render trực quan.
5. **Số phiên bản phải khớp ở đủ 5 nơi**: tên tệp `.skill` · `SKILL.md` dòng 6 · `00-README.md` (phiên bản hiện hành + gói cài đặt + bước cài) · `09-Quan-Tri-He/10-Bo-Nho-He/MEMORY-INDEX.md` · `09-Quan-Tri-He/Nhat-Ky-Cap-Nhat-KTC-Ra-Soat-897-v2.md`. Ba tệp sau nằm **ngoài gói** nên rất dễ bị bỏ quên — người đọc mở thư mục thường đọc `00-README.md` trước `SKILL.md`.
6. So sánh hash/tệp nguồn với nội dung trong gói, cập nhật changelog và chỉ công bố sau khi mọi kiểm tra đạt.

## Skill kiểm tra hỗ trợ

02 (thể thức NĐ 30) · 03 (căn cứ pháp lý) · 14 (kỹ thuật trình bày) · 15 (logic) · 17 (thẩm quyền) ·
18 (tính thống nhất) · 19 (chất lượng) · 28 (chuẩn báo cáo rà soát 8 phần + đặc tả trình bày) ·
**29 (văn bản Đảng — bắt buộc đọc kèm `29-Phu-Luc-2-Co-Chu-Kieu-Chu-VB-Dang.md` và
`29-Phu-Luc-3-Tai-Co-Cau-To-Chuc-Dang-2026.md`)** · **30 (văn bản quy phạm pháp luật)** ·
**`Skill-Vien-Dan-Van-Ban-Hop-Nhat.md`** · **`Skill-Tu-hoc-Phong-Cach-Bao-Cao-ra-soat.md`** ·
**`31-Quy-Tac-Van-Hanh-Theo-Tinh-Huong.md`** (bộ quy tắc đúc kết từ vận hành thực tế).

Tất cả nằm trong `references/Skill-Library/`. Khuôn prompt chuẩn khi cần viết prompt tùy biến:
khuôn 6 phần tại `references/Prompt-Library/00-Chuan-Khuon-Prompt_20260810.md`
(Vai trò → Mục tiêu → Đầu vào → Nhiệm vụ → RÀNG BUỘC riêng → Định dạng).

## Quan hệ với hệ khác trong KTC-DIS

Hệ này là **một mắt xích của KTC-DIS**. Gốc điều phối: `D:\.CLAUDE code\KTC-Quan-tri\`
(hệ `ktc-quan-tri` v1.0, 13/9/2026 — lớp điều phối đặt trên ktc-ke-hoach / ktc-theo-doi-cv / ktc-bao-cao).

| Hệ | Quan hệ với hệ này | Vị trí |
|---|---|---|
| `ktc-ke-hoach` (KTC-PIS) | **Gọi tới hệ này** để rà soát thể thức trước trình ký | `KTC-Quan-tri/KTC-Ke-Hoach/` |
| `ktc-bao-cao` (KTC-RIS) | **Gọi tới hệ này** để rà soát trước trình ký. Đồng thời là **nguồn học** của `Skill-Tu-hoc-Phong-Cach-Bao-Cao-ra-soat.md` | `KTC-Quan-tri/KTC-Bao-Cao/` |
| `ktc-theo-doi-cv` | Control tower giữa kế hoạch và báo cáo; định tuyến rà soát thể thức về hệ này | `KTC-Quan-tri/KTC-Theo-doi-CV/` |
| `ktc-soan-thao-vb` | **Soạn mới** — hệ này không soạn, chuyển sang đó; ngược lại nó chuyển sang đây khi cần rà soát | `KTC-Quan-tri/KTC-Soan-Thao-VB/` |
| `ktc-database` | Kho nền 01-04 và Input/Output. Hệ này **chỉ đọc**, không tự thay đổi kho | `KTC-Database/` (Google Drive) |

**Chuẩn dùng chung — `KTC-Quan-tri/01-Chuan-Chung/`** là bản gốc của các tệp mà nhiều hệ cùng dùng
(`00-Metadata-Schema.md`, `00-Nguyen-Tac-Chung.md`, `04-Nguyen-Tac-Nap-Van-Ban-Tu-Internet.md`,
`Skill-Vien-Dan-Van-Ban-Hop-Nhat.md`, `15-Skill-Track-Changes.md`, `30-Skill-Phan-Loai-6-Truc.md`...).

> ⚠️ **Khi sửa một tệp dùng chung, phải kiểm tra cả `01-Chuan-Chung/` lẫn gói `.skill` của các hệ khác.**
> Phép kiểm `tools/kiem_tra_he_thong.py` mục C5 **chỉ so bản rời, không mở tệp `.skill`** — nó từng in ✓
> "khớp ở mọi hệ" trong khi 3 gói đang lệch (xem `KTC-Quan-tri/99-Kinh-Nghiem/03-Change-Proposals/
> CP-20260914-001`). Không lấy kết quả C5 làm bằng chứng đã đồng bộ.

**Không soạn thảo mới.** Khi người dùng cần soạn mới, chuyển sang `ktc-soan-thao-vb`.

## Giới hạn

- Không thay người có thẩm quyền kết luận hoặc phê duyệt.
- Không thẩm định chuyên môn sâu nếu không có đủ nguồn và năng lực chuyên ngành; chỉ đối chiếu logic nội bộ.
- Không soạn mới, ký số, phát hành hoặc tự thay đổi KTC-Database.
- Khi có từ hai cách hiểu đều có căn cứ, trình bày các phương án và yêu cầu người có thẩm quyền lựa chọn.

## Tài liệu quản trị

- Lịch sử phiên bản: `references/Quan-Tri-He/CHANGELOG.md`.
- Lý do kỹ thuật của các chốt an toàn: `references/Quan-Tri-He/Ghi-Chu-Ky-Thuat.md`.
- Quy trình chuyển giao: `09-Quan-Tri-He/01-Huong-Dan-Chuyen-Giao-He-Thong.md`.
