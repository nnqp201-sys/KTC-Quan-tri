# KTC-Ra-Soat-897 v3.0
**Release date:** 28/08/2026  
**Trạng thái:** RELEASE CANDIDATE — đạt kiểm tra cấu trúc/kỹ thuật; cần chạy acceptance trên Claude sau khi upload trước khi công bố chính thức.

## Mục tiêu
Hệ chuyên biệt rà soát, so sánh, chuẩn hóa dự thảo văn bản của Trường Cao đẳng Kon Tum theo TB 897. Không soạn văn bản mới.

## Điểm nâng cấp chính so với v2.x
1. Orchestration bằng XML semantic **có chọn lọc**, không bọc XML máy móc toàn bộ prompt.
2. Long-context: document/evidence first, task/query last.
3. Bỏ Assistant prefill do Claude thế hệ mới không hỗ trợ; dùng output contract và JSON Schema tùy runtime.
4. Hệ D tách D1 Công đoàn / D2 Đoàn Thanh niên / D3 Hội Sinh viên + Checklist 09.
5. Hệ C cập nhật: Luật 64/2025/QH15 + Luật 87/2025/QH15; NĐ 78/2025 + NĐ 187/2025; NĐ 79/2025 + NĐ 187/2025. NĐ 34/2016, 154/2020, 59/2024 không dùng làm khung hiện hành sau 01/04/2025.
6. Anti prompt-injection cho nội dung tài liệu/tool output.
7. Evidence-first cho finding pháp lý/trọng yếu.
8. Auto-trigger + binary DOCX fallback rõ ràng: không có bytes thật thì không giả vờ đã đo lề/cỡ chữ.
9. Temporal legal rules cho NĐ 60/111 ↔ NĐ 334/2026.
10. Acceptance gate + regression fixture mở rộng.

## Cấu trúc
```text
ktc-ra-soat-897/
├── SKILL.md
├── assets/
├── references/
│   ├── Checklist/
│   ├── Skill-Library/
│   ├── Prompt-Library/
│   └── Nguyen-Tac/
├── tools/
├── schemas/
├── 13-Regression-Test/
└── 09-Quan-Tri-He/10-Bo-Nho-He/
```

## Cài trên Claude
Gói cài chính thức là ZIP có thư mục `ktc-ra-soat-897/` ở root. File `.skill` đi kèm là cùng định dạng ZIP để tương thích quy ước KTC hiện có.

## Điểm nạp đầu phiên
`MEMORY-INDEX → 00c Auto Trigger → SKILL → Checklist 08 → Skill/Checklist theo hệ → Process Memory liên quan → input`.

## Trạng thái kiểm thử
- Deterministic validation: chạy `tools/validate_v3.py`.
- Regression mô hình: dùng `13-Regression-Test/File-Test-Loi-KTC897-v3.0.docx` + `DAP-AN-v3.0.md`.
- Không tuyên bố 30/30 hoặc 100% trước khi Claude thực chạy và đối chiếu đáp án.
