# 01-Ke-hoach-Nang-cap-v3.0
**Ngày:** 28/08/2026

## I. Baseline
- Kế thừa package v2.17 đã kiểm zip/byte trước đây.
- Đồng bộ patch loose v2.18: SKILL.md và `build_ktc897_report.py` v3.3.
- Kế thừa Checklist 08 v2.8 và toàn bộ Prompt/Skill hiện có.

## II. Vấn đề phải xử lý
1. 11/30 finding từng bị bỏ sót trong regression.
2. Hệ D chưa được mã hóa đủ độc lập.
3. Prompt v2 trộn instruction/context, thiếu boundary rõ.
4. v2.x có lịch sử CONFLICT phiên bản giữa `.skill`, SKILL/README/MEMORY.
5. Hệ C còn tham chiếu NĐ 34/2016 + NĐ 154/2020 đã không còn là khung hiện hành.
6. Đề xuất v3 ban đầu dùng Assistant prefill — không tương thích Claude 4.6+ hiện hành.
7. Cơ chế tự chủ tài chính có mốc tương lai 05/10/2026 cần temporal trigger thay vì hard-code kết luận thay thế chưa kiểm chứng đủ.

## III. Workstream
### WS1 — Architecture & Context
- Semantic XML boundaries.
- Document/evidence first; task last.
- Anti-injection.
- Output contract + API JSON schema.

### WS2 — Legal/System Frames
- Hệ A/B/C/D tách rõ.
- Hệ C update current law.
- Hệ D D1/D2/D3 + checklist riêng.
- Temporal legal rule.

### WS3 — Deterministic DOCX
- Giữ `_read_input_properties.py` v2.0.
- Giữ build report v3.3; sửa định danh system v3.0/fallback version.
- Kiểm table fixed/gridCol/width.

### WS4 — Memory & Governance
- MEMORY-INDEX v3.0.
- Process Memory.
- Migration + manifest.
- CONFLICT gate.

### WS5 — Regression
- 30 lỗi legacy: mục tiêu coverage 30/30.
- Fixture mở rộng: 12 ca lỗi mới + 4 negative controls.
- Không công bố pass rate model nếu chưa chạy thật trên Claude.

## IV. Điều kiện phát hành chính thức
1. Package ZIP toàn vẹn, cấu trúc đúng Claude Skills.
2. YAML name/description hợp lệ; description ≤200 ký tự.
3. Không còn active reference NĐ34/154/59 như khung Hệ C hiện hành.
4. Không còn Assistant prefill.
5. Python compile + test margin PASS.
6. Regression model trên Claude: coverage đạt mục tiêu và không có false positive critical.
7. Người phụ trách xác nhận báo cáo acceptance.
