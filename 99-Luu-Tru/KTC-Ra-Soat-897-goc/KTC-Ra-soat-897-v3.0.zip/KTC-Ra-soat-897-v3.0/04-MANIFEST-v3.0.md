# 04-MANIFEST-v3.0
## Core release artifacts
- `assets/897-TB-CDKT-Huong-dan-Kiem-Tra-Ra-Soat-Van-Ban-AI.docx` — văn bản nền TB 897.
- `SKILL.md` — v3 orchestrator.
- `00-README.md`.
- `01-Ke-hoach-Nang-cap-v3.0.md`.
- `02-Bao-cao-Tham-dinh-Kien-truc-v3.0.md`.
- `03-MIGRATION-v2.18-to-v3.0.md`.
- `references/Skill-Library/D0-Skill-He-Quy-Chieu-Doan-The-v3.md`.
- `references/Checklist/09-Checklist-He-D-Doan-The-v3.md`.
- `references/Skill-Library/30-Skill-Van-Ban-Quy-Pham-Phap-Luat.md` — updated legal frame.
- `references/Prompt-Library/00-Core-Orchestration-v3.md`.
- `references/Prompt-Library/Examples-v3.md`.
- `schemas/review-output.schema.json`.
- `tools/build_ktc897_report.py` v3.3, system-version aware v3.0.
- `tools/_read_input_properties.py` v2.0.
- `tools/test_margin_boundary.py`.
- `tools/validate_v3.py`, `tools/package_skill.py`.
- regression fixture/answer/acceptance.
- memory index/journal/process memory.

## Inherited assets/references
Tất cả tài nguyên baseline v2.17 được kế thừa trong source package, sau đó được patch bằng các file v2.18/v3.0 hiện hành. Các file kế thừa không được hiểu là nguồn ưu tiên cao hơn file v3 có cùng tên.

## Release status
`RELEASE CANDIDATE` cho tới khi model regression trên Claude được xác nhận bởi người có trách nhiệm.
