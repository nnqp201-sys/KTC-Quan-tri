# 02-Bao-cao-Tham-dinh-Kien-truc-v3.0
## Kết luận thẩm định trước triển khai
**Ngày:** 28/08/2026

## 1. Nội dung đề xuất được giữ
- XML tags: giữ nhưng chỉ dùng tại ranh giới semantic quan trọng.
- Document-first/query-last: giữ cho long context.
- Explicit uncertainty/refusal: giữ và chuyển thành `uncertainty_handling` theo materiality.
- Hệ D tách 3 tiểu-hệ: giữ và bổ sung Checklist 09.
- `_read_input_properties.py` ở Bước 0: giữ, thêm fallback minh bạch khi không có binary.
- 3 trường trách nhiệm, Track Changes, Process Memory: giữ.

## 2. Nội dung đề xuất được sửa
### 2.1. Bỏ Assistant prefill
Claude Sonnet 4.6 và các model mới hơn không hỗ trợ assistant-message prefill. v3.0 dùng system/output instructions; runtime API có thể dùng structured outputs (`output_config.format`).

### 2.2. Không “XML hóa 100%”
XML là công cụ boundary, không phải mục tiêu. Dùng XML cho context/rules/documents/task/output; nội dung nghiệp vụ giữ Markdown/bảng khi dễ đọc hơn.

### 2.3. Cập nhật Hệ C
Đề xuất cũ ghi NĐ 34/2016 + NĐ 154/2020. v3.0 thay bằng khung hiện hành:
- Luật 64/2025/QH15, sửa bởi Luật 87/2025/QH15.
- NĐ 78/2025/NĐ-CP, sửa bởi NĐ 187/2025/NĐ-CP.
- NĐ 79/2025/NĐ-CP, sửa bởi NĐ 187/2025/NĐ-CP cho kiểm tra/rà soát/hệ thống hóa.
- NĐ 34/2016, 154/2020, 59/2024 chỉ còn ý nghĩa lịch sử sau 01/04/2025.

### 2.4. Temporal NĐ 334/2026
Không khẳng định tự động “thay toàn bộ” chỉ từ ghi nhớ. Tại/ sau 05/10/2026 phải tái kiểm nguồn chính thức và phạm vi thay thế trước khi viện dẫn.

### 2.5. Không hard-code model
Skill là model-agnostic. Lựa chọn Sonnet/Opus do runtime/workspace quyết định; tránh làm SKILL hết hạn vì model ID đổi.

## 3. Kiến trúc v3.0
`Source hierarchy → Auto trigger → Document security → Per-document system frame → Evidence-first review → Severity/uncertainty → Output contract → Acceptance gate → Process Memory`.

## 4. Rủi ro còn lại
- Hệ D vẫn phụ thuộc mức đầy đủ của tài liệu cấp trên được nạp; thiếu căn cứ thì Mức 4.
- Behavioral regression cần chạy thật trên Claude; deterministic validation không thay thế model evaluation.
- NĐ 334/2026 cần revalidation gần ngày hiệu lực.
