# 03-MIGRATION-v2.18-to-v3.0

## Nguồn kế thừa
- Package v2.17 làm baseline file tree.
- Loose SKILL.md v2.18 + build script v3.3 ngày 28/8 làm patch hiện hành.

## CONFLICT baseline đã phát hiện
Tại thời điểm migration:
- loose `SKILL.md` ghi v2.18;
- `00-README.md`, `MEMORY-INDEX.md`, package `.skill` vẫn ghi v2.17.
V3.0 **không sửa ngược v2.x**; tạo release folder riêng và đồng bộ toàn bộ control files về v3.0.

## Thay đổi breaking/behavioral
1. Hệ C đổi pháp lý mặc định sang luật/nghị định 2025 hiện hành.
2. Hệ D dùng Skill + Checklist riêng.
3. Missing core evidence không làm dừng toàn workflow; chỉ block kết luận phụ thuộc và block trình ký nếu material.
4. Severity v3 chuẩn hóa: lỗi lề/cỡ chữ/thể thức = Mức 2 theo policy mới. Khi chấm bộ legacy phải lưu cả `legacy_level` và `v3_level` nếu khác.
5. Không dùng Assistant prefill.
6. Không tuyên bố đã kiểm binary nếu runtime không cung cấp bytes.

## Tương thích
- Tên Skill giữ `ktc-ra-soat-897` để không đổi trigger người dùng.
- 4 tác vụ A/B/C/D nghiệp vụ giữ nguyên.
- Template báo cáo, Prompt chính thức và các Prompt-Library cũ được kế thừa.
- `build_ktc897_report.py` vẫn là script xuất báo cáo duy nhất; script version v3.3, system version v3.0.
